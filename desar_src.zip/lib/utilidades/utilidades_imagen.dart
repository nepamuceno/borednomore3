// /desar/lib/utilidades/utilidades_imagen.dart
// Manejo local de imagenes - redimensionar y guardar

import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:image/image.dart' as img;

class UtilidadesImagen {
  static Future<String> guardar(String rutaOriginal, String nombreBase) async {
    final doc = await getApplicationDocumentsDirectory();
    final dir = Directory('${doc.path}/fotos');
    if (!await dir.exists()) await dir.create(recursive: true);

    final ts = DateTime.now().millisecondsSinceEpoch;
    final ruta = '${dir.path}/${nombreBase}_$ts.jpg';

    final bytes = await File(rutaOriginal).readAsBytes();
    img.Image? imagen = img.decodeImage(bytes);
    if (imagen != null) {
      if (imagen.width > 800) imagen = img.copyResize(imagen, width: 800);
      await File(ruta).writeAsBytes(img.encodeJpg(imagen, quality: 85));
    } else {
      await File(rutaOriginal).copy(ruta);
    }
    return ruta;
  }

  static Future<void> eliminar(String? ruta) async {
    if (ruta == null) return;
    try {
      final f = File(ruta);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  static Future<bool> existe(String? ruta) async {
    if (ruta == null) return false;
    return File(ruta).exists();
  }
}
