// /desar/lib/base_datos/base_datos_helper.dart
// DESAR - Schema FINAL v1 — sin migraciones históricas
// Columnas = exactamente lo que devuelven aMapaSql() de cada modelo

import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../modelos/empleado.dart';
import '../modelos/administrador_bot.dart';
import '../modelos/registro.dart';
import '../modelos/jornada.dart';
import '../modelos/sitio.dart';
import '../modelos/configuracion.dart';

class BaseDatosHelper {
  static final BaseDatosHelper _inst = BaseDatosHelper._interno();
  static Database? _bd;
  BaseDatosHelper._interno();
  factory BaseDatosHelper() => _inst;

  static const String _nombre  = 'desar.db';
  static const int    _version = 1; // VERSIÓN FINAL - no migrar

  static const String tEmpleados     = 'empleados';
  static const String tRegistros     = 'registros';
  static const String tJornadas      = 'jornadas';
  static const String tSitios        = 'sitios';
  static const String tAdminsBot     = 'administradores_bot';
  static const String tConfiguracion = 'configuracion';

  Future<Database> get bd async { _bd ??= await _init(); return _bd!; }

  Future<Database> _init() async {
    final ruta = join(await getDatabasesPath(), _nombre);
    return openDatabase(ruta, version: _version,
        onCreate: _crear, onUpgrade: _migrar);
  }

  Future<void> _crear(Database db, int ver) async {
    await _crearTablas(db);
    await db.insert(tSitios, {
      'nombre': 'Principal', 'descripcion': 'Sitio principal',
      'tipo_sitio': 'normal', 'recibir_advertencias': 0, 'activo': 1,
    });
    await db.insert(tConfiguracion, Configuracion().aMapaSql()..['id'] = 1);
  }

  // Migración universal: agrega columnas faltantes si la BD ya existía
  Future<void> _migrar(Database db, int oldVer, int newVer) async {
    final ops = [
      // empleados
      'ALTER TABLE $tEmpleados ADD COLUMN codigo_postal TEXT',
      'ALTER TABLE $tEmpleados ADD COLUMN fecha_alta TEXT',
      'ALTER TABLE $tEmpleados ADD COLUMN fecha_vencimiento TEXT',
      // registros
      'ALTER TABLE $tRegistros ADD COLUMN sync_status INTEGER NOT NULL DEFAULT 0',
      // jornadas
      'ALTER TABLE $tJornadas ADD COLUMN sync_status INTEGER NOT NULL DEFAULT 0',
      // sitios - nuevo
      'ALTER TABLE $tSitios ADD COLUMN geofence_radio_metros REAL',
      "ALTER TABLE $tSitios ADD COLUMN geofence_tipo TEXT DEFAULT 'permitido'",
      'ALTER TABLE $tSitios ADD COLUMN geofence_activo INTEGER DEFAULT 0',
      "ALTER TABLE $tSitios ADD COLUMN tipo_sitio TEXT DEFAULT 'normal'",
      'ALTER TABLE $tSitios ADD COLUMN recibir_advertencias INTEGER DEFAULT 0',
      // configuracion
      'ALTER TABLE $tConfiguracion ADD COLUMN ciudad_compania TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN estado_compania TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN pais_compania TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN codigo_postal_compania TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN logo_compania TEXT',
      "ALTER TABLE $tConfiguracion ADD COLUMN bot_prefijo TEXT DEFAULT '/'",
      'ALTER TABLE $tConfiguracion ADD COLUMN facebook_page_token TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN facebook_app_id TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN facebook_app_secret TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN facebook_verify_token TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN facebook_habilitado INTEGER DEFAULT 0',
      'ALTER TABLE $tConfiguracion ADD COLUMN sync_url TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN sync_api_key TEXT',
      'ALTER TABLE $tConfiguracion ADD COLUMN sync_puerto INTEGER DEFAULT 8080',
      'ALTER TABLE $tConfiguracion ADD COLUMN sync_habilitado INTEGER DEFAULT 0',
      'ALTER TABLE $tConfiguracion ADD COLUMN sync_solo_wifi INTEGER DEFAULT 1',
      // tabla admins_bot
      '''CREATE TABLE IF NOT EXISTS $tAdminsBot (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plataforma TEXT NOT NULL, plataforma_id TEXT NOT NULL,
        nombre TEXT, apellido TEXT, username TEXT, email TEXT,
        telefono TEXT, empresa TEXT, cargo TEXT, notas TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        fecha_registro TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(plataforma, plataforma_id))''',
    ];
    for (final sql in ops) {
      try { await db.execute(sql); } catch (_) {}
    }
  }

  Future<void> _crearTablas(Database db) async {

    // ── EMPLEADOS ──────────────────────────────────────────
    // Columnas = exactamente Empleado.aMapaSql() keys
    await db.execute('''CREATE TABLE IF NOT EXISTS $tEmpleados (
      id                    INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo_empleado       TEXT NOT NULL UNIQUE,
      nombre                TEXT NOT NULL,
      direccion             TEXT,
      ciudad                TEXT,
      estado                TEXT,
      pais                  TEXT,
      codigo_postal         TEXT,
      telefono              TEXT,
      telefono_emergencia   TEXT,
      fecha_nacimiento      TEXT,
      rfc                   TEXT,
      seguro_social         TEXT,
      numero_identificacion TEXT,
      puesto                TEXT,
      tipo_sangre           TEXT,
      notas                 TEXT,
      foto_perfil           TEXT,
      foto_rostro_1         TEXT,
      foto_rostro_2         TEXT,
      foto_rostro_3         TEXT,
      embedding_1           TEXT,
      embedding_2           TEXT,
      embedding_3           TEXT,
      sitio_trabajo         TEXT,
      activo                INTEGER NOT NULL DEFAULT 1,
      fecha_registro        TEXT NOT NULL DEFAULT (datetime('now')),
      fecha_alta            TEXT,
      fecha_vencimiento     TEXT)''');

    // ── REGISTROS ─────────────────────────────────────────
    // Columnas = Registro.aMapaSql() keys + sync_status
    await db.execute('''CREATE TABLE IF NOT EXISTS $tRegistros (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      empleado_id     INTEGER NOT NULL,
      codigo_empleado TEXT NOT NULL,
      nombre_empleado TEXT NOT NULL,
      tipo            TEXT NOT NULL,
      timestamp       TEXT NOT NULL,
      gps_lat         REAL,
      gps_lon         REAL,
      sitio_trabajo   TEXT,
      metodo          TEXT NOT NULL DEFAULT 'manual',
      notas           TEXT,
      sync_status     INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (empleado_id) REFERENCES $tEmpleados(id))''');

    // ── JORNADAS ──────────────────────────────────────────
    // Columnas = Jornada.aMapaSql() keys + sync_status
    await db.execute('''CREATE TABLE IF NOT EXISTS $tJornadas (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      empleado_id       INTEGER NOT NULL,
      codigo_empleado   TEXT NOT NULL,
      nombre_empleado   TEXT NOT NULL,
      fecha             TEXT NOT NULL,
      entrada_timestamp TEXT,
      salida_timestamp  TEXT,
      horas_trabajadas  REAL,
      completa          INTEGER NOT NULL DEFAULT 0,
      sitio_trabajo     TEXT,
      sync_status       INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (empleado_id) REFERENCES $tEmpleados(id))''');

    // ── SITIOS ────────────────────────────────────────────
    // Columnas = Sitio.aMapaSql() keys
    await db.execute('''CREATE TABLE IF NOT EXISTS $tSitios (
      id                    INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre                TEXT NOT NULL UNIQUE,
      descripcion           TEXT,
      gps_lat               REAL,
      gps_lon               REAL,
      geofence_radio_metros REAL,
      geofence_tipo         TEXT DEFAULT 'permitido',
      geofence_activo       INTEGER DEFAULT 0,
      tipo_sitio            TEXT DEFAULT 'normal',
      recibir_advertencias  INTEGER DEFAULT 0,
      activo                INTEGER NOT NULL DEFAULT 1)''');

    // ── ADMINISTRADORES BOT ───────────────────────────────
    // Columnas = AdministradorBot.aMapaSql() keys
    await db.execute('''CREATE TABLE IF NOT EXISTS $tAdminsBot (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      plataforma     TEXT NOT NULL,
      plataforma_id  TEXT NOT NULL,
      nombre         TEXT,
      apellido       TEXT,
      username       TEXT,
      email          TEXT,
      telefono       TEXT,
      empresa        TEXT,
      cargo          TEXT,
      notas          TEXT,
      activo         INTEGER NOT NULL DEFAULT 1,
      fecha_registro TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(plataforma, plataforma_id))''');

    // ── CONFIGURACION ─────────────────────────────────────
    // Columnas = Configuracion.aMapaSql() keys
    await db.execute('''CREATE TABLE IF NOT EXISTS $tConfiguracion (
      id                       INTEGER PRIMARY KEY DEFAULT 1,
      nombre_compania          TEXT NOT NULL DEFAULT 'Mi Compañía',
      rfc_compania             TEXT,
      direccion_compania       TEXT,
      ciudad_compania          TEXT,
      estado_compania          TEXT,
      pais_compania            TEXT,
      codigo_postal_compania   TEXT,
      telefono_compania        TEXT,
      email_compania           TEXT,
      logo_compania            TEXT,
      whatsapp_api_url         TEXT,
      whatsapp_api_token       TEXT,
      whatsapp_channel_id      TEXT,
      whatsapp_phone_number_id TEXT,
      whatsapp_verify_token    TEXT,
      whatsapp_habilitado      INTEGER DEFAULT 0,
      telegram_bot_token       TEXT,
      telegram_chat_id         TEXT,
      telegram_habilitado      INTEGER DEFAULT 0,
      facebook_page_token      TEXT,
      facebook_app_id          TEXT,
      facebook_app_secret      TEXT,
      facebook_verify_token    TEXT,
      facebook_habilitado      INTEGER DEFAULT 0,
      sync_url                 TEXT,
      sync_api_key             TEXT,
      sync_puerto              INTEGER DEFAULT 8080,
      sync_habilitado          INTEGER DEFAULT 0,
      sync_solo_wifi           INTEGER DEFAULT 1,
      bot_prefijo              TEXT DEFAULT '/',
      hora_entrada_default     TEXT DEFAULT '08:00',
      hora_salida_default      TEXT DEFAULT '17:00',
      tolerancia_minutos       INTEGER DEFAULT 15,
      jornada_horas            REAL    DEFAULT 8.0,
      umbral_reconocimiento    REAL    DEFAULT 0.55,
      pedir_confirmacion_nuevo INTEGER DEFAULT 1,
      formato_reporte_default  TEXT    DEFAULT 'excel',
      zona_horaria             TEXT    DEFAULT 'America/Mexico_City')''');
  }

  // ═══════════════════════════════════════════════════════
  // EMPLEADOS
  // ═══════════════════════════════════════════════════════
  Future<int>  insertarEmpleado(Empleado e) async =>
      (await bd).insert(tEmpleados, e.aMapaSql(), conflictAlgorithm: ConflictAlgorithm.abort);
  Future<int>  actualizarEmpleado(Empleado e) async =>
      (await bd).update(tEmpleados, e.aMapaSql(), where: 'id=?', whereArgs: [e.id]);
  Future<int>  eliminarEmpleado(int id) async =>
      (await bd).delete(tEmpleados, where: 'id=?', whereArgs: [id]);
  Future<int>  cambiarEstado(int id, int activo) async =>
      (await bd).update(tEmpleados, {'activo': activo}, where: 'id=?', whereArgs: [id]);

  Future<void> eliminarEmpleadoCompleto(int id) async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.delete(tRegistros, where: 'empleado_id=?', whereArgs: [id]);
      await txn.delete(tJornadas,  where: 'empleado_id=?', whereArgs: [id]);
      await txn.delete(tEmpleados, where: 'id=?',          whereArgs: [id]);
    });
  }

  Future<List<Empleado>> obtenerTodosEmpleados() async =>
      (await (await bd).query(tEmpleados, orderBy: 'nombre ASC')).map(Empleado.desdeMapa).toList();
  Future<List<Empleado>> obtenerEmpleadosActivos() async =>
      (await (await bd).query(tEmpleados, where: 'activo=1', orderBy: 'nombre ASC')).map(Empleado.desdeMapa).toList();

  Future<Empleado?> obtenerEmpleadoPorCodigo(String codigo) async {
    final r = await (await bd).query(tEmpleados, where: 'codigo_empleado=?', whereArgs: [codigo]);
    return r.isEmpty ? null : Empleado.desdeMapa(r.first);
  }
  Future<Empleado?> obtenerEmpleadoPorId(int id) async {
    final r = await (await bd).query(tEmpleados, where: 'id=?', whereArgs: [id]);
    return r.isEmpty ? null : Empleado.desdeMapa(r.first);
  }
  Future<List<Empleado>> buscarEmpleados(String t) async {
    final r = await (await bd).query(tEmpleados,
        where: 'nombre LIKE ? OR codigo_empleado LIKE ? OR numero_identificacion LIKE ? OR puesto LIKE ?',
        whereArgs: ['%$t%','%$t%','%$t%','%$t%'], orderBy: 'nombre ASC');
    return r.map(Empleado.desdeMapa).toList();
  }
  Future<bool> existeCodigoEmpleado(String codigo, {int? excludeId}) async {
    String w = 'codigo_empleado=?'; List<dynamic> a = [codigo];
    if (excludeId != null) { w += ' AND id != ?'; a.add(excludeId); }
    return (await (await bd).query(tEmpleados, where: w, whereArgs: a)).isNotEmpty;
  }
  Future<void> renombrarCodigoEmpleado(String viejo, String nuevo) async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.update(tEmpleados, {'codigo_empleado': nuevo}, where: 'codigo_empleado=?', whereArgs: [viejo]);
      await txn.update(tRegistros, {'codigo_empleado': nuevo}, where: 'codigo_empleado=?', whereArgs: [viejo]);
      await txn.update(tJornadas,  {'codigo_empleado': nuevo}, where: 'codigo_empleado=?', whereArgs: [viejo]);
    });
  }
  Future<List<Empleado>> obtenerEmpleadosRango(int ini, int fin) async {
    final r = await (await bd).query(tEmpleados,
        where: 'id >= ? AND id <= ?', whereArgs: [ini, fin], orderBy: 'id ASC');
    return r.map(Empleado.desdeMapa).toList();
  }

  // ═══════════════════════════════════════════════════════
  // REGISTROS
  // ═══════════════════════════════════════════════════════
  Future<int> insertarRegistro(Registro r) async => (await bd).insert(tRegistros, r.aMapaSql());
  Future<int> actualizarRegistro(Registro r) async =>
      (await bd).update(tRegistros, r.aMapaSql(), where: 'id=?', whereArgs: [r.id]);
  Future<int> eliminarRegistro(int id) async =>
      (await bd).delete(tRegistros, where: 'id=?', whereArgs: [id]);

  Future<List<Registro>> obtenerRegistrosPorRango(String ini, String fin) async {
    final r = await (await bd).query(tRegistros,
        where: 'timestamp >= ? AND timestamp <= ?', whereArgs: [ini, fin], orderBy: 'timestamp ASC');
    return r.map(Registro.desdeMapa).toList();
  }
  Future<List<Registro>> obtenerRegistrosTodos() async =>
      (await (await bd).query(tRegistros, orderBy: 'timestamp ASC')).map(Registro.desdeMapa).toList();
  Future<List<Registro>> obtenerRegistrosPorEmpleado(int empId) async {
    final r = await (await bd).query(tRegistros,
        where: 'empleado_id=?', whereArgs: [empId], orderBy: 'timestamp DESC');
    return r.map(Registro.desdeMapa).toList();
  }
  Future<Registro?> obtenerUltimoRegistro(int empId) async {
    final r = await (await bd).query(tRegistros,
        where: 'empleado_id=?', whereArgs: [empId], orderBy: 'timestamp DESC', limit: 1);
    return r.isEmpty ? null : Registro.desdeMapa(r.first);
  }
  Future<List<Registro>> obtenerUltimosRegistros({int limite = 5}) async =>
      (await (await bd).query(tRegistros, orderBy: 'timestamp DESC', limit: limite)).map(Registro.desdeMapa).toList();
  Future<List<Registro>> obtenerRegistrosFecha(String fecha) async =>
      obtenerRegistrosPorRango('${fecha}T00:00:00', '${fecha}T23:59:59');

  // ═══════════════════════════════════════════════════════
  // JORNADAS
  // ═══════════════════════════════════════════════════════
  Future<int> insertarJornada(Jornada j) async => (await bd).insert(tJornadas, j.aMapaSql());
  Future<int> actualizarJornada(Jornada j) async =>
      (await bd).update(tJornadas, j.aMapaSql(), where: 'id=?', whereArgs: [j.id]);

  Future<Jornada?> obtenerJornadaDia(int empId, String fecha) async {
    final r = await (await bd).query(tJornadas,
        where: 'empleado_id=? AND fecha=?', whereArgs: [empId, fecha]);
    return r.isEmpty ? null : Jornada.desdeMapa(r.first);
  }
  Future<List<Jornada>> obtenerJornadasRango(String fi, String ff) async {
    final r = await (await bd).query(tJornadas,
        where: 'fecha >= ? AND fecha <= ?', whereArgs: [fi, ff],
        orderBy: 'fecha ASC, nombre_empleado ASC');
    return r.map(Jornada.desdeMapa).toList();
  }
  Future<List<Jornada>> obtenerJornadasEmpleado(int empId, String fi, String ff) async {
    final r = await (await bd).query(tJornadas,
        where: 'empleado_id=? AND fecha >= ? AND fecha <= ?',
        whereArgs: [empId, fi, ff], orderBy: 'fecha ASC');
    return r.map(Jornada.desdeMapa).toList();
  }
  Future<List<Jornada>> obtenerJornadasTodas() async =>
      (await (await bd).query(tJornadas, orderBy: 'fecha ASC')).map(Jornada.desdeMapa).toList();

  // ═══════════════════════════════════════════════════════
  // SITIOS
  // ═══════════════════════════════════════════════════════
  Future<int> insertarSitio(Sitio s) async => (await bd).insert(tSitios, s.aMapaSql());
  Future<int> actualizarSitio(Sitio s) async =>
      (await bd).update(tSitios, s.aMapaSql(), where: 'id=?', whereArgs: [s.id]);
  Future<int> eliminarSitio(int id) async =>
      (await bd).delete(tSitios, where: 'id=?', whereArgs: [id]);
  Future<List<Sitio>> obtenerSitios() async {
    final r = await (await bd).query(tSitios, where: 'activo=1', orderBy: 'nombre ASC');
    return r.map(Sitio.desdeMapa).toList();
  }

  // ═══════════════════════════════════════════════════════
  // ADMINS BOT
  // ═══════════════════════════════════════════════════════
  Future<int> insertarAdminBot(AdministradorBot a) async =>
      (await bd).insert(tAdminsBot, a.aMapaSql(), conflictAlgorithm: ConflictAlgorithm.replace);
  Future<int> actualizarAdminBot(AdministradorBot a) async =>
      (await bd).update(tAdminsBot, a.aMapaSql(), where: 'id=?', whereArgs: [a.id]);
  Future<int> eliminarAdminBot(int id) async =>
      (await bd).delete(tAdminsBot, where: 'id=?', whereArgs: [id]);
  Future<List<AdministradorBot>> obtenerAdminsBot({bool soloActivos = true}) async {
    final r = await (await bd).query(tAdminsBot,
        where: soloActivos ? 'activo=1' : null, orderBy: 'plataforma ASC, nombre ASC');
    return r.map(AdministradorBot.desdeMapa).toList();
  }
  Future<bool> esAdminAutorizado(String plataforma, String id) async {
    final r = await (await bd).query(tAdminsBot,
        where: 'plataforma=? AND plataforma_id=? AND activo=1', whereArgs: [plataforma, id]);
    return r.isNotEmpty;
  }
  Future<AdministradorBot?> obtenerAdminBot(String plataforma, String id) async {
    final r = await (await bd).query(tAdminsBot,
        where: 'plataforma=? AND plataforma_id=?', whereArgs: [plataforma, id]);
    return r.isEmpty ? null : AdministradorBot.desdeMapa(r.first);
  }

  // ═══════════════════════════════════════════════════════
  // CONFIGURACION
  // ═══════════════════════════════════════════════════════
  Future<Configuracion> obtenerConfiguracion() async {
    final r = await (await bd).query(tConfiguracion, where: 'id=1');
    return r.isEmpty ? const Configuracion() : Configuracion.desdeMapa(r.first);
  }
  Future<void> guardarConfiguracion(Configuracion c) async {
    final mapa = c.aMapaSql()..['id'] = 1;
    final db   = await bd;
    if ((await db.query(tConfiguracion, where: 'id=1')).isEmpty) {
      await db.insert(tConfiguracion, mapa);
    } else {
      await db.update(tConfiguracion, mapa, where: 'id=1');
    }
  }

  // ═══════════════════════════════════════════════════════
  // ESTADÍSTICAS
  // ═══════════════════════════════════════════════════════
  Future<int> contarEmpleadosActivos() async {
    final r = await (await bd).rawQuery('SELECT COUNT(*) as t FROM $tEmpleados WHERE activo=1');
    return r.first['t'] as int;
  }
  Future<int> contarRegistrosHoy() async {
    final hoy = DateTime.now().toIso8601String().substring(0, 10);
    final r = await (await bd).rawQuery(
        "SELECT COUNT(*) as t FROM $tRegistros WHERE timestamp LIKE ?", ['$hoy%']);
    return r.first['t'] as int;
  }
  Future<List<Map<String, dynamic>>> resumenHoy() async {
    final hoy = DateTime.now().toIso8601String().substring(0, 10);
    return (await bd).rawQuery('''
      SELECT e.nombre, e.codigo_empleado, e.activo,
             j.entrada_timestamp, j.salida_timestamp,
             j.horas_trabajadas, j.completa, j.sitio_trabajo
      FROM   $tEmpleados e
      LEFT JOIN $tJornadas j ON e.id = j.empleado_id AND j.fecha = ?
      WHERE  e.activo = 1
      ORDER  BY e.nombre ASC''', [hoy]);
  }

  // ═══════════════════════════════════════════════════════
  // SINCRONIZACIÓN
  // ═══════════════════════════════════════════════════════
  Future<int> contarPendientesSync() async {
    final r = await (await bd).rawQuery(
        'SELECT COUNT(*) as t FROM $tRegistros WHERE sync_status=0');
    return r.first['t'] as int;
  }
  Future<List<Registro>> obtenerPendientesSync() async {
    final r = await (await bd).query(tRegistros,
        where: 'sync_status=0', orderBy: 'timestamp ASC');
    return r.map(Registro.desdeMapa).toList();
  }
  Future<void> marcarSincronizado(int id) async =>
      (await bd).update(tRegistros, {'sync_status': 1}, where: 'id=?', whereArgs: [id]);
  Future<void> marcarErrorSync(int id) async =>
      (await bd).update(tRegistros, {'sync_status': 2}, where: 'id=?', whereArgs: [id]);

  // ═══════════════════════════════════════════════════════
  // BACKUP / RESTORE
  // ═══════════════════════════════════════════════════════
  Future<String> exportarBd() async {
    final origen = join(await getDatabasesPath(), _nombre);
    final dir    = Directory(join((await getDatabasesPath()).replaceAll('/databases',''), 'backups'));
    if (!await dir.exists()) await dir.create(recursive: true);
    final ts   = DateTime.now().toIso8601String().replaceAll(':','-').substring(0,19);
    final dest = join(dir.path, 'desar_backup_$ts.db');
    await File(origen).copy(dest);
    return dest;
  }
  Future<void> importarBd(String ruta) async {
    await _bd?.close(); _bd = null;
    await File(ruta).copy(join(await getDatabasesPath(), _nombre));
    _bd = await _init();
  }

  // ═══════════════════════════════════════════════════════
  // LIMPIEZA Y DUMPS SQL
  // ═══════════════════════════════════════════════════════
  Future<void> limpiarTodaLaBd() async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.execute('DELETE FROM $tJornadas');
      await txn.execute('DELETE FROM $tRegistros');
      await txn.execute('DELETE FROM $tEmpleados');
      await txn.execute("DELETE FROM $tSitios WHERE nombre != 'Principal'");
    });
  }

  String _valSql(dynamic v) => v == null ? 'NULL' :
      v is num ? '$v' : "'${v.toString().replaceAll("'", "''")}'";

  Future<String> generarSqlDump() async {
    final db  = await bd;
    final buf = StringBuffer();
    buf.writeln('-- DESAR SQL Dump  ${DateTime.now().toIso8601String()}');
    buf.writeln('PRAGMA foreign_keys = OFF;');
    for (final t in [tSitios, tConfiguracion, tEmpleados, tRegistros, tJornadas]) {
      buf.writeln('\n-- $t\nDELETE FROM $t;');
      for (final row in await db.query(t)) {
        buf.writeln('INSERT INTO $t (${row.keys.join(",")}) VALUES (${row.values.map(_valSql).join(",")});');
      }
    }
    buf.writeln('\nPRAGMA foreign_keys = ON;');
    return buf.toString();
  }

  Future<String> generarSqlDumpMovimientos() async {
    final db  = await bd;
    final buf = StringBuffer();
    buf.writeln('-- DESAR Movimientos  ${DateTime.now().toIso8601String()}');
    for (final t in [tRegistros, tJornadas]) {
      buf.writeln('\n-- $t\nDELETE FROM $t;');
      for (final row in await db.query(t)) {
        buf.writeln('INSERT INTO $t (${row.keys.join(",")}) VALUES (${row.values.map(_valSql).join(",")});');
      }
    }
    return buf.toString();
  }

  Future<void> importarSql(String sql) async {
    final db = await bd;
    await db.transaction((txn) async {
      for (final s in sql.split(';').map((e) => e.trim())
          .where((e) => e.isNotEmpty && !e.startsWith('--'))) {
        try { await txn.execute(s); } catch (e) { print('[BD] SQL: $e'); }
      }
    });
  }
}
