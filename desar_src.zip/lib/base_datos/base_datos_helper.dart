// /desar/lib/base_datos/base_datos_helper.dart
// DESAR v0.0.1-beta - Schema v3 - BD limpia, migración reconstruye tabla

import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../modelos/empleado.dart';
import '../modelos/administrador_bot.dart';
import '../modelos/registro.dart';
import '../modelos/jornada.dart';
import '../modelos/sitio.dart';
import '../modelos/configuracion.dart';

class BaseDatosHelper {
  static final BaseDatosHelper _inst = BaseDatosHelper._interno();
  static Database? _bd;

  BaseDatosHelper._interno();
  factory BaseDatosHelper() => _inst;

  static const String _nombre = 'desar.db';
  // v3: reconstruye tabla empleados para eliminar NOT NULL heredados de v1
  static const int _version = 7;

  static const String tEmpleados    = 'empleados';
  static const String tRegistros    = 'registros';
  static const String tJornadas     = 'jornadas';
  static const String tSitios       = 'sitios';
  static const String tConfiguracion = 'configuracion';

  Future<Database> get bd async {
    _bd ??= await _init();
    return _bd!;
  }

  Future<Database> _init() async {
    final ruta = join(await getDatabasesPath(), _nombre);
    return openDatabase(
      ruta,
      version: _version,
      onCreate: _crear,
      onUpgrade: _migrar,
    );
  }

  // ── Creación limpia desde cero ────────────────────────────
  Future<void> _crear(Database db, int ver) async {
    await _crearTablas(db);
    // Datos iniciales
    await db.insert(tSitios, {
      'nombre': 'Principal',
      'descripcion': 'Sitio principal',
      'activo': 1,
    });
    await db.insert(tConfiguracion,
        Configuracion().aMapaSql()..['id'] = 1);
  }

  Future<void> _crearTablas(Database db) async {
    // empleados: SOLO codigo_empleado y nombre son NOT NULL
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tEmpleados (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo_empleado      TEXT NOT NULL UNIQUE,
        nombre               TEXT NOT NULL,
        direccion            TEXT,
        ciudad               TEXT,
        estado               TEXT,
        pais                 TEXT,
        telefono             TEXT,
        telefono_emergencia  TEXT,
        fecha_nacimiento     TEXT,
        rfc                  TEXT,
        seguro_social        TEXT,
        numero_identificacion TEXT,
        puesto               TEXT,
        tipo_sangre          TEXT,
        notas                TEXT,
        foto_perfil          TEXT,
        foto_rostro_1        TEXT,
        foto_rostro_2        TEXT,
        foto_rostro_3        TEXT,
        embedding_1          TEXT,
        embedding_2          TEXT,
        embedding_3          TEXT,
        sitio_trabajo        TEXT,
        codigo_postal        TEXT,
        activo               INTEGER NOT NULL DEFAULT 1,
        fecha_registro       TEXT NOT NULL DEFAULT (datetime('now')),
        fecha_alta           TEXT,
        fecha_vencimiento    TEXT
      )''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tRegistros (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        empleado_id    INTEGER NOT NULL,
        codigo_empleado TEXT NOT NULL,
        nombre_empleado TEXT NOT NULL,
        tipo           TEXT NOT NULL,
        timestamp      TEXT NOT NULL,
        gps_lat        REAL,
        gps_lon        REAL,
        sitio_trabajo  TEXT,
        metodo         TEXT NOT NULL DEFAULT 'manual',
        notas          TEXT,
        FOREIGN KEY (empleado_id) REFERENCES $tEmpleados(id)
      )''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tJornadas (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        empleado_id     INTEGER NOT NULL,
        codigo_empleado TEXT NOT NULL,
        nombre_empleado TEXT NOT NULL,
        fecha           TEXT NOT NULL,
        entrada_timestamp TEXT,
        salida_timestamp  TEXT,
        horas_trabajadas  REAL,
        completa         INTEGER NOT NULL DEFAULT 0,
        sitio_trabajo    TEXT,
        FOREIGN KEY (empleado_id) REFERENCES $tEmpleados(id)
      )''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tSitios (
        id                    INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre                TEXT NOT NULL UNIQUE,
        descripcion           TEXT,
        gps_lat               REAL,
        gps_lon               REAL,
        geofence_radio_metros REAL,
        geofence_tipo         TEXT DEFAULT 'permitido',
        geofence_activo       INTEGER DEFAULT 0,
        activo                INTEGER NOT NULL DEFAULT 1
      )''');


    await db.execute('''
      CREATE TABLE IF NOT EXISTS administradores_bot (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        plataforma     TEXT NOT NULL,
        plataforma_id  TEXT NOT NULL,
        nombre         TEXT,
        apellido       TEXT,
        username       TEXT,
        email          TEXT,
        telefono       TEXT,
        empresa        TEXT,
        cargo          TEXT,
        notas          TEXT,
        activo         INTEGER NOT NULL DEFAULT 1,
        fecha_registro TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(plataforma, plataforma_id)
      )''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tConfiguracion (
        id                       INTEGER PRIMARY KEY DEFAULT 1,
        nombre_compania          TEXT NOT NULL DEFAULT 'Mi Compañía',
        rfc_compania             TEXT,
        direccion_compania       TEXT,
        ciudad_compania          TEXT,
        estado_compania          TEXT,
        pais_compania            TEXT,
        telefono_compania        TEXT,
        email_compania           TEXT,
        logo_compania            TEXT,
        whatsapp_api_url         TEXT,
        whatsapp_api_token       TEXT,
        whatsapp_channel_id      TEXT,
        whatsapp_phone_number_id TEXT,
        whatsapp_verify_token    TEXT,
        whatsapp_habilitado      INTEGER DEFAULT 0,
        telegram_bot_token       TEXT,
        telegram_chat_id         TEXT,
        telegram_habilitado      INTEGER DEFAULT 0,
        bot_prefijo              TEXT DEFAULT '/',
        hora_entrada_default     TEXT DEFAULT '08:00',
        hora_salida_default      TEXT DEFAULT '17:00',
        tolerancia_minutos       INTEGER DEFAULT 15,
        jornada_horas            REAL DEFAULT 8.0,
        umbral_reconocimiento    REAL DEFAULT 0.80,
        pedir_confirmacion_nuevo INTEGER DEFAULT 1,
        formato_reporte_default  TEXT DEFAULT 'excel',
        zona_horaria             TEXT DEFAULT 'America/Mexico_City',
        codigo_postal_compania   TEXT,
        facebook_page_token      TEXT,
        facebook_app_id          TEXT,
        facebook_app_secret      TEXT,
        facebook_verify_token    TEXT,
        facebook_habilitado      INTEGER DEFAULT 0
      )''');
  }

  // ── Migración: reconstruye empleados para quitar NOT NULL ──
  Future<void> _migrar(Database db, int oldVer, int newVer) async {
    // v3: reconstruir tabla empleados sin NOT NULL heredados
    if (oldVer < 7) {
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN facebook_page_token TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN facebook_app_id TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN facebook_app_secret TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN facebook_verify_token TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN facebook_habilitado INTEGER DEFAULT 0'); } catch (_) {}
      try { await db.execute('''CREATE TABLE IF NOT EXISTS administradores_bot (id INTEGER PRIMARY KEY AUTOINCREMENT, plataforma TEXT NOT NULL, plataforma_id TEXT NOT NULL, nombre TEXT, apellido TEXT, username TEXT, email TEXT, telefono TEXT, empresa TEXT, cargo TEXT, notas TEXT, activo INTEGER NOT NULL DEFAULT 1, fecha_registro TEXT NOT NULL DEFAULT (datetime(''now'')), UNIQUE(plataforma, plataforma_id))'''); } catch (_) {}
    }
    if (oldVer < 6) {
      try { await db.execute('ALTER TABLE \$tSitios ADD COLUMN geofence_radio_metros REAL'); } catch (_) {}
      try { await db.execute("ALTER TABLE \$tSitios ADD COLUMN geofence_tipo TEXT DEFAULT 'permitido'"); } catch (_) {}
      try { await db.execute('ALTER TABLE \$tSitios ADD COLUMN geofence_activo INTEGER DEFAULT 0'); } catch (_) {}
    }
    if (oldVer < 5) {
      try { await db.execute('ALTER TABLE \$tEmpleados ADD COLUMN fecha_alta TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE \$tEmpleados ADD COLUMN fecha_vencimiento TEXT'); } catch (_) {}
    }
    if (oldVer < 4) {
      // v4: add codigo_postal columns
      try { await db.execute('ALTER TABLE $tEmpleados ADD COLUMN codigo_postal TEXT'); } catch (_) {}
      try { await db.execute('ALTER TABLE $tConfiguracion ADD COLUMN codigo_postal_compania TEXT'); } catch (_) {}
      // Also run the v3 migration if needed
    }
    if (oldVer < 3) {
      try {
        // 1. Renombrar tabla vieja
        await db.execute(
            'ALTER TABLE $tEmpleados RENAME TO _empleados_old');

        // 2. Crear tabla nueva con schema correcto
        await db.execute('''
          CREATE TABLE $tEmpleados (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo_empleado      TEXT NOT NULL UNIQUE,
            nombre               TEXT NOT NULL,
            direccion            TEXT,
            ciudad               TEXT,
            estado               TEXT,
            pais                 TEXT,
            telefono             TEXT,
            telefono_emergencia  TEXT,
            fecha_nacimiento     TEXT,
            rfc                  TEXT,
            seguro_social        TEXT,
            numero_identificacion TEXT,
            puesto               TEXT,
            tipo_sangre          TEXT,
            notas                TEXT,
            foto_perfil          TEXT,
            foto_rostro_1        TEXT,
            foto_rostro_2        TEXT,
            foto_rostro_3        TEXT,
            embedding_1          TEXT,
            embedding_2          TEXT,
            embedding_3          TEXT,
            sitio_trabajo        TEXT,
            codigo_postal        TEXT,
            activo               INTEGER NOT NULL DEFAULT 1,
            fecha_registro       TEXT NOT NULL DEFAULT (datetime('now')),
            fecha_alta           TEXT,
            fecha_vencimiento    TEXT
          )''');

        // 3. Copiar datos conservando solo columnas seguras
        await db.execute('''
          INSERT INTO $tEmpleados
            (id, codigo_empleado, nombre, fecha_nacimiento,
             foto_perfil, foto_rostro_1, foto_rostro_2, foto_rostro_3,
             embedding_1, embedding_2, embedding_3,
             sitio_trabajo, activo, fecha_registro, notas,
             seguro_social, numero_identificacion)
          SELECT
            id, codigo_empleado, nombre, fecha_nacimiento,
            foto_perfil, foto_rostro_1, foto_rostro_2, foto_rostro_3,
            embedding_1, embedding_2, embedding_3,
            sitio_trabajo, activo,
            COALESCE(fecha_registro, datetime('now')),
            notas,
            seguro_social, numero_identificacion
          FROM _empleados_old
        ''');

        // 4. Eliminar tabla vieja
        await db.execute('DROP TABLE IF EXISTS _empleados_old');
        print('[BD] v3: tabla empleados reconstruida OK');
      } catch (e) {
        print('[BD] v3 migración error: $e');
      }

      // Agregar columnas nuevas a configuracion si no existen
      for (final col in [
        'ciudad_compania TEXT',
        'estado_compania TEXT',
        'pais_compania TEXT',
        'logo_compania TEXT',
        "bot_prefijo TEXT DEFAULT '/'",
      ]) {
        try {
          await db.execute(
              'ALTER TABLE $tConfiguracion ADD COLUMN $col');
        } catch (_) {}
      }
    }
  }


  // ── Cambiar codigo de empleado en todas las tablas ────────
  Future<void> renombrarCodigoEmpleado(
      String codigoViejo, String codigoNuevo) async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.update(tEmpleados, {'codigo_empleado': codigoNuevo},
          where: 'codigo_empleado=?', whereArgs: [codigoViejo]);
      await txn.update(tRegistros, {'codigo_empleado': codigoNuevo},
          where: 'codigo_empleado=?', whereArgs: [codigoViejo]);
      await txn.update(tJornadas, {'codigo_empleado': codigoNuevo},
          where: 'codigo_empleado=?', whereArgs: [codigoViejo]);
    });
    print('[BD] Codigo renombrado OK');
  }

  // ── Verificar si codigo ya existe ─────────────────────────
  Future<bool> existeCodigoEmpleado(String codigo, {int? excludeId}) async {
    final db = await bd;
    String where = 'codigo_empleado=?';
    List<dynamic> args = [codigo];
    if (excludeId != null) {
      where += ' AND id != ?';
      args.add(excludeId);
    }
    final r = await db.query(tEmpleados, where: where, whereArgs: args);
    return r.isNotEmpty;
  }

  // ═══════════════════════════════════════════════════════════
  // EMPLEADOS
  // ═══════════════════════════════════════════════════════════

  Future<int> insertarEmpleado(Empleado e) async =>
      (await bd).insert(tEmpleados, e.aMapaSql(),
          conflictAlgorithm: ConflictAlgorithm.abort);

  Future<int> actualizarEmpleado(Empleado e) async =>
      (await bd).update(tEmpleados, e.aMapaSql(),
          where: 'id=?', whereArgs: [e.id]);

  Future<int> eliminarEmpleado(int id) async =>
      (await bd).delete(tEmpleados, where: 'id=?', whereArgs: [id]);

  // Elimina empleado + todo su historial (registros y jornadas)
  Future<void> eliminarEmpleadoCompleto(int id) async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.delete(tRegistros, where: 'empleado_id=?', whereArgs: [id]);
      await txn.delete(tJornadas,  where: 'empleado_id=?', whereArgs: [id]);
      await txn.delete(tEmpleados, where: 'id=?',          whereArgs: [id]);
    });
    print('[BD] Empleado $id eliminado con todo su historial');
  }

  // Exportar BD: copia el archivo .db para compartir
  Future<String> exportarBd() async {
    final origen  = join(await getDatabasesPath(), _nombre);
    final dir     = await _dirBackup();
    final ts      = DateTime.now().toIso8601String().replaceAll(':', '-').substring(0, 19);
    final destino = join(dir, 'desar_backup_$ts.db');
    await File(origen).copy(destino);
    print('[BD] Exportada a $destino');
    return destino;
  }

  // Importar BD: reemplaza la BD activa con el archivo seleccionado
  Future<void> importarBd(String rutaArchivo) async {
    await _bd?.close();
    _bd = null;
    final destino = join(await getDatabasesPath(), _nombre);
    await File(rutaArchivo).copy(destino);
    _bd = await _init();
    print('[BD] Importada desde $rutaArchivo');
  }

  Future<String> _dirBackup() async {
    final base = await getDatabasesPath();
    final parent = base.replaceAll('/databases', '');
    final dir = Directory(join(parent, 'backups'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir.path;
  }

  Future<int> cambiarEstado(int id, int activo) async =>
      (await bd).update(tEmpleados, {'activo': activo},
          where: 'id=?', whereArgs: [id]);

  Future<List<Empleado>> obtenerTodosEmpleados() async {
    final r = await (await bd).query(tEmpleados, orderBy: 'nombre ASC');
    return r.map(Empleado.desdeMapa).toList();
  }

  Future<List<Empleado>> obtenerEmpleadosActivos() async {
    final r = await (await bd).query(tEmpleados,
        where: 'activo=1', orderBy: 'nombre ASC');
    return r.map(Empleado.desdeMapa).toList();
  }

  Future<Empleado?> obtenerEmpleadoPorCodigo(String codigo) async {
    final r = await (await bd).query(tEmpleados,
        where: 'codigo_empleado=?', whereArgs: [codigo]);
    return r.isEmpty ? null : Empleado.desdeMapa(r.first);
  }

  Future<Empleado?> obtenerEmpleadoPorId(int id) async {
    final r = await (await bd).query(tEmpleados,
        where: 'id=?', whereArgs: [id]);
    return r.isEmpty ? null : Empleado.desdeMapa(r.first);
  }

  Future<List<Empleado>> buscarEmpleados(String t) async {
    final r = await (await bd).query(tEmpleados,
        where: 'nombre LIKE ? OR codigo_empleado LIKE ? OR '
            'numero_identificacion LIKE ? OR puesto LIKE ?',
        whereArgs: ['%$t%', '%$t%', '%$t%', '%$t%'],
        orderBy: 'nombre ASC');
    return r.map(Empleado.desdeMapa).toList();
  }

  Future<List<Empleado>> obtenerEmpleadosRango(
      int idInicio, int idFin) async {
    final r = await (await bd).query(tEmpleados,
        where: 'id >= ? AND id <= ?',
        whereArgs: [idInicio, idFin],
        orderBy: 'id ASC');
    return r.map(Empleado.desdeMapa).toList();
  }

  // ═══════════════════════════════════════════════════════════
  // REGISTROS
  // ═══════════════════════════════════════════════════════════

  Future<int> insertarRegistro(Registro r) async =>
      (await bd).insert(tRegistros, r.aMapaSql());

  Future<int> actualizarRegistro(Registro r) async =>
      (await bd).update(tRegistros, r.aMapaSql(),
          where: 'id=?', whereArgs: [r.id]);

  Future<int> eliminarRegistro(int id) async =>
      (await bd).delete(tRegistros, where: 'id=?', whereArgs: [id]);

  Future<List<Registro>> obtenerRegistrosPorRango(
      String tsInicio, String tsFin) async {
    final r = await (await bd).query(tRegistros,
        where: 'timestamp >= ? AND timestamp <= ?',
        whereArgs: [tsInicio, tsFin],
        orderBy: 'timestamp ASC');
    return r.map(Registro.desdeMapa).toList();
  }

  Future<List<Registro>> obtenerRegistrosTodos() async {
    final r = await (await bd).query(tRegistros,
        orderBy: 'timestamp ASC');
    return r.map(Registro.desdeMapa).toList();
  }

  Future<List<Registro>> obtenerRegistrosPorEmpleado(int empId) async {
    final r = await (await bd).query(tRegistros,
        where: 'empleado_id=?',
        whereArgs: [empId],
        orderBy: 'timestamp DESC');
    return r.map(Registro.desdeMapa).toList();
  }

  Future<Registro?> obtenerUltimoRegistro(int empId) async {
    final r = await (await bd).query(tRegistros,
        where: 'empleado_id=?',
        whereArgs: [empId],
        orderBy: 'timestamp DESC',
        limit: 1);
    return r.isEmpty ? null : Registro.desdeMapa(r.first);
  }

  // Returns last N registrations across all employees (for live strip)
  Future<List<Registro>> obtenerUltimosRegistros({int limite = 5}) async {
    final r = await (await bd).query(tRegistros,
        orderBy: 'timestamp DESC', limit: limite);
    return r.map(Registro.desdeMapa).toList();
  }

  Future<List<Registro>> obtenerRegistrosFecha(String fecha) async =>
      obtenerRegistrosPorRango(
          '${fecha}T00:00:00', '${fecha}T23:59:59');

  // ═══════════════════════════════════════════════════════════
  // JORNADAS
  // ═══════════════════════════════════════════════════════════

  Future<int> insertarJornada(Jornada j) async =>
      (await bd).insert(tJornadas, j.aMapaSql());

  Future<int> actualizarJornada(Jornada j) async =>
      (await bd).update(tJornadas, j.aMapaSql(),
          where: 'id=?', whereArgs: [j.id]);

  Future<Jornada?> obtenerJornadaDia(int empId, String fecha) async {
    final r = await (await bd).query(tJornadas,
        where: 'empleado_id=? AND fecha=?',
        whereArgs: [empId, fecha]);
    return r.isEmpty ? null : Jornada.desdeMapa(r.first);
  }

  Future<List<Jornada>> obtenerJornadasRango(
      String fi, String ff) async {
    final r = await (await bd).query(tJornadas,
        where: 'fecha >= ? AND fecha <= ?',
        whereArgs: [fi, ff],
        orderBy: 'fecha ASC, nombre_empleado ASC');
    return r.map(Jornada.desdeMapa).toList();
  }

  Future<List<Jornada>> obtenerJornadasEmpleado(
      int empId, String fi, String ff) async {
    final r = await (await bd).query(tJornadas,
        where: 'empleado_id=? AND fecha >= ? AND fecha <= ?',
        whereArgs: [empId, fi, ff],
        orderBy: 'fecha ASC');
    return r.map(Jornada.desdeMapa).toList();
  }

  Future<List<Jornada>> obtenerJornadasTodas() async {
    final r =
        await (await bd).query(tJornadas, orderBy: 'fecha ASC');
    return r.map(Jornada.desdeMapa).toList();
  }

  // ═══════════════════════════════════════════════════════════
  // SITIOS
  // ═══════════════════════════════════════════════════════════

  Future<int> insertarSitio(Sitio s) async =>
      (await bd).insert(tSitios, s.aMapaSql());

  Future<int> actualizarSitio(Sitio s) async =>
      (await bd).update(tSitios, s.aMapaSql(),
          where: 'id=?', whereArgs: [s.id]);

  Future<int> eliminarSitio(int id) async =>
      (await bd).delete(tSitios, where: 'id=?', whereArgs: [id]);

  Future<List<Sitio>> obtenerSitios() async {
    final r = await (await bd).query(tSitios,
        where: 'activo=1', orderBy: 'nombre ASC');
    return r.map(Sitio.desdeMapa).toList();
  }

  // ═══════════════════════════════════════════════════════════
  // CONFIGURACION
  // ═══════════════════════════════════════════════════════════

  Future<Configuracion> obtenerConfiguracion() async {
    final r =
        await (await bd).query(tConfiguracion, where: 'id=1');
    if (r.isEmpty) return const Configuracion();
    return Configuracion.desdeMapa(r.first);
  }

  Future<void> guardarConfiguracion(Configuracion c) async {
    final mapa = c.aMapaSql()..['id'] = 1;
    final db = await bd;
    final existe =
        await db.query(tConfiguracion, where: 'id=1');
    if (existe.isEmpty) {
      await db.insert(tConfiguracion, mapa);
    } else {
      await db.update(tConfiguracion, mapa, where: 'id=1');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ESTADÍSTICAS
  // ═══════════════════════════════════════════════════════════

  Future<int> contarEmpleadosActivos() async {
    final r = await (await bd).rawQuery(
        'SELECT COUNT(*) as t FROM $tEmpleados WHERE activo=1');
    return r.first['t'] as int;
  }

  Future<int> contarRegistrosHoy() async {
    final hoy =
        DateTime.now().toIso8601String().substring(0, 10);
    final r = await (await bd).rawQuery(
        "SELECT COUNT(*) as t FROM $tRegistros WHERE timestamp LIKE ?",
        ['$hoy%']);
    return r.first['t'] as int;
  }

  Future<List<Map<String, dynamic>>> resumenHoy() async {
    final hoy =
        DateTime.now().toIso8601String().substring(0, 10);
    return (await bd).rawQuery('''
      SELECT e.nombre, e.codigo_empleado, e.activo,
             j.entrada_timestamp, j.salida_timestamp,
             j.horas_trabajadas, j.completa, j.sitio_trabajo
      FROM $tEmpleados e
      LEFT JOIN $tJornadas j
             ON e.id=j.empleado_id AND j.fecha=?
      WHERE e.activo=1
      ORDER BY e.nombre ASC
    ''', [hoy]);
  }

  // ── Borrar TODOS los datos (BD limpia, tablas vacías) ──────
  Future<void> limpiarTodaLaBd() async {
    final db = await bd;
    await db.transaction((txn) async {
      await txn.execute('DELETE FROM $tJornadas');
      await txn.execute('DELETE FROM $tRegistros');
      await txn.execute('DELETE FROM $tEmpleados');
      await txn.execute(
          "DELETE FROM $tSitios WHERE nombre != 'Principal'");
    });
    print('[BD] Todos los datos borrados');
  }

  // ── SQL Dump ───────────────────────────────────────────────
  Future<String> generarSqlDump() async {
    final db = await bd;
    final buf = StringBuffer();
    buf.writeln('-- DESAR SQL Dump v$_version');
    buf.writeln('-- ${DateTime.now().toIso8601String()}');
    buf.writeln('PRAGMA foreign_keys = OFF;');
    for (final tabla in [
      tSitios, tConfiguracion, tEmpleados, tRegistros, tJornadas
    ]) {
      buf.writeln('\n-- $tabla');
      buf.writeln('DELETE FROM $tabla;');
      final rows = await db.query(tabla);
      for (final row in rows) {
        final cols = row.keys.join(', ');
        final vals = row.values.map((v) {
          if (v == null) return 'NULL';
          if (v is int || v is double) return '$v';
          return "'${v.toString().replaceAll("'", "''")}'";
        }).join(', ');
        buf.writeln('INSERT INTO $tabla ($cols) VALUES ($vals);');
      }
    }
    buf.writeln('\nPRAGMA foreign_keys = ON;');
    return buf.toString();
  }

  Future<String> generarSqlDumpMovimientos() async {
    final db = await bd;
    final buf = StringBuffer();
    buf.writeln('-- DESAR Movimientos Dump');
    buf.writeln('-- ${DateTime.now().toIso8601String()}');
    for (final tabla in [tRegistros, tJornadas]) {
      buf.writeln('\n-- $tabla');
      buf.writeln('DELETE FROM $tabla;');
      final rows = await db.query(tabla);
      for (final row in rows) {
        final cols = row.keys.join(', ');
        final vals = row.values.map((v) {
          if (v == null) return 'NULL';
          if (v is int || v is double) return '$v';
          return "'${v.toString().replaceAll("'", "''")}'";
        }).join(', ');
        buf.writeln('INSERT INTO $tabla ($cols) VALUES ($vals);');
      }
    }
    return buf.toString();
  }

  Future<void> importarSql(String sql) async {
    final db = await bd;
    final stmts = sql
        .split(';')
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty && !s.startsWith('--'));
    await db.transaction((txn) async {
      for (final stmt in stmts) {
        try {
          await txn.execute(stmt);
        } catch (e) {
          print('[BD] Error SQL: $e');
        }
      }
    });
  }
}
