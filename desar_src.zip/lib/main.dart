// /desar/lib/main.dart
// DESAR - Sistema de Control de Asistencias v0.0.1-beta
// (c) 2026 zSoft - Alex Rogelio Rodriguez Castañeda

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'servicios/servicio_reconocimiento_facial.dart';
import 'servicios/servicio_bot.dart';
import 'servicios/servicio_licencia.dart';
import 'base_datos/base_datos_helper.dart';
import 'pantallas/pantalla_principal.dart';
import 'pantallas/pantalla_licencia.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await initializeDateFormatting('es_MX', null);

  // Inicializar licencia
  final licencia = ServicioLicencia();
  await licencia.inicializar();

  // Cargar modelo facial
  final facial = ServicioReconocimientoFacial();
  await facial.cargarModelo();

  // Iniciar bot Telegram si configurado
  final bd = BaseDatosHelper();
  final cfg = await bd.obtenerConfiguracion();
  if (cfg.telegramHabilitado && (cfg.telegramBotToken ?? '').isNotEmpty) {
    ServicioBot().iniciarTelegram(cfg);
  }

  runApp(const DesarApp());
}

class DesarApp extends StatelessWidget {
  const DesarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DESAR',
      debugShowCheckedModeBanner: false,
      locale: const Locale('es', 'MX'),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1565C0), brightness: Brightness.light),
        appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF1565C0),
            foregroundColor: Colors.white,
            elevation: 2,
            centerTitle: false),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1976D2),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10))),
        ),
        inputDecorationTheme: InputDecorationTheme(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12)),
        cardTheme: CardThemeData(
            elevation: 2,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10))),
        switchTheme: SwitchThemeData(
          thumbColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected) ? const Color(0xFF1976D2) : null),
          trackColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected) ? const Color(0xFFBBDEFB) : null),
        ),
      ),
      home: const _SplashLicencia(),
    );
  }
}

// Verifica licencia antes de mostrar la app
class _SplashLicencia extends StatefulWidget {
  const _SplashLicencia();
  @override
  State<_SplashLicencia> createState() => _SplashLicenciaState();
}

class _SplashLicenciaState extends State<_SplashLicencia> {
  @override
  void initState() {
    super.initState();
    _verificar();
  }

  Future<void> _verificar() async {
    await Future.delayed(const Duration(milliseconds: 500));
    final estado = await ServicioLicencia().obtenerEstado();

    if (!mounted) return;

    if (estado.estaExpirada) {
      // Licencia expirada: mostrar pantalla bloqueante
      Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => PantallaLicencia(
            estado: estado,
            onContinuar: () {}, // no puede continuar si expirada
            soloAviso: false,
          )));
    } else if (estado.advertencia) {
      // Quedan pocos dias: mostrar aviso pero dejar continuar
      Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => PantallaLicencia(
            estado: estado,
            onContinuar: () => Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (_) => const PantallaPrincipal())),
            soloAviso: true,
          )));
    } else {
      // OK: ir directo
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const PantallaPrincipal()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF1565C0),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.fingerprint, color: Colors.white, size: 80),
          SizedBox(height: 16),
          Text('DESAR', style: TextStyle(color: Colors.white, fontSize: 32,
              fontWeight: FontWeight.bold, letterSpacing: 4)),
          SizedBox(height: 8),
          Text('v0.0.1-beta', style: TextStyle(color: Colors.white54, fontSize: 12)),
          SizedBox(height: 32),
          CircularProgressIndicator(color: Colors.white54, strokeWidth: 2),
        ]),
      ),
    );
  }
}
