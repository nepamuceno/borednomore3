// /desar/lib/pantallas/movimientos/pantalla_movimientos.dart
// Lista, consulta, edicion y eliminacion de registros de asistencia

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../modelos/registro.dart';

class PantallaMovimientos extends StatefulWidget {
  const PantallaMovimientos({super.key});
  @override
  State<PantallaMovimientos> createState() => _PantallaMovimientosState();
}

class _PantallaMovimientosState extends State<PantallaMovimientos> {
  final BaseDatosHelper _bd = BaseDatosHelper();
  final DateFormat _fmtFecha = DateFormat('yyyy-MM-dd');
  final DateFormat _fmtHora = DateFormat('HH:mm:ss');

  List<Registro> _registros = [];
  bool _cargando = true;
  DateTime _fechaFiltro = DateTime.now();

  @override
  void initState() { super.initState(); _cargar(); }

  Future<void> _cargar() async {
    setState(() => _cargando = true);
    final fecha = _fmtFecha.format(_fechaFiltro);
    final lista = await _bd.obtenerRegistrosFecha(fecha);
    setState(() { _registros = lista; _cargando = false; });
  }

  Future<void> _selFecha() async {
    final f = await showDatePicker(context: context,
        initialDate: _fechaFiltro, firstDate: DateTime(2020), lastDate: DateTime.now());
    if (f != null) { setState(() => _fechaFiltro = f); _cargar(); }
  }

  Future<void> _confirmarEliminar(Registro r) async {
    final ok = await showDialog<bool>(context: context,
        builder: (_) => AlertDialog(
          title: const Text('Eliminar Registro'),
          content: Text('¿Eliminar ${r.tipo} de ${r.nombreEmpleado}?\nFecha: ${r.timestamp}'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            TextButton(onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Eliminar')),
          ],
        ));
    if (ok == true) { await _bd.eliminarRegistro(r.id!); _cargar(); }
  }

  void _mostrarDetalle(Registro r) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Row(children: [
        Icon(r.esEntrada ? Icons.login : Icons.logout,
            color: r.esEntrada ? Colors.green : Colors.blue),
        const SizedBox(width: 8),
        Text(r.tipo.toUpperCase()),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        _detRow('Empleado', r.nombreEmpleado),
        _detRow('Código', r.codigoEmpleado),
        _detRow('Fecha', r.timestamp.substring(0, 10)),
        _detRow('Hora', _fmtHora.format(r.fechaHora)),
        _detRow('Método', r.metodo),
        _detRow('Sitio', r.sitioTrabajo ?? '---'),
        if (r.gpsLat != null)
          _detRow('GPS', '${r.gpsLat!.toStringAsFixed(5)}, ${r.gpsLon!.toStringAsFixed(5)}'),
        if (r.notas != null) _detRow('Notas', r.notas!),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
        TextButton(
            onPressed: () { Navigator.pop(context); _confirmarEliminar(r); },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar')),
      ],
    ));
  }

  Widget _detRow(String label, String val) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 70, child: Text('$label:', style: const TextStyle(color: Colors.grey, fontSize: 12))),
      Expanded(child: Text(val, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500))),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: const Text('Movimientos'),
        actions: [
          IconButton(icon: const Icon(Icons.calendar_today), onPressed: _selFecha, tooltip: 'Cambiar fecha'),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _cargar),
        ],
      ),
      body: Column(children: [
        // Barra de fecha seleccionada
        Container(
          color: const Color(0xFF1976D2),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: GestureDetector(
            onTap: _selFecha,
            child: Row(children: [
              const Icon(Icons.calendar_today, color: Colors.white70, size: 16),
              const SizedBox(width: 8),
              Text(_fmtFecha.format(_fechaFiltro),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              const Spacer(),
              Text('${_registros.length} registros',
                  style: const TextStyle(color: Colors.white70, fontSize: 13)),
            ]),
          ),
        ),
        Expanded(
          child: _cargando
              ? const Center(child: CircularProgressIndicator())
              : _registros.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.event_busy, size: 60, color: Colors.grey),
                      const SizedBox(height: 10),
                      Text('Sin registros el ${_fmtFecha.format(_fechaFiltro)}',
                          style: const TextStyle(color: Colors.grey)),
                    ]))
                  : ListView.builder(
                      itemCount: _registros.length,
                      itemBuilder: (_, i) => _item(_registros[i])),
        ),
      ]),
    );
  }

  Widget _item(Registro r) {
    final color = r.esEntrada ? Colors.green : const Color(0xFF1565C0);
    final ico = r.esEntrada ? Icons.login : Icons.logout;
    return Dismissible(
      key: Key('r${r.id}'),
      direction: DismissDirection.endToStart,
      background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
          color: Colors.red, child: const Icon(Icons.delete, color: Colors.white)),
      confirmDismiss: (_) async { await _confirmarEliminar(r); return false; },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: ListTile(
          leading: Container(width: 42, height: 42,
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(ico, color: color, size: 22)),
          title: Text(r.nombreEmpleado, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          subtitle: Text('${r.codigoEmpleado} • ${r.metodo} • ${r.sitioTrabajo ?? "---"}',
              style: const TextStyle(fontSize: 11)),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(r.tipo.toUpperCase(),
                style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11)),
            Text(_fmtHora.format(r.fechaHora),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ]),
          onTap: () => _mostrarDetalle(r),
        ),
      ),
    );
  }
}
