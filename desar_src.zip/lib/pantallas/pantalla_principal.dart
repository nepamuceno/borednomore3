// /desar/lib/pantallas/pantalla_principal.dart
// Pantalla principal DESAR - reloj en vivo, responsive, logo compañia

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../base_datos/base_datos_helper.dart';
import '../modelos/configuracion.dart';
import 'asistencia/pantalla_registrar_asistencia.dart';
import 'empleados/pantalla_lista_empleados.dart';
import 'movimientos/pantalla_movimientos.dart';
import 'reportes/pantalla_reportes.dart';
import 'admin/pantalla_admin.dart';
import 'pantalla_creditos.dart';
import 'pantalla_licencia.dart';
import '../servicios/servicio_licencia.dart';

class PantallaPrincipal extends StatefulWidget {
  const PantallaPrincipal({super.key});
  @override
  State<PantallaPrincipal> createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal>
    with WidgetsBindingObserver {
  final BaseDatosHelper _bd = BaseDatosHelper();

  // Datos del dashboard
  int _totalEmp = 0, _regHoy = 0, _presentes = 0, _salidas = 0;
  List<Map<String, dynamic>> _resumen = [];
  bool _cargando = true;
  EstadoLicencia? _estadoLicencia;
  Configuracion? _cfg;

  // Reloj en vivo
  Timer? _timerReloj;
  Timer? _timerStats;
  DateTime _ahora = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _iniciarReloj();
    _cargar();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timerReloj?.cancel();
    _timerStats?.cancel();
    super.dispose();
  }

  // Actualizar datos cuando vuelve al foco
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _cargar();
    }
  }

  void _iniciarReloj() {
    _timerReloj = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _ahora = DateTime.now());
    });
    // Refrescar estadísticas cada 30 segundos automáticamente
    _timerStats = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) _cargar();
    });
  }

  Future<void> _cargar() async {
    setState(() => _cargando = true);
    final emp  = await _bd.contarEmpleadosActivos();
    final reg  = await _bd.contarRegistrosHoy();
    final res  = await _bd.resumenHoy();
    final pres = res.where((r) => r['entrada_timestamp'] != null && r['salida_timestamp'] == null).length;
    final sal  = res.where((r) => r['salida_timestamp'] != null).length;
    final lic  = await ServicioLicencia().obtenerEstado();
    final cfg  = await _bd.obtenerConfiguracion();
    if (mounted) {
      setState(() {
        _totalEmp = emp; _regHoy = reg; _resumen = res;
        _presentes = pres; _salidas = sal;
        _estadoLicencia = lic; _cfg = cfg;
        _cargando = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isLandscape = size.width > size.height;

    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: _buildAppBar(),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _cargar,
              child: isLandscape ? _layoutLandscape() : _layoutPortrait(),
            ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF1565C0),
      foregroundColor: Colors.white,
      title: Row(
        children: [
          // Logo si está definido
          if (_cfg?.logoCompania != null)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: Image.file(
                  File(_cfg!.logoCompania!),
                  width: 32, height: 32,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ),
          Flexible(
            child: Text(
              _cfg?.nombreCompania != null &&
                      _cfg!.nombreCompania != 'Mi Compañía'
                  ? _cfg!.nombreCompania
                  : 'DESAR',
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 4),
          const Text('v0.0.1-β',
              style: TextStyle(fontSize: 9, color: Colors.white38)),
        ],
      ),
      actions: [
        IconButton(
            icon: const Icon(Icons.refresh, size: 20),
            onPressed: _cargar,
            tooltip: 'Actualizar'),
        IconButton(
            icon: const Icon(Icons.admin_panel_settings, size: 20),
            onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const PantallaAdmin()))
                .then((_) => _cargar()),
            tooltip: 'Admin'),
      ],
    );
  }

  // ── Layout portrait (vertical) ────────────────────────────
  Widget _layoutPortrait() {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_estadoLicencia != null && !_estadoLicencia!.esCompleta)
            _bannerLicencia(),
          _tarjetaReloj(),
          const SizedBox(height: 12),
          _statsRow(),
          const SizedBox(height: 16),
          _labelSec('Registrar Asistencia'),
          const SizedBox(height: 8),
          _botonesMetodo(),
          const SizedBox(height: 16),
          _labelSec('Gestión'),
          const SizedBox(height: 8),
          _botonesGestion(),
          const SizedBox(height: 16),
          _labelSec('Resumen de Hoy'),
          const SizedBox(height: 8),
          _listaResumen(),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  // ── Layout landscape (horizontal) ─────────────────────────
  Widget _layoutLandscape() {
    return Row(
      children: [
        // Columna izquierda: reloj + stats + botones
        Expanded(
          flex: 4,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(10),
            child: Column(children: [
              if (_estadoLicencia != null && !_estadoLicencia!.esCompleta)
                _bannerLicencia(),
              _tarjetaReloj(compacto: true),
              const SizedBox(height: 10),
              _statsRow(),
              const SizedBox(height: 12),
              _labelSec('Registrar'),
              const SizedBox(height: 6),
              _botonesMetodo(),
              const SizedBox(height: 12),
              _labelSec('Gestión'),
              const SizedBox(height: 6),
              _botonesGestion(),
            ]),
          ),
        ),
        // Separador
        Container(width: 1, color: Colors.grey.shade300),
        // Columna derecha: resumen del dia
        Expanded(
          flex: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
                child: _labelSec('Resumen del Día'),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: _listaResumen(),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _bannerLicencia() {
    final color = _estadoLicencia!.advertencia
        ? const Color(0xFFE53935)
        : const Color(0xFFF57C00);
    return GestureDetector(
      onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => PantallaLicencia(
                        estado: _estadoLicencia!,
                        onContinuar: () {
                          Navigator.pop(context);
                          _cargar();
                        },
                      )))
          .then((_) => _cargar()),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(8)),
        child: Row(children: [
          const Icon(Icons.warning_amber, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Expanded(
              child: Text(_estadoLicencia!.mensaje,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold))),
          const Text('ACTIVAR →',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }

  Widget _tarjetaReloj({bool compacto = false}) {
    final fmtFecha = DateFormat('EEEE d MMM yyyy', 'es_MX');
    final fmtHora  = DateFormat('HH:mm', 'es_MX');
    final fmtSeg   = DateFormat('ss', 'es_MX');

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(compacto ? 12 : 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [Color(0xFF1565C0), Color(0xFF1976D2)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(fmtFecha.format(_ahora),
                style: TextStyle(
                    color: Colors.white70,
                    fontSize: compacto ? 10 : 12)),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(fmtHora.format(_ahora),
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: compacto ? 32 : 42,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2)),
                const SizedBox(width: 4),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(fmtSeg.format(_ahora),
                      style: TextStyle(
                          color: Colors.white54,
                          fontSize: compacto ? 14 : 18,
                          fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ]),
        ),
        const Icon(Icons.fingerprint, color: Colors.white24, size: 50),
      ]),
    );
  }

  Widget _statsRow() {
    return Row(children: [
      Expanded(child: _stat('Activos', '$_totalEmp', Icons.people, const Color(0xFF1976D2))),
      const SizedBox(width: 8),
      Expanded(child: _stat('Presentes', '$_presentes', Icons.login, const Color(0xFF388E3C))),
      const SizedBox(width: 8),
      Expanded(child: _stat('Salidas', '$_salidas', Icons.logout, const Color(0xFFE53935))),
      const SizedBox(width: 8),
      Expanded(child: _stat('Hoy', '$_regHoy', Icons.fact_check, const Color(0xFFF57C00))),
    ]);
  }

  Widget _stat(String label, String val, IconData ico, Color color) =>
      Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4)]),
        child: Column(children: [
          Icon(ico, color: color, size: 20),
          const SizedBox(height: 4),
          FittedBox(
            child: Text(val,
                style: TextStyle(
                    fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          ),
          FittedBox(
            child: Text(label,
                style: const TextStyle(fontSize: 9, color: Colors.grey)),
          ),
        ]),
      );

  Widget _botonesMetodo() {
    return Row(children: [
      Expanded(child: _botonMetodo('QR', Icons.qr_code_scanner,
          const Color(0xFF1976D2), 'qr')),
      const SizedBox(width: 8),
      Expanded(child: _botonMetodo('Facial', Icons.face_retouching_natural,
          const Color(0xFF7B1FA2), 'rostro')),
      const SizedBox(width: 8),
      Expanded(child: _botonMetodo('Manual', Icons.keyboard,
          const Color(0xFF00838F), 'manual')),
    ]);
  }

  Widget _botonMetodo(String label, IconData ico, Color color, String metodo) =>
      GestureDetector(
        onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        PantallaRegistrarAsistencia(metodo: metodo)))
            .then((_) => _cargar()),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                    color: color.withOpacity(0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 3))
              ]),
          child: Column(children: [
            Icon(ico, color: Colors.white, size: 26),
            const SizedBox(height: 4),
            FittedBox(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(label,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          ]),
        ),
      );

  Widget _botonesGestion() {
    final botones = [
      ('Empleados', Icons.badge, const Color(0xFF388E3C),
          () => Navigator.push(context,
                  MaterialPageRoute(
                      builder: (_) => const PantallaListaEmpleados()))
              .then((_) => _cargar())),
      ('Movimientos', Icons.swap_vert, const Color(0xFFF57C00),
          () => Navigator.push(context,
                  MaterialPageRoute(
                      builder: (_) => const PantallaMovimientos()))
              .then((_) => _cargar())),
      ('Reportes', Icons.bar_chart, const Color(0xFF5C6BC0),
          () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const PantallaReportes()))),
      ('Créditos', Icons.info_outline, const Color(0xFF546E7A),
          () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const PantallaCreditos()))),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: botones.map((b) {
        return SizedBox(
          width: (MediaQuery.of(context).size.width - 40) / 2,
          child: _botonGestion(b.$1, b.$2, b.$3, b.$4),
        );
      }).toList(),
    );
  }

  Widget _botonGestion(
      String label, IconData ico, Color color, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.2)),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.04), blurRadius: 3)
              ]),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(ico, color: color, size: 18),
            const SizedBox(width: 6),
            Flexible(
              child: Text(label,
                  style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontSize: 13),
                  overflow: TextOverflow.ellipsis),
            ),
          ]),
        ),
      );

  Widget _labelSec(String t) => Text(t,
      style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Color(0xFF1565C0)));

  Widget _listaResumen() {
    if (_resumen.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(12)),
        child: const Center(
            child: Text('Sin registros hoy',
                style: TextStyle(color: Colors.grey))),
      );
    }
    final fmt = DateFormat('HH:mm');
    return Column(
      children: _resumen.map((r) {
        final tieneEnt = r['entrada_timestamp'] != null;
        final tieneSal = r['salida_timestamp'] != null;
        final dotColor = tieneSal
            ? Colors.grey
            : (tieneEnt ? Colors.green : Colors.red);
        return Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.03), blurRadius: 3)
              ]),
          child: Row(children: [
            Container(
                width: 8,
                height: 8,
                decoration:
                    BoxDecoration(shape: BoxShape.circle, color: dotColor)),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r['nombre'] ?? '',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 12),
                        overflow: TextOverflow.ellipsis),
                    Text(r['codigo_empleado'] ?? '',
                        style:
                            const TextStyle(color: Colors.grey, fontSize: 10)),
                  ]),
            ),
            if (tieneEnt)
              Text(
                  fmt.format(DateTime.parse(r['entrada_timestamp'])),
                  style: const TextStyle(
                      color: Colors.green,
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
            if (tieneSal) ...[
              const Text(' → ',
                  style: TextStyle(color: Colors.grey, fontSize: 10)),
              Text(
                  fmt.format(DateTime.parse(r['salida_timestamp'])),
                  style: const TextStyle(
                      color: Colors.red,
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
            ],
          ]),
        );
      }).toList(),
    );
  }
}
