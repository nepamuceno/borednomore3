// /desar/lib/pantallas/pantalla_creditos.dart
// Créditos DESAR v0.0.1-beta - diseño profesional sin overflow

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PantallaCreditos extends StatelessWidget {
  const PantallaCreditos({super.key});

  static const String _version = '0.0.1-beta';
  static const String _autor   = 'Alex Rogelio Rodriguez Castañeda';
  static const String _empresa = 'zSoft';
  static const String _email   = 'zzerver@gmail.com';
  static const int    _anio    = 2026;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: const Text('Acerca de DESAR'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(children: [

          // ── Header azul ──────────────────────────────────────
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xFF1565C0),
              borderRadius: BorderRadius.only(
                bottomLeft:  Radius.circular(32),
                bottomRight: Radius.circular(32),
              ),
            ),
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 36),
            child: Column(children: [
              Container(
                width: 88, height: 88,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                ),
                child: const Icon(Icons.fingerprint, color: Colors.white, size: 52),
              ),
              const SizedBox(height: 14),
              const Text('DESAR',
                  style: TextStyle(
                    fontSize: 32, fontWeight: FontWeight.bold,
                    color: Colors.white, letterSpacing: 6,
                  )),
              const SizedBox(height: 4),
              const Text(
                'Sistema de Control de Asistencias',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'Versión $_version',
                  style: const TextStyle(color: Colors.white60, fontSize: 11),
                ),
              ),
            ]),
          ),

          // ── Contenido ────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [

              // Autor
              _seccion('Desarrollo', [
                _fila(context, Icons.person_outline, 'Autor', _autor),
                _divider(),
                _fila(context, Icons.business_outlined, 'Empresa', _empresa),
                _divider(),
                _filaCopiable(context, Icons.email_outlined, 'Contacto', _email),
              ]),
              const SizedBox(height: 14),

              // Tecnologías
              _seccion('Tecnologías', [
                _filaSimple(Icons.phone_android, 'Plataforma', 'Flutter / Dart — Android'),
                _divider(),
                _filaSimple(Icons.storage, 'Base de datos', 'SQLite (local, sin internet)'),
                _divider(),
                _filaSimple(Icons.face_retouching_natural, 'Reconocimiento facial', 'FaceNet + ML Kit'),
                _divider(),
                _filaSimple(Icons.qr_code_scanner, 'Escáner QR', 'Mobile Scanner (offline)'),
                _divider(),
                _filaSimple(Icons.location_on_outlined, 'GPS', 'Geolocator'),
              ]),
              const SizedBox(height: 14),

              // Funcionalidades
              _seccion('Funcionalidades', [
                _chip('✓ Registro facial, QR y manual'),
                _chip('✓ Reportes Excel y PDF'),
                _chip('✓ Gafetes CR80 imprimibles'),
                _chip('✓ Bot Telegram / WhatsApp'),
                _chip('✓ Geofences por sitio'),
                _chip('✓ Control de vigencias'),
                _chip('✓ Exportar / importar BD'),
                _chip('✓ 100% offline'),
              ]),
              const SizedBox(height: 14),

              // Licencia
              _seccion('Licencia', [
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text(
                    'Para adquirir la licencia completa envíe un correo '
                    'indicando el número de dispositivos requeridos.',
                    style: TextStyle(fontSize: 13, color: Colors.black87, height: 1.5),
                  ),
                ),
                _divider(),
                _filaCopiable(context, Icons.email_outlined, 'Email', _email),
              ]),
              const SizedBox(height: 20),

              // Copyright
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF1565C0).withOpacity(0.07),
                      const Color(0xFF1976D2).withOpacity(0.04),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: const Color(0xFF1565C0).withOpacity(0.18)),
                ),
                child: Column(children: [
                  const Icon(Icons.copyright,
                      color: Color(0xFF1565C0), size: 20),
                  const SizedBox(height: 8),
                  Text(
                    'Copyright © $_anio  $_autor',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: Color(0xFF1565C0),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$_empresa — Todos los derechos reservados',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Este software es propiedad exclusiva del autor. '
                    'Queda prohibida su reproducción, distribución '
                    'o modificación sin autorización expresa por escrito.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 10.5, color: Colors.grey[500], height: 1.5),
                  ),
                ]),
              ),
              const SizedBox(height: 28),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _seccion(String titulo, List<Widget> hijos) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(titulo,
          style: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.bold,
              color: Color(0xFF1565C0), letterSpacing: 1)),
      const SizedBox(height: 6),
      Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: Colors.grey.shade200)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: hijos),
        ),
      ),
    ],
  );

  Widget _fila(BuildContext context, IconData ico, String label, String valor) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(ico, color: const Color(0xFF1976D2), size: 18),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 10, color: Colors.grey,
                      fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              const SizedBox(height: 2),
              Text(valor,
                  style: const TextStyle(fontSize: 13, color: Colors.black87)),
            ],
          )),
        ]),
      );

  Widget _filaSimple(IconData ico, String label, String valor) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(children: [
          Icon(ico, color: const Color(0xFF1976D2), size: 18),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(fontSize: 10, color: Colors.grey,
                      fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              const SizedBox(height: 2),
              Text(valor, style: const TextStyle(fontSize: 13)),
            ],
          )),
        ]),
      );

  Widget _filaCopiable(
      BuildContext context, IconData ico, String label, String valor) =>
      GestureDetector(
        onTap: () {
          Clipboard.setData(ClipboardData(text: valor));
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Copiado: $valor'),
              duration: const Duration(seconds: 1)));
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            Icon(ico, color: const Color(0xFF1976D2), size: 18),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(fontSize: 10, color: Colors.grey,
                        fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                const SizedBox(height: 2),
                Row(children: [
                  Flexible(child: Text(valor,
                      style: const TextStyle(
                          fontSize: 13,
                          color: Color(0xFF1976D2),
                          decoration: TextDecoration.underline))),
                  const SizedBox(width: 6),
                  const Icon(Icons.copy, color: Colors.grey, size: 13),
                ]),
              ],
            )),
          ]),
        ),
      );

  Widget _chip(String texto) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      const SizedBox(width: 2),
      Text(texto,
          style: const TextStyle(fontSize: 13, color: Colors.black87, height: 1.4)),
    ]),
  );

  Widget _divider() => Divider(height: 1, color: Colors.grey.shade100);
}
