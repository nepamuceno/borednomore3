// /desar/lib/pantallas/admin/pantalla_admin.dart
// Panel de administracion: compañia, WhatsApp, Telegram, jornada, reconocimiento

import 'dart:io';
import '../../servicios/servicio_gps.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'pantalla_sonidos.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../modelos/administrador_bot.dart';
import '../../modelos/configuracion.dart';
import '../../modelos/sitio.dart';

class PantallaAdmin extends StatefulWidget {
  const PantallaAdmin({super.key});
  @override
  State<PantallaAdmin> createState() => _PantallaAdminState();
}

class _PantallaAdminState extends State<PantallaAdmin>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final BaseDatosHelper _bd = BaseDatosHelper();

  // Configuracion
  final _ctrlNombreCia = TextEditingController();
  final _ctrlRfc = TextEditingController();
  final _ctrlDireccion = TextEditingController();
  final _ctrlTelefono = TextEditingController();
  final _ctrlEmail = TextEditingController();
  final _ctrlCiudadCia = TextEditingController();
  final _ctrlEstadoCia = TextEditingController();
  final _ctrlPaisCia = TextEditingController();
  final _ctrlCpCia = TextEditingController();
  // Bot prefijo
  final _ctrlBotPrefijo = TextEditingController();
  // WhatsApp
  final _ctrlWaUrl = TextEditingController();
  final _ctrlWaToken = TextEditingController();
  final _ctrlWaChanId = TextEditingController();
  final _ctrlWaPhoneId = TextEditingController();
  final _ctrlWaVerify = TextEditingController();
  bool _waHab = false;
  // Telegram
  final _ctrlTgToken = TextEditingController();
  final _ctrlTgChatId = TextEditingController();
  bool _tgHab = false;
  // Jornada
  final _ctrlHoraEnt = TextEditingController();
  final _ctrlHoraSal = TextEditingController();
  final _ctrlToleran = TextEditingController();
  final _ctrlJornH = TextEditingController();
  // Reconocimiento
  double _umbral = 0.80;
  bool _pedirNuevo = true;
  String _fmtReporte = 'excel';
  // Sitios
  List<Sitio> _sitios = [];
  final _ctrlNuevoSitio   = TextEditingController();
  final _ctrlSitioDesc    = TextEditingController();
  final _ctrlSitioLat     = TextEditingController();
  final _ctrlSitioLon     = TextEditingController();
  final ServicioGps _svcGps = ServicioGps();
  // Facebook
  final _ctrlFbPageToken   = TextEditingController();
  final _ctrlFbAppId       = TextEditingController();
  final _ctrlFbAppSecret   = TextEditingController();
  final _ctrlFbVerifyToken = TextEditingController();
  bool _fbHabilitado = false;
  // Admins bot
  List<AdministradorBot> _adminsBot = [];

  bool _guardando = false;
  String? _logoRuta;
  final ImagePicker _picker = ImagePicker();
  Configuracion? _cfg;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 7, vsync: this);
    _cargar();
  }

  @override
  void dispose() {
    _tab.dispose();
    for (final c in [_ctrlNombreCia, _ctrlRfc, _ctrlDireccion, _ctrlTelefono,
        _ctrlEmail, _ctrlCiudadCia, _ctrlEstadoCia, _ctrlPaisCia, _ctrlCpCia, _ctrlBotPrefijo,
        _ctrlWaUrl, _ctrlWaToken, _ctrlWaChanId, _ctrlWaPhoneId,
        _ctrlWaVerify, _ctrlTgToken, _ctrlTgChatId, _ctrlHoraEnt, _ctrlHoraSal,
        _ctrlToleran, _ctrlJornH, _ctrlNuevoSitio,
      _ctrlSitioDesc, _ctrlSitioLat, _ctrlSitioLon]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _cargar() async {
    final cfg = await _bd.obtenerConfiguracion();
    final sitios = await _bd.obtenerSitios();
    setState(() {
      _cfg = cfg;
      _ctrlNombreCia.text = cfg.nombreCompania;
      _ctrlRfc.text = cfg.rfcCompania ?? '';
      _ctrlDireccion.text = cfg.direccionCompania ?? '';
      _ctrlTelefono.text = cfg.telefonoCompania ?? '';
      _ctrlEmail.text = cfg.emailCompania ?? '';
      _ctrlCiudadCia.text = cfg.ciudadCompania ?? '';
      _ctrlEstadoCia.text = cfg.estadoCompania ?? '';
      _ctrlPaisCia.text = cfg.paisCompania ?? '';
      _ctrlBotPrefijo.text = cfg.botPrefijo;
      _ctrlCpCia.text = cfg.codigoPostalCompania ?? '';
      _logoRuta = cfg.logoCompania;
      _ctrlWaUrl.text = cfg.whatsappApiUrl ?? '';
      _ctrlWaToken.text = cfg.whatsappApiToken ?? '';
      _ctrlWaChanId.text = cfg.whatsappChannelId ?? '';
      _ctrlWaPhoneId.text = cfg.whatsappPhoneNumberId ?? '';
      _ctrlWaVerify.text = cfg.whatsappVerifyToken ?? '';
      _waHab = cfg.whatsappHabilitado;
      _ctrlTgToken.text = cfg.telegramBotToken ?? '';
      _ctrlTgChatId.text = cfg.telegramChatId ?? '';
      _tgHab = cfg.telegramHabilitado;
      _ctrlHoraEnt.text = cfg.horaEntradaDefault;
      _ctrlHoraSal.text = cfg.horaSalidaDefault;
      _ctrlToleran.text = '${cfg.toleranciaMinutos}';
      _ctrlJornH.text = '${cfg.jornadaHoras}';
      _umbral = cfg.umbralReconocimiento;
      _pedirNuevo = cfg.pedirConfirmacionNuevo;
      _fmtReporte = cfg.formatoReporteDefault;
      _sitios = sitios;
    });
  }

  Future<void> _guardar() async {
    setState(() => _guardando = true);
    final cfg = Configuracion(
      nombreCompania: _ctrlNombreCia.text.trim().isEmpty ? 'Mi Compañía' : _ctrlNombreCia.text.trim(),
      rfcCompania: _ctrlRfc.text.trim().isEmpty ? null : _ctrlRfc.text.trim(),
      direccionCompania: _ctrlDireccion.text.trim().isEmpty ? null : _ctrlDireccion.text.trim(),
      telefonoCompania: _ctrlTelefono.text.trim().isEmpty ? null : _ctrlTelefono.text.trim(),
      emailCompania: _ctrlEmail.text.trim().isEmpty ? null : _ctrlEmail.text.trim(),
      ciudadCompania: _ctrlCiudadCia.text.trim().isEmpty ? null : _ctrlCiudadCia.text.trim(),
      estadoCompania: _ctrlEstadoCia.text.trim().isEmpty ? null : _ctrlEstadoCia.text.trim(),
      paisCompania: _ctrlPaisCia.text.trim().isEmpty ? null : _ctrlPaisCia.text.trim(),
      botPrefijo: _ctrlBotPrefijo.text.trim().isEmpty ? '/' : _ctrlBotPrefijo.text.trim(),
      codigoPostalCompania: _ctrlCpCia.text.trim().isEmpty ? null : _ctrlCpCia.text.trim(),
      logoCompania: _logoRuta,
      whatsappApiUrl: _ctrlWaUrl.text.trim().isEmpty ? null : _ctrlWaUrl.text.trim(),
      whatsappApiToken: _ctrlWaToken.text.trim().isEmpty ? null : _ctrlWaToken.text.trim(),
      whatsappChannelId: _ctrlWaChanId.text.trim().isEmpty ? null : _ctrlWaChanId.text.trim(),
      whatsappPhoneNumberId: _ctrlWaPhoneId.text.trim().isEmpty ? null : _ctrlWaPhoneId.text.trim(),
      whatsappVerifyToken: _ctrlWaVerify.text.trim().isEmpty ? null : _ctrlWaVerify.text.trim(),
      whatsappHabilitado: _waHab,
      telegramBotToken: _ctrlTgToken.text.trim().isEmpty ? null : _ctrlTgToken.text.trim(),
      telegramChatId: _ctrlTgChatId.text.trim().isEmpty ? null : _ctrlTgChatId.text.trim(),
      telegramHabilitado: _tgHab,
      horaEntradaDefault: _ctrlHoraEnt.text.trim().isEmpty ? '08:00' : _ctrlHoraEnt.text.trim(),
      horaSalidaDefault: _ctrlHoraSal.text.trim().isEmpty ? '17:00' : _ctrlHoraSal.text.trim(),
      toleranciaMinutos: int.tryParse(_ctrlToleran.text) ?? 15,
      jornadaHoras: double.tryParse(_ctrlJornH.text) ?? 8.0,
      umbralReconocimiento: _umbral,
      pedirConfirmacionNuevo: _pedirNuevo,
      formatoReporteDefault: _fmtReporte,
      zonaHoraria: _cfg?.zonaHoraria ?? 'America/Mexico_City',
    );
    await _bd.guardarConfiguracion(cfg);
    setState(() => _guardando = false);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Configuración guardada'), backgroundColor: Colors.green));
  }

  Future<void> _agregarSitio() async {
    final nombre = _ctrlNuevoSitio.text.trim();
    if (nombre.isEmpty) return;
    final lat = double.tryParse(_ctrlSitioLat.text.trim());
    final lon = double.tryParse(_ctrlSitioLon.text.trim());
    await _bd.insertarSitio(Sitio(
      nombre: nombre,
      descripcion: _ctrlSitioDesc.text.trim().isEmpty ? null : _ctrlSitioDesc.text.trim(),
      gpsLat: lat, gpsLon: lon));
    _ctrlNuevoSitio.clear(); _ctrlSitioDesc.clear();
    _ctrlSitioLat.clear(); _ctrlSitioLon.clear();
    _cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: const Text('Administración'),
        actions: [
          if (!_guardando)
            TextButton.icon(onPressed: _guardar,
                icon: const Icon(Icons.save, color: Colors.white),
                label: const Text('Guardar', style: TextStyle(color: Colors.white)))
          else
            const Padding(padding: EdgeInsets.all(16),
                child: SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Colors.white, labelColor: Colors.white, unselectedLabelColor: Colors.white70,
          isScrollable: true,
          tabs: const [
            Tab(icon: Icon(Icons.business), text: 'Compañía'),
            Tab(icon: Icon(Icons.chat), text: 'Bot/Chat'),
            Tab(icon: Icon(Icons.settings), text: 'Sistema'),
            Tab(icon: Icon(Icons.location_on), text: 'Sitios'),
            Tab(icon: Icon(Icons.backup), text: 'Backup'),
            Tab(icon: Icon(Icons.facebook), text: 'Facebook'),
            Tab(icon: Icon(Icons.admin_panel_settings), text: 'Admins'),
          ],
        ),
      ),
      body: TabBarView(controller: _tab, children: [
        _tabCompania(),
        _tabBot(),
        _tabSistema(),
        _tabSitios(),
        _tabBackup(),
        _tabFacebook(),
        _tabAdmins(),
      ]),
    );
  }

  Widget _tabCompania() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      _sec('Datos de la Compañía', Icons.business),
      _campo(_ctrlNombreCia, 'Nombre de la Compañía *', Icons.business),
      _campo(_ctrlRfc, 'RFC', Icons.numbers),
      _campo(_ctrlDireccion, 'Dirección', Icons.location_city),
      _campo(_ctrlTelefono, 'Teléfono', Icons.phone),
      _campo(_ctrlEmail, 'Email', Icons.email),
      Row(children: [
        Expanded(child: _campo(_ctrlCiudadCia, 'Ciudad', Icons.location_city)),
        const SizedBox(width: 8),
        Expanded(child: _campo(_ctrlEstadoCia, 'Estado', Icons.map)),
      ]),
      _campo(_ctrlPaisCia, 'País', Icons.public),
      _campo(_ctrlCpCia, 'Código Postal', Icons.markunread_mailbox),
      const SizedBox(height: 8),
      ListTile(
        leading: _logoRuta != null
            ? ClipRRect(borderRadius: BorderRadius.circular(4),
                child: Image.file(File(_logoRuta!), width: 40, height: 40, fit: BoxFit.contain))
            : const Icon(Icons.image, color: Color(0xFF1976D2), size: 40),
        title: const Text('Logo de la Compañía'),
        subtitle: Text(_logoRuta != null ? _logoRuta!.split('/').last : 'Sin logo'),
        trailing: ElevatedButton(
          onPressed: _seleccionarLogo,
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white),
          child: const Text('Cambiar'),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: Colors.grey.shade300)),
      ),
    ]),
  );

  Widget _tabBot() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Telegram
      _sec('Invocación del Bot', Icons.alternate_email),
      _campo(_ctrlBotPrefijo, 'Prefijo/Invocación (ej: / o @mibot )', Icons.alternate_email),
      const Padding(padding: EdgeInsets.only(bottom: 12),
        child: Text('Define cómo se llama al bot. Ejemplos: /, @desar, &bot',
            style: TextStyle(color: Colors.grey, fontSize: 11))),
      _sec('Telegram Bot', Icons.telegram),
      SwitchListTile(
          title: const Text('Habilitar Telegram Bot'),
          value: _tgHab, activeColor: const Color(0xFF1976D2),
          onChanged: (v) => setState(() => _tgHab = v)),
      _campo(_ctrlTgToken, 'Bot Token (de @BotFather)', Icons.vpn_key, obscure: false),
      _campo(_ctrlTgChatId, 'Chat ID del canal/grupo', Icons.group),
      const SizedBox(height: 8),
      Card(color: const Color(0xFFE3F2FD),
          child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Comandos disponibles:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 4),
            _cmdHelp('/reporte', 'Asistencias (hoy, fecha, rango, total)'),
            _cmdHelp('/lista', 'Lista empleados (pantalla o archivo)'),
            _cmdHelp('/hoy', 'Resumen de asistencias de hoy'),
            _cmdHelp('/empleado <cod>', 'Detalle de un empleado'),
            _cmdHelp('/estado', 'Estado del sistema'),
            _cmdHelp('/ayuda', 'Lista de comandos'),
            _cmdHelp('/creditos', 'Información del sistema'),
          ]))),
      const SizedBox(height: 16),

      // WhatsApp
      _sec('WhatsApp Business API', Icons.messenger),
      SwitchListTile(
          title: const Text('Habilitar WhatsApp'),
          value: _waHab, activeColor: const Color(0xFF1976D2),
          onChanged: (v) => setState(() => _waHab = v)),
      _campo(_ctrlWaUrl, 'API URL', Icons.link),
      _campo(_ctrlWaToken, 'Access Token', Icons.vpn_key, obscure: true),
      _campo(_ctrlWaPhoneId, 'Phone Number ID', Icons.phone_android),
      _campo(_ctrlWaChanId, 'Número destino (con código país)', Icons.group),
      _campo(_ctrlWaVerify, 'Verify Token (webhook)', Icons.verified),
      const SizedBox(height: 8),
      Card(color: const Color(0xFFFFF3E0),
          child: Padding(padding: const EdgeInsets.all(12),
              child: const Text('ℹ️ WhatsApp requiere cuenta Business y aprobación de Meta. Solo envía notificaciones.', style: TextStyle(fontSize: 12)))),
    ]),
  );

  Widget _tabSistema() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      _sec('Horario de Jornada', Icons.access_time),
      Row(children: [
        Expanded(child: _campo(_ctrlHoraEnt, 'Hora entrada', Icons.login)),
        const SizedBox(width: 12),
        Expanded(child: _campo(_ctrlHoraSal, 'Hora salida', Icons.logout)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _campo(_ctrlToleran, 'Tolerancia (min)', Icons.timer)),
        const SizedBox(width: 12),
        Expanded(child: _campo(_ctrlJornH, 'Horas jornada', Icons.hourglass_full)),
      ]),
      const SizedBox(height: 16),

      _sec('Reconocimiento Facial', Icons.face),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Umbral de reconocimiento: ${(_umbral * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const Text('Menor = más estricto, Mayor = más permisivo',
              style: TextStyle(color: Colors.grey, fontSize: 11)),
          Slider(value: _umbral, min: 0.5, max: 0.99, divisions: 49,
              activeColor: const Color(0xFF1976D2),
              label: '${(_umbral * 100).toStringAsFixed(0)}%',
              onChanged: (v) => setState(() => _umbral = v)),
        ]),
      ),
      SwitchListTile(
          title: const Text('Preguntar al añadir empleado nuevo'),
          subtitle: const Text('Si no se reconoce el rostro o QR, preguntar si registrar'),
          value: _pedirNuevo, activeColor: const Color(0xFF1976D2),
          onChanged: (v) => setState(() => _pedirNuevo = v)),
      const SizedBox(height: 16),

      _sec('Notificaciones', Icons.notifications),
      Card(child: ListTile(
        leading: const Icon(Icons.music_note, color: Color(0xFF1976D2)),
        title: const Text('Sonidos de Asistencia'),
        subtitle: const Text('Configurar sonidos de entrada, salida y baja'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PantallaSonidos())),
      )),
      const SizedBox(height: 16),
      _sec('Reportes', Icons.bar_chart),
      Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            const Text('Formato por default:'),
            const SizedBox(width: 16),
            ChoiceChip(label: const Text('Excel'), selected: _fmtReporte == 'excel',
                onSelected: (_) => setState(() => _fmtReporte = 'excel'),
                selectedColor: const Color(0xFF1976D2), labelStyle: TextStyle(color: _fmtReporte == 'excel' ? Colors.white : Colors.black)),
            const SizedBox(width: 8),
            ChoiceChip(label: const Text('PDF'), selected: _fmtReporte == 'pdf',
                onSelected: (_) => setState(() => _fmtReporte = 'pdf'),
                selectedColor: const Color(0xFF1976D2), labelStyle: TextStyle(color: _fmtReporte == 'pdf' ? Colors.white : Colors.black)),
          ]))),
    ]),
  );

  Widget _tabSitios() => Column(children: [
    Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        Row(children: [
          Expanded(child: TextField(controller: _ctrlNuevoSitio,
              decoration: InputDecoration(labelText: 'Nombre del sitio *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
          const SizedBox(width: 8),
          ElevatedButton(onPressed: _agregarSitio,
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1976D2),
                  foregroundColor: Colors.white, padding: const EdgeInsets.all(14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              child: const Icon(Icons.add)),
        ]),
        const SizedBox(height: 8),
        TextField(controller: _ctrlSitioDesc,
            decoration: InputDecoration(labelText: 'Descripción (opcional)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10))),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: _ctrlSitioLat,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: InputDecoration(labelText: 'GPS Latitud',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: _ctrlSitioLon,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: InputDecoration(labelText: 'GPS Longitud',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.my_location, color: Color(0xFF1976D2)),
            tooltip: 'Usar mi ubicación actual',
            onPressed: () async {
              final pos = await _svcGps.obtenerPosicion();
              if (pos != null && mounted) {
                setState(() {
                  _ctrlSitioLat.text = pos.latitud.toStringAsFixed(6);
                  _ctrlSitioLon.text = pos.longitud.toStringAsFixed(6);
                });
              }
            },
          ),
        ]),
      ]),
    ),
    Expanded(
      child: _sitios.isEmpty
          ? const Center(child: Text('Sin sitios de trabajo', style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              itemCount: _sitios.length,
              itemBuilder: (_, i) {
                final s = _sitios[i];
                final gps = (s.gpsLat != null && s.gpsLon != null)
                    ? '\${s.gpsLat!.toStringAsFixed(5)}, \${s.gpsLon!.toStringAsFixed(5)}'
                    : null;
                return ListTile(
                  leading: const Icon(Icons.location_on, color: Color(0xFF1976D2)),
                  title: Text(s.nombre),
                  subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (s.descripcion != null) Text(s.descripcion!, style: const TextStyle(fontSize: 12)),
                    if (gps != null) Text('GPS: \$gps',
                        style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  ]),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Color(0xFF1976D2)),
                      onPressed: () => _editarSitioDialog(s)),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () async { await _bd.eliminarSitio(s.id!); _cargar(); }),
                  ]),
                );
              }),
    ),
  ]);


  Future<void> _editarSitioDialog(Sitio sitio) async {
    final ctrlNombre = TextEditingController(text: sitio.nombre);
    final ctrlDesc   = TextEditingController(text: sitio.descripcion ?? '');
    final ctrlLat    = TextEditingController(text: sitio.gpsLat?.toString() ?? '');
    final ctrlLon    = TextEditingController(text: sitio.gpsLon?.toString() ?? '');
    final ctrlRadio  = TextEditingController(text: sitio.geofenceRadioMetros?.toString() ?? '');
    String tipo      = sitio.geofenceTipo ?? 'permitido';
    bool   gfActivo  = sitio.geofenceActivo;

    await showDialog(context: context, builder: (_) => StatefulBuilder(
      builder: (ctx, setD) => AlertDialog(
        title: const Text('Editar Sitio'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctrlNombre,
              decoration: const InputDecoration(labelText: 'Nombre *')),
          TextField(controller: ctrlDesc,
              decoration: const InputDecoration(labelText: 'Descripción')),
          Row(children: [
            Expanded(child: TextField(controller: ctrlLat,
                keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: const InputDecoration(labelText: 'GPS Lat'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: ctrlLon,
                keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: const InputDecoration(labelText: 'GPS Lon'))),
            IconButton(
              icon: const Icon(Icons.my_location, color: Color(0xFF1976D2)),
              onPressed: () async {
                final pos = await _svcGps.obtenerPosicion();
                if (pos != null) {
                  ctrlLat.text = pos.latitud.toStringAsFixed(6);
                  ctrlLon.text = pos.longitud.toStringAsFixed(6);
                }
              },
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: ctrlRadio,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Radio geofence (m)'))),
            const SizedBox(width: 8),
            DropdownButton<String>(
              value: tipo,
              items: const [
                DropdownMenuItem(value: 'permitido', child: Text('✅ Permitido')),
                DropdownMenuItem(value: 'prohibido', child: Text('🚫 Prohibido')),
              ],
              onChanged: (v) => setD(() => tipo = v ?? 'permitido'),
            ),
          ]),
          Row(children: [
            const Text('Geofence activo'),
            Switch(
              value: gfActivo,
              activeColor: const Color(0xFF1976D2),
              onChanged: (v) => setD(() => gfActivo = v),
            ),
          ]),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () async {
              if (ctrlNombre.text.trim().isEmpty) return;
              final lat   = double.tryParse(ctrlLat.text.trim());
              final lon   = double.tryParse(ctrlLon.text.trim());
              final radio = double.tryParse(ctrlRadio.text.trim());
              await _bd.actualizarSitio(Sitio(
                id:                   sitio.id,
                nombre:               ctrlNombre.text.trim(),
                descripcion:          ctrlDesc.text.trim().isEmpty ? null : ctrlDesc.text.trim(),
                gpsLat:               lat,
                gpsLon:               lon,
                geofenceRadioMetros:  radio,
                geofenceTipo:         tipo,
                geofenceActivo:       gfActivo,
                activo:               sitio.activo,
              ));
              if (mounted) { Navigator.pop(context); _cargar(); }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white),
            child: const Text('Guardar'),
          ),
        ],
      ),
    ));
  }

  Future<void> _seleccionarLogo() async {
    final xf = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (xf != null && mounted) setState(() => _logoRuta = xf.path);
  }

  Widget _sec(String t, IconData ico) => Padding(
    padding: const EdgeInsets.only(bottom: 10, top: 4),
    child: Row(children: [
      Icon(ico, color: const Color(0xFF1976D2), size: 18),
      const SizedBox(width: 8),
      Text(t, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF1565C0))),
      const Expanded(child: Divider(indent: 10)),
    ]),
  );

  Widget _campo(TextEditingController ctrl, String label, IconData ico, {bool obscure = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: ctrl, obscureText: obscure,
          decoration: InputDecoration(labelText: label,
              prefixIcon: Icon(ico, color: const Color(0xFF1976D2)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
        ),
      );

  Widget _cmdHelp(String cmd, String desc) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(children: [
      Text(cmd, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFF1565C0), fontWeight: FontWeight.bold)),
      const SizedBox(width: 8),
      Expanded(child: Text(desc, style: const TextStyle(fontSize: 11, color: Colors.grey))),
    ]),
  );

  // ── Tab Backup ──────────────────────────────────────────────
  bool _exportando = false;
  bool _importando = false;

  Widget _tabBackup() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _sec('Base de Datos', Icons.storage),
      Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            'Exportar crea una copia del archivo .db que puedes compartir. '
            'Importar reemplaza la base de datos activa con un archivo de respaldo.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity,
            child: ElevatedButton.icon(
              icon: _exportando
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.upload),
              label: const Text('Exportar base de datos'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: _exportando ? null : _exportarBd,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity,
            child: ElevatedButton.icon(
              icon: _importando
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.download),
              label: const Text('Importar base de datos'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange, foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: _importando ? null : _importarBd,
            ),
          ),
        ]),
      )),
      const SizedBox(height: 8),
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 4),
        child: Text('Importar reemplaza TODOS los datos actuales. Haz un respaldo antes.',
            style: TextStyle(fontSize: 12, color: Colors.orange)),
      ),
    ]),
  );

  Future<void> _exportarBd() async {
    setState(() => _exportando = true);
    try {
      final ruta = await _bd.exportarBd();
      if (!mounted) return;
      await Share.shareXFiles([XFile(ruta)], text: 'Backup DESAR');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Base de datos exportada'), backgroundColor: Colors.green));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al exportar: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _exportando = false);
    }
  }

  Future<void> _importarBd() async {
    final ok = await showDialog<bool>(context: context,
      builder: (_) => AlertDialog(
        title: const Text('Importar base de datos'),
        content: const Text('Esto reemplazará TODOS los datos actuales.\n\n¿Deseas continuar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(foregroundColor: Colors.orange),
              child: const Text('Importar')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _importando = true);
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: false);
      if (result == null || result.files.single.path == null) { setState(() => _importando = false); return; }
      await _bd.importarBd(result.files.single.path!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Base de datos importada'), backgroundColor: Colors.green));
        _cargar();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al importar: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _importando = false);
    }
  }

}
