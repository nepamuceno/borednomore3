// /desar/lib/pantallas/admin/pantalla_sonidos.dart
// Configuracion de sonidos - v2: file_picker para seleccionar archivo de media

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../servicios/servicio_sonido.dart';

class PantallaSonidos extends StatefulWidget {
  const PantallaSonidos({super.key});
  @override
  State<PantallaSonidos> createState() => _PantallaSonidosState();
}

class _PantallaSonidosState extends State<PantallaSonidos> {
  final ServicioSonido _svc = ServicioSonido();

  Map<String, String?> _sonidos = {};
  bool _sonidoEntrada = true, _vibEntrada   = false;
  bool _sonidoSalida  = true, _vibSalida    = false;
  bool _sonidoBaja    = true, _vibBaja      = false;
  bool _cargando = true;

  @override
  void initState() { super.initState(); _cargar(); }

  Future<void> _cargar() async {
    final p = await _svc.obtenerPrefsCompletas();
    setState(() {
      _sonidos = {
        'entrada': p['entrada'] as String?,
        'salida':  p['salida']  as String?,
        'baja':    p['baja']    as String?,
      };
      _sonidoEntrada = p['sonido_entrada'] as bool;
      _vibEntrada    = p['vib_entrada']    as bool;
      _sonidoSalida  = p['sonido_salida']  as bool;
      _vibSalida     = p['vib_salida']     as bool;
      _sonidoBaja    = p['sonido_baja']    as bool;
      _vibBaja       = p['vib_baja']       as bool;
      _cargando      = false;
    });
  }

  Future<void> _probar(String tipo) async {
    switch (tipo) {
      case 'entrada': await _svc.reproducirEntrada(); break;
      case 'salida':  await _svc.reproducirSalida();  break;
      case 'baja':    await _svc.reproducirBaja();    break;
    }
  }

  Future<void> _seleccionarArchivo(String tipo) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
      );
      if (result == null || result.files.single.path == null) return;
      final ruta = result.files.single.path!;
      switch (tipo) {
        case 'entrada': await _svc.guardarSonidoEntrada(ruta); break;
        case 'salida':  await _svc.guardarSonidoSalida(ruta);  break;
        case 'baja':    await _svc.guardarSonidoBaja(ruta);    break;
      }
      _cargar();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sonido actualizado: ${ruta.split('/').last}'),
              backgroundColor: Colors.green));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  Future<void> _limpiar(String tipo) async {
    switch (tipo) {
      case 'entrada': await _svc.guardarSonidoEntrada(''); break;
      case 'salida':  await _svc.guardarSonidoSalida('');  break;
      case 'baja':    await _svc.guardarSonidoBaja('');    break;
    }
    _cargar();
  }

  Future<void> _guardarToggle(String tipo, bool sonido, bool vib) async {
    switch (tipo) {
      case 'entrada': await _svc.guardarPrefsEntrada(sonido, vib); break;
      case 'salida':  await _svc.guardarPrefsSalida(sonido, vib);  break;
      case 'baja':    await _svc.guardarPrefsBaja(sonido, vib);    break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: const Text('Sonidos de Notificación'),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              const Text(
                'Configura los sonidos y vibraciones al registrar asistencia.',
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 20),
              _tarjetaSonido('Entrada', Icons.login, Colors.green,
                  _sonidos['entrada'], 'entrada', _sonidoEntrada, _vibEntrada,
                  (s, v) async { setState(() { _sonidoEntrada = s; _vibEntrada = v; }); await _guardarToggle('entrada', s, v); }),
              _tarjetaSonido('Salida', Icons.logout, const Color(0xFF1565C0),
                  _sonidos['salida'], 'salida', _sonidoSalida, _vibSalida,
                  (s, v) async { setState(() { _sonidoSalida = s; _vibSalida = v; }); await _guardarToggle('salida', s, v); }),
              _tarjetaSonido('BAJA (empleado inactivo)', Icons.block, Colors.red,
                  _sonidos['baja'], 'baja', _sonidoBaja, _vibBaja,
                  (s, v) async { setState(() { _sonidoBaja = s; _vibBaja = v; }); await _guardarToggle('baja', s, v); }),
            ]),
    );
  }

  Widget _tarjetaSonido(String titulo, IconData ico, Color color,
      String? rutaActual, String tipo, bool usarSonido, bool usarVibracion,
      Future<void> Function(bool, bool) onCambio) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(ico, color: color, size: 22),
            const SizedBox(width: 8),
            Text(titulo, style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 15)),
          ]),
          const SizedBox(height: 8),
          Text(
            rutaActual != null && rutaActual.isNotEmpty
                ? 'Archivo: ${rutaActual.split('/').last}'
                : 'Usando archivo por defecto',
            style: TextStyle(
                color: rutaActual != null && rutaActual.isNotEmpty ? Colors.black87 : Colors.grey,
                fontSize: 12),
          ),
          const SizedBox(height: 12),
          Row(children: [
            _botonToggle(activo: usarSonido, icono: Icons.volume_up, etiqueta: 'Sonido',
                colorActivo: color, onTap: () => onCambio(!usarSonido, usarVibracion)),
            const SizedBox(width: 8),
            _botonToggle(activo: usarVibracion, icono: Icons.vibration, etiqueta: 'Vibración',
                colorActivo: color, onTap: () => onCambio(usarSonido, !usarVibracion)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            ElevatedButton.icon(
              onPressed: () => _probar(tipo),
              icon: const Icon(Icons.play_arrow, size: 16), label: const Text('Probar'),
              style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  textStyle: const TextStyle(fontSize: 12)),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: () => _seleccionarArchivo(tipo),
              icon: const Icon(Icons.audio_file, size: 16), label: const Text('Cambiar'),
              style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  textStyle: const TextStyle(fontSize: 12)),
            ),
            if (rutaActual != null && rutaActual.isNotEmpty) ...[
              const SizedBox(width: 8),
              TextButton.icon(
                onPressed: () => _limpiar(tipo),
                icon: const Icon(Icons.restore, size: 16), label: const Text('Restablecer'),
                style: TextButton.styleFrom(foregroundColor: Colors.grey,
                    textStyle: const TextStyle(fontSize: 12)),
              ),
            ],
          ]),
        ]),
      ),
    );
  }

  Widget _botonToggle({required bool activo, required IconData icono, required String etiqueta,
      required Color colorActivo, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: activo ? colorActivo : Colors.transparent,
          border: Border.all(color: activo ? colorActivo : Colors.grey.shade400, width: 1.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icono, size: 16, color: activo ? Colors.white : Colors.grey.shade600),
          const SizedBox(width: 5),
          Text(etiqueta, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold,
              color: activo ? Colors.white : Colors.grey.shade600)),
        ]),
      ),
    );
  }
}
