// /desar/lib/pantallas/empleados/pantalla_lista_empleados.dart
// CRUD completo de empleados

import 'dart:io';
import 'package:flutter/material.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../modelos/empleado.dart';
import 'pantalla_nuevo_empleado.dart';
import 'pantalla_detalle_empleado.dart';

class PantallaListaEmpleados extends StatefulWidget {
  const PantallaListaEmpleados({super.key});
  @override
  State<PantallaListaEmpleados> createState() => _PantallaListaEmpleadosState();
}

class _PantallaListaEmpleadosState extends State<PantallaListaEmpleados> {
  final BaseDatosHelper _bd = BaseDatosHelper();
  final TextEditingController _ctrlBusq = TextEditingController();
  List<Empleado> _todos = [], _filtrados = [];
  bool _cargando = true, _soloActivos = true;

  @override
  void initState() { super.initState(); _cargar(); }

  @override
  void dispose() { _ctrlBusq.dispose(); super.dispose(); }

  Future<void> _cargar() async {
    setState(() => _cargando = true);
    final lista = _soloActivos ? await _bd.obtenerEmpleadosActivos() : await _bd.obtenerTodosEmpleados();
    setState(() { _todos = lista; _filtrados = lista; _cargando = false; });
  }

  void _filtrar(String t) {
    if (t.isEmpty) { setState(() => _filtrados = _todos); return; }
    final q = t.toLowerCase();
    setState(() => _filtrados = _todos.where((e) =>
        e.nombre.toLowerCase().contains(q) ||
        e.codigoEmpleado.toLowerCase().contains(q) ||
        (e.numeroIdentificacion ?? '').toLowerCase().contains(q)).toList());
  }

  Future<void> _confirmarEliminar(Empleado emp) async {
    final ok = await showDialog<bool>(context: context,
        builder: (_) => AlertDialog(
          title: const Text('Eliminar Empleado'),
          content: Text('¿Eliminar a \${emp.nombre}?\nSe borrará también todo su historial de asistencia.\nEsta acción no se puede deshacer.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            TextButton(onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Eliminar')),
          ],
        ));
    if (ok == true) {
      await _bd.eliminarEmpleadoCompleto(emp.id!);
      _cargar();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${emp.nombre} eliminado')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: const Text('Empleados'),
        actions: [
          IconButton(
              icon: Icon(_soloActivos ? Icons.people : Icons.people_outline),
              tooltip: _soloActivos ? 'Ver todos' : 'Solo activos',
              onPressed: () { setState(() => _soloActivos = !_soloActivos); _cargar(); }),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _cargar),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PantallaNuevoEmpleado()))
            .then((_) => _cargar()),
        backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add), label: const Text('Nuevo'),
      ),
      body: Column(children: [
        Container(
          color: const Color(0xFF1976D2),
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: TextField(
            controller: _ctrlBusq, onChanged: _filtrar,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Buscar...', hintStyle: const TextStyle(color: Colors.white70),
              prefixIcon: const Icon(Icons.search, color: Colors.white70),
              suffixIcon: _ctrlBusq.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.clear, color: Colors.white70),
                      onPressed: () { _ctrlBusq.clear(); _filtrar(''); })
                  : null,
              filled: true, fillColor: Colors.white24,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 8),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(children: [
            Text('${_filtrados.length} empleados', style: const TextStyle(color: Colors.grey, fontSize: 13)),
            const Spacer(),
            Text(_soloActivos ? 'Activos' : 'Todos',
                style: const TextStyle(color: Color(0xFF1976D2), fontSize: 13, fontWeight: FontWeight.bold)),
          ]),
        ),
        Expanded(
          child: _cargando
              ? const Center(child: CircularProgressIndicator())
              : _filtrados.isEmpty
                  ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.people_outline, size: 60, color: Colors.grey),
                      SizedBox(height: 10),
                      Text('Sin empleados', style: TextStyle(color: Colors.grey)),
                    ]))
                  : ListView.builder(
                      itemCount: _filtrados.length,
                      itemBuilder: (_, i) => _item(_filtrados[i])),
        ),
      ]),
    );
  }

  Widget _item(Empleado emp) {
    return Dismissible(
      key: Key('e${emp.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
          alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
          color: Colors.red, child: const Icon(Icons.delete, color: Colors.white)),
      confirmDismiss: (_) async { await _confirmarEliminar(emp); return false; },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: emp.estaActivo ? const Color(0xFF1976D2) : Colors.grey,
            backgroundImage: emp.fotoPerfil != null ? FileImage(File(emp.fotoPerfil!)) : null,
            child: emp.fotoPerfil == null
                ? Text(emp.nombre.isNotEmpty ? emp.nombre[0].toUpperCase() : '?',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))
                : null,
          ),
          title: Text(emp.nombre,
              style: TextStyle(fontWeight: FontWeight.bold,
                  color: emp.estaActivo ? Colors.black87 : Colors.grey)),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Código: ${emp.codigoEmpleado}', style: const TextStyle(fontSize: 12)),
            if (emp.numeroIdentificacion != null) Text('ID: ${emp.numeroIdentificacion}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ]),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(
                icon: Icon(emp.estaActivo ? Icons.toggle_on : Icons.toggle_off,
                    color: emp.estaActivo ? Colors.green : Colors.grey, size: 28),
                onPressed: () async {
                  await _bd.cambiarEstado(emp.id!, emp.estaActivo ? 0 : 1);
                  _cargar();
                }),
            const Icon(Icons.chevron_right, color: Colors.grey),
          ]),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => PantallaDetalleEmpleado(empleado: emp)))
              .then((_) => _cargar()),
        ),
      ),
    );
  }
}
