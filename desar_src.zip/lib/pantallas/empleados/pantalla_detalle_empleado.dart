// /desar/lib/pantallas/empleados/pantalla_detalle_empleado.dart
// Detalle empleado: datos, QR, Gafete, historial
// Fixed: QR content = codigoEmpleado only
//        Gafete tab: auto-generated on open, PdfPreview in-screen (same as QR), share button only

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:printing/printing.dart';
import '../../modelos/empleado.dart';
import '../../modelos/jornada.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../servicios/servicio_qr.dart';
import '../../servicios/servicio_gafete.dart';
import 'pantalla_nuevo_empleado.dart';

class PantallaDetalleEmpleado extends StatefulWidget {
  final Empleado empleado;
  const PantallaDetalleEmpleado({super.key, required this.empleado});
  @override
  State<PantallaDetalleEmpleado> createState() => _PantallaDetalleEmpleadoState();
}

class _PantallaDetalleEmpleadoState extends State<PantallaDetalleEmpleado>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final BaseDatosHelper _bd       = BaseDatosHelper();
  final ServicioQr _qr            = ServicioQr();
  final ServicioGafete _svcGafete = ServicioGafete();
  late Empleado _emp;
  List<Jornada> _jornadas = [];
  bool _cargando = true;

  // Badge state
  String? _rutaGafete;
  String? _rutaQrPdf;
  bool _generandoGafete = false;
  bool _generandoImpresion = false;

  @override
  void initState() {
    super.initState();
    _emp = widget.empleado;
    _tab = TabController(length: 5, vsync: this);
    _cargarJornadas();
    _generarGafeteAuto();
    _generarQrPdfAuto();
    _tab.addListener(() {
      if (_tab.index == 2 && _rutaGafete == null && !_generandoGafete) {
        _generarGafeteAuto();
      }
    });
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _cargarJornadas() async {
    setState(() => _cargando = true);
    final hoy    = DateTime.now();
    final hace30 = hoy.subtract(const Duration(days: 30));
    final fmt    = DateFormat('yyyy-MM-dd');
    final lista  = await _bd.obtenerJornadasEmpleado(
        _emp.id!, fmt.format(hace30), fmt.format(hoy));
    setState(() { _jornadas = lista.reversed.toList(); _cargando = false; });
  }

  Future<void> _generarGafeteAuto() async {
    if (_generandoGafete) return;
    setState(() => _generandoGafete = true);
    try {
      final cfg  = await _bd.obtenerConfiguracion();
      final ruta = await _svcGafete.generarGafetePdf(_emp, cfg);
      if (mounted) setState(() { _rutaGafete = ruta; _generandoGafete = false; });
    } catch (e) {
      print('[GAFETE] Auto-gen error: $e');
      if (mounted) setState(() => _generandoGafete = false);
    }
  }

  Future<void> _generarQrPdfAuto() async {
    try {
      final ruta = await _svcGafete.generarQrPdf(_emp);
      if (ruta != null && mounted) setState(() => _rutaQrPdf = ruta);
    } catch (e) { print('[QR PDF] $e'); }
  }

  Future<void> _imprimirIndividual() async {
    if (_generandoImpresion) return;
    setState(() => _generandoImpresion = true);
    try {
      final cfg  = await _bd.obtenerConfiguracion();
      final ruta = await _svcGafete.generarImpresionIndividual(_emp, cfg);
      if (ruta != null && mounted) {
        await Share.shareXFiles([XFile(ruta)],
            text: 'Impresión gafete/QR: \${_emp.nombre}');
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: \$e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _generandoImpresion = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: Text(_emp.nombre, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => PantallaNuevoEmpleado(empleadoEditar: _emp)))
                .then((_) async {
                  final act = await _bd.obtenerEmpleadoPorId(_emp.id!);
                  if (act != null && mounted) {
                    setState(() { _emp = act; _rutaGafete = null; });
                    _generarGafeteAuto();
                  }
                }),
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Colors.white, labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.person),  text: 'Datos'),
            Tab(icon: Icon(Icons.qr_code), text: 'QR'),
            Tab(icon: Icon(Icons.badge),   text: 'Gafete'),
            Tab(icon: Icon(Icons.history),  text: 'Historial'),
            Tab(icon: Icon(Icons.print),   text: 'Imprimir'),
          ],
        ),
      ),
      body: TabBarView(controller: _tab,
          children: [_tabDatos(), _tabQr(), _tabGafete(), _tabHistorial(), _tabImprimir()]),
    );
  }

  // ── TAB DATOS ─────────────────────────────────────────────
  Widget _tabDatos() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      CircleAvatar(
        radius: 52, backgroundColor: const Color(0xFFBBDEFB),
        backgroundImage: _emp.fotoPerfil != null ? FileImage(File(_emp.fotoPerfil!)) : null,
        child: _emp.fotoPerfil == null
            ? Text(_emp.nombre[0].toUpperCase(),
                style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold, color: Color(0xFF1976D2)))
            : null,
      ),
      const SizedBox(height: 10),
      Text(_emp.nombre, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Text(_emp.estaActivo ? 'Activo' : 'BAJA',
          style: TextStyle(color: _emp.estaActivo ? Colors.green : Colors.red,
              fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      _dato('Código',              _emp.codigoEmpleado,         Icons.badge),
      if (_emp.puesto != null)              _dato('Puesto',          _emp.puesto!,                  Icons.work),
      if (_emp.numeroIdentificacion != null) _dato('No. Identificación', _emp.numeroIdentificacion!, Icons.credit_card),
      if (_emp.seguroSocial != null)        _dato('Seguro Social',   _emp.seguroSocial!,            Icons.security),
      if (_emp.rfc != null)                 _dato('RFC',             _emp.rfc!,                     Icons.numbers),
      if (_emp.telefono != null)            _dato('Teléfono',        _emp.telefono!,                Icons.phone),
      if (_emp.telefonoEmergencia != null)  _dato('Tel. Emergencia', _emp.telefonoEmergencia!,      Icons.emergency),
      if (_emp.direccion != null)           _dato('Dirección',       _emp.direccion!,               Icons.location_on),
      if (_emp.ciudad != null)              _dato('Ciudad',          _emp.ciudad!,                  Icons.location_city),
      if (_emp.estado != null)              _dato('Estado',          _emp.estado!,                  Icons.map),
      if (_emp.pais != null)                _dato('País',            _emp.pais!,                    Icons.public),
      if (_emp.codigoPostal != null)        _dato('C.P.',            _emp.codigoPostal!,            Icons.markunread_mailbox),
      if (_emp.tipoSangre != null)          _dato('Tipo de Sangre',  _emp.tipoSangre!,              Icons.bloodtype),
      if (_emp.fechaNacimiento != null)     _dato('F. Nacimiento',   _emp.fechaNacimiento!,         Icons.cake),
      if (_emp.sitioTrabajo != null)        _dato('Sitio',           _emp.sitioTrabajo!,            Icons.location_on),
      if (_emp.fechaRegistro != null)       _dato('Registro',        _emp.fechaRegistro!.substring(0, 10), Icons.calendar_today),
      if (_emp.notas != null)               _dato('Notas',           _emp.notas!,                   Icons.note),
      const SizedBox(height: 16),
      const Text('Fotos Reconocimiento Facial',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
      const SizedBox(height: 8),
      Row(children: [
        _miniFoto('Frente',    _emp.fotoRostro1, _emp.embedding1 != null),
        const SizedBox(width: 8),
        _miniFoto('Izquierda', _emp.fotoRostro2, _emp.embedding2 != null),
        const SizedBox(width: 8),
        _miniFoto('Derecha',   _emp.fotoRostro3, _emp.embedding3 != null),
      ]),
    ]),
  );

  // ── TAB QR — QR content is always just codigoEmpleado ─────
  Widget _tabQr() {
    // QR data = employee code only, always consistent
    final contenido = _qr.generarContenido(_emp);
    return Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('Código QR Personal',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(_emp.nombre, style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 20),
        Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(
                    color: Colors.black.withOpacity(0.08), blurRadius: 8)]),
            child: _qr.widget(contenido, tam: 220)),
        const SizedBox(height: 14),
        Text(_emp.codigoEmpleado,
            style: const TextStyle(
                fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 4)),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: ElevatedButton.icon(
            onPressed: () async {
              final ruta = await _qr.guardarImagen(_emp);
              if (ruta != null && mounted) {
                await Share.shareXFiles([XFile(ruta)],
                    text: 'QR de asistencia: \${_emp.nombre} (\${_emp.codigoEmpleado})',
                    subject: 'QR \${_emp.nombre}');
              }
            },
            icon: const Icon(Icons.share), label: const Text('Compartir PNG'),
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          )),
          const SizedBox(width: 8),
          if (_rutaQrPdf != null)
            Expanded(child: ElevatedButton.icon(
              onPressed: () async {
                await Share.shareXFiles([XFile(_rutaQrPdf!)],
                    text: 'QR PDF: \${_emp.nombre}');
              },
              icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF QR'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFB71C1C), foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            )),
        ]),
        const SizedBox(height: 8),
        const Text('WhatsApp • Bluetooth • Gmail • Telegram • Drive…',
            style: TextStyle(color: Colors.grey, fontSize: 11)),
      ]),
    ));
  }

  // ── TAB GAFETE — identical structure to QR tab ─────────────
  Widget _tabGafete() {
    return Column(children: [
      // PDF rendered inline — same as QR widget is shown inline
      Expanded(
        child: _generandoGafete
            ? const Center(child: Column(
                mainAxisAlignment: MainAxisAlignment.center, children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 12),
                  Text('Generando gafete…', style: TextStyle(color: Colors.grey)),
                ]))
            : _rutaGafete != null
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                    child: PdfPreview(
                      build: (_) => File(_rutaGafete!).readAsBytes(),
                      allowPrinting: false,
                      allowSharing: false,
                      canChangeOrientation: false,
                      canChangePageFormat: false,
                      canDebug: false,
                      maxPageWidth: 440,
                      pdfFileName: 'gafete_${_emp.codigoEmpleado}.pdf',
                    ),
                  )
                : const Center(child: Text('Error al generar gafete',
                    style: TextStyle(color: Colors.grey))),
      ),

      // Only share button — no "generate" button (auto-generated)
      if (_rutaGafete != null)
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
          child: Column(children: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await Share.shareXFiles([XFile(_rutaGafete!)],
                      text: 'Gafete de ${_emp.nombre}',
                      subject: 'Gafete ${_emp.nombre}');
                },
                icon: const Icon(Icons.share),
                label: const Text('Compartir Gafete'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.all(14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 4),
            const Text('WhatsApp • Bluetooth • Gmail • Telegram • Drive…',
                style: TextStyle(color: Colors.grey, fontSize: 11)),
          ]),
        ),
    ]);
  }

  // ── TAB IMPRIMIR ──────────────────────────────────────────
  Widget _tabImprimir() => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
      const SizedBox(height: 10),
      CircleAvatar(
        radius: 40, backgroundColor: const Color(0xFFBBDEFB),
        backgroundImage: _emp.fotoPerfil != null ? FileImage(File(_emp.fotoPerfil!)) : null,
        child: _emp.fotoPerfil == null
            ? Text(_emp.nombre[0].toUpperCase(),
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF1976D2)))
            : null,
      ),
      const SizedBox(height: 10),
      Text(_emp.nombre, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      Text(_emp.codigoEmpleado, style: const TextStyle(fontSize: 13, color: Colors.grey, letterSpacing: 2)),
      const SizedBox(height: 24),
      const Text('Impresión individual para porta-gafetes CR80',
          style: TextStyle(color: Colors.grey, fontSize: 13)),
      const SizedBox(height: 6),
      const Text('Genera una hoja A4 con el frente y reverso del gafete listos para recortar.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.grey, fontSize: 12)),
      const SizedBox(height: 24),
      SizedBox(width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _generandoImpresion ? null : _imprimirIndividual,
          icon: _generandoImpresion
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.print),
          label: const Text('Generar e imprimir/compartir'),
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
              padding: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        ),
      ),
      const SizedBox(height: 12),
      if (_rutaGafete != null)
        OutlinedButton.icon(
          onPressed: () async {
            await Share.shareXFiles([XFile(_rutaGafete!)], text: 'Gafete \${_emp.nombre}');
          },
          icon: const Icon(Icons.badge, color: Color(0xFF1565C0)),
          label: const Text('Solo Gafete PDF'),
          style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
        ),
      const SizedBox(height: 8),
      if (_rutaQrPdf != null)
        OutlinedButton.icon(
          onPressed: () async {
            await Share.shareXFiles([XFile(_rutaQrPdf!)], text: 'QR PDF \${_emp.nombre}');
          },
          icon: const Icon(Icons.qr_code, color: Color(0xFF1976D2)),
          label: const Text('Solo QR PDF'),
          style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
        ),
    ]),
  );

  // ── TAB HISTORIAL ─────────────────────────────────────────
  Widget _tabHistorial() {
    if (_cargando) return const Center(child: CircularProgressIndicator());
    if (_jornadas.isEmpty) return const Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.history, size: 60, color: Colors.grey), SizedBox(height: 10),
          Text('Sin registros últimos 30 días', style: TextStyle(color: Colors.grey)),
        ]));

    final totalH = _jornadas.where((j) => j.horasTrabajadas != null)
        .fold<double>(0, (s, j) => s + j.horasTrabajadas!);
    final fmt = DateFormat('HH:mm');

    return Column(children: [
      Container(color: const Color(0xFFE3F2FD), padding: const EdgeInsets.all(10),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _chipR('Días',      '${_jornadas.length}', Icons.calendar_today),
            _chipR('Completas', '${_jornadas.where((j) => j.estaCompleta).length}', Icons.check_circle),
            _chipR('Total',     '${totalH.toStringAsFixed(1)}h', Icons.access_time),
          ])),
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: _jornadas.length,
        itemBuilder: (_, i) {
          final j = _jornadas[i];
          return Card(
            margin: const EdgeInsets.only(bottom: 6),
            child: ListTile(
              leading: Container(width: 40, height: 40,
                  decoration: BoxDecoration(
                      color: j.estaCompleta ? const Color(0xFFE8F5E9) : const Color(0xFFFFF3E0),
                      borderRadius: BorderRadius.circular(8)),
                  child: Icon(j.estaCompleta ? Icons.check_circle : Icons.pending,
                      color: j.estaCompleta ? Colors.green : Colors.orange, size: 20)),
              title: Text(j.fecha, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Row(children: [
                if (j.entradaTimestamp != null)
                  Text('🟢 ${fmt.format(DateTime.parse(j.entradaTimestamp!))}',
                      style: const TextStyle(fontSize: 12)),
                if (j.salidaTimestamp != null)
                  Text('  🔴 ${fmt.format(DateTime.parse(j.salidaTimestamp!))}',
                      style: const TextStyle(fontSize: 12)),
              ]),
              trailing: Text(j.horasFormateadas,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ),
          );
        },
      )),
    ]);
  }

  Widget _dato(String label, String val, IconData ico) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 3)]),
    child: Row(children: [
      Icon(ico, color: const Color(0xFF1976D2), size: 18), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10)),
        Text(val,   style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      ])),
    ]),
  );

  Widget _miniFoto(String label, String? ruta, bool tieneEmb) => Expanded(
    child: Container(height: 85,
        decoration: BoxDecoration(
            border: Border.all(color: tieneEmb ? Colors.green : Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8)),
        child: ruta != null
            ? Stack(children: [
                ClipRRect(borderRadius: BorderRadius.circular(6),
                    child: Image.file(File(ruta), fit: BoxFit.cover,
                        width: double.infinity, height: double.infinity)),
                Positioned(top: 3, right: 3,
                    child: Icon(tieneEmb ? Icons.verified : Icons.warning,
                        color: tieneEmb ? Colors.green : Colors.orange, size: 13)),
              ])
            : Center(child: Icon(Icons.no_photography,
                color: Colors.grey.shade300, size: 24))),
  );

  Widget _chipR(String label, String val, IconData ico) =>
      Column(children: [
        Icon(ico, color: const Color(0xFF1976D2), size: 16), const SizedBox(height: 3),
        Text(val,   style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10)),
      ]);
}
