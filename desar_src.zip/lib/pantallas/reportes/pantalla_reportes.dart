// /desar/lib/pantallas/reportes/pantalla_reportes.dart
// v4: registros individuales, delete, preview PDF, todos los catálogos

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:open_filex/open_filex.dart';
import 'package:printing/printing.dart';
import '../../servicios/servicio_reportes.dart';
import '../../servicios/servicio_gafete.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../modelos/empleado.dart';
import '../../modelos/configuracion.dart';

class PantallaReportes extends StatefulWidget {
  const PantallaReportes({super.key});
  @override
  State<PantallaReportes> createState() => _PantallaReportesState();
}

class _PantallaReportesState extends State<PantallaReportes>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final ServicioReportes _rep    = ServicioReportes();
  final ServicioGafete   _gafete = ServicioGafete();
  final BaseDatosHelper  _bd     = BaseDatosHelper();
  final DateFormat _fmt = DateFormat('yyyy-MM-dd');

  DateTime _fechaIni = DateTime.now().subtract(const Duration(days: 7));
  DateTime _fechaFin = DateTime.now();
  Empleado? _empFiltro;
  List<Empleado> _empleados = [];
  bool _generando = false;
  List<ArchivoReporte> _archivos = [];
  bool _cargandoArch = false;
  Configuracion? _cfg;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _init();
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _init() async {
    _empleados = await _bd.obtenerTodosEmpleados();
    _cfg = await _bd.obtenerConfiguracion();
    await _cargarArchivos();
  }

  Future<void> _cargarArchivos() async {
    setState(() => _cargandoArch = true);
    final lista = await _rep.listar();
    setState(() { _archivos = lista; _cargandoArch = false; });
  }

  Future<void> _selFecha(bool esIni) async {
    final f = await showDatePicker(context: context,
        initialDate: esIni ? _fechaIni : _fechaFin,
        firstDate: DateTime(2020), lastDate: DateTime.now());
    if (f != null) setState(() {
      if (esIni) { _fechaIni = f; if (_fechaFin.isBefore(f)) _fechaFin = f; }
      else { _fechaFin = f; if (_fechaIni.isAfter(f)) _fechaIni = f; }
    });
  }

  String get _tsIni => '${_fmt.format(_fechaIni)}T00:00:00';
  String get _tsFin => '${_fmt.format(_fechaFin)}T23:59:59';

  Future<void> _generar(String tipo) async {
    setState(() => _generando = true);
    String? ruta;
    try {
      switch (tipo) {
        case 'excel_asis':      ruta = await _rep.excelAsistencias(tsInicio: _tsIni, tsFin: _tsFin, empleadoId: _empFiltro?.id, config: _cfg); break;
        case 'pdf_asis':        ruta = await _rep.pdfAsistencias(tsInicio: _tsIni, tsFin: _tsFin, empleadoId: _empFiltro?.id, config: _cfg); break;
        case 'txt_asis':        ruta = await _rep.txtAsistencias(tsInicio: _tsIni, tsFin: _tsFin); break;
        case 'excel_registros': ruta = await _rep.excelRegistros(tsInicio: _tsIni, tsFin: _tsFin, empleadoId: _empFiltro?.id, config: _cfg); break;
        case 'pdf_registros':   ruta = await _rep.pdfRegistros(tsInicio: _tsIni, tsFin: _tsFin, empleadoId: _empFiltro?.id, config: _cfg); break;
        case 'excel_tardanzas': ruta = await _rep.excelTardanzasAusencias(tsInicio: _tsIni, tsFin: _tsFin); break;
        case 'pdf_tardanzas':   ruta = await _rep.pdfTardanzasAusencias(tsInicio: _tsIni, tsFin: _tsFin, config: _cfg); break;
        case 'pdf_vigencias':   ruta = await _rep.pdfVigencias(config: _cfg); break;
        case 'excel_emp':       ruta = await _rep.excelEmpleados(); break;
        case 'pdf_emp':         ruta = await _rep.pdfEmpleados(config: _cfg); break;
        case 'pdf_emp_gafetes': ruta = await _rep.pdfCatalogoEmpleadosGafetes(config: _cfg); break;
        case 'excel_gafetes':   ruta = await _rep.excelCatalogoGafetes(); break;
        case 'pdf_gafetes':     ruta = await _rep.pdfCatalogoGafetes(config: _cfg); break;
        case 'excel_qr':        ruta = await _rep.excelCatalogoQr(); break;
        case 'pdf_qr':          ruta = await _rep.pdfCatalogoQr(); break;
        case 'sql_completo':    ruta = await _rep.sqlDumpCompleto(); break;
        case 'sql_movimientos': ruta = await _rep.sqlDumpMovimientos(); break;
      }
      await _cargarArchivos();
      if (ruta != null && mounted) _mostrarGenerado(ruta);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _generando = false);
    }
  }

  void _mostrarGenerado(String ruta) {
    final esPdf = ruta.endsWith('.pdf');
    showDialog(context: context, builder: (_) => AlertDialog(
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 52),
        const SizedBox(height: 8),
        Text(ruta.split('/').last, textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 4),
        const Text('Reporte generado', style: TextStyle(color: Colors.grey)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
        if (esPdf) TextButton(
          onPressed: () { Navigator.pop(context); _verEnPantalla(ruta); },
          child: const Text('Ver'),
        ),
        TextButton(onPressed: () { Navigator.pop(context); OpenFilex.open(ruta); },
            child: const Text('Abrir')),
        ElevatedButton.icon(
          onPressed: () { Navigator.pop(context); Share.shareXFiles([XFile(ruta)]); },
          icon: const Icon(Icons.share), label: const Text('Compartir'),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white)),
      ],
    ));
  }

  void _verEnPantalla(String ruta) {
    Navigator.push(context, MaterialPageRoute(builder: (_) =>
        _PantallaPreviewPdf(ruta: ruta, titulo: ruta.split('/').last)));
  }

  Future<void> _confirmarEliminar(ArchivoReporte a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar reporte'),
        content: Text('¿Eliminar ${a.nombre}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await File(a.ruta).delete();
        _cargarArchivos();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${a.nombre} eliminado')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: const Text('Reportes'),
        bottom: TabBar(controller: _tab, indicatorColor: Colors.white,
            labelColor: Colors.white, unselectedLabelColor: Colors.white70,
            tabs: const [
              Tab(icon: Icon(Icons.add_chart), text: 'Generar'),
              Tab(icon: Icon(Icons.folder_open), text: 'Archivos'),
            ]),
      ),
      body: TabBarView(controller: _tab, children: [_tabGenerar(), _tabArchivos()]),
    );
  }

  Widget _tabGenerar() => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      _sec('Período', Icons.date_range),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnFecha('Desde', _fmt.format(_fechaIni), true)),
        const SizedBox(width: 12),
        Expanded(child: _btnFecha('Hasta', _fmt.format(_fechaFin), false)),
      ]),
      const SizedBox(height: 14),

      _sec('Empleado (opcional)', Icons.person),
      const SizedBox(height: 8),
      DropdownButtonFormField<Empleado?>(
        value: _empFiltro,
        decoration: InputDecoration(hintText: 'Todos',
            prefixIcon: const Icon(Icons.people, color: Color(0xFF1976D2)),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
        items: [
          const DropdownMenuItem<Empleado?>(value: null, child: Text('Todos los empleados')),
          ..._empleados.map((e) => DropdownMenuItem<Empleado?>(value: e,
              child: Text('${e.codigoEmpleado} - ${e.nombre}'))),
        ],
        onChanged: (v) => setState(() => _empFiltro = v),
      ),
      const SizedBox(height: 20),

      _sec('Asistencias (jornadas)', Icons.fact_check),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart, const Color(0xFF1B5E20), () => _generar('excel_asis'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_asis'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('Texto', Icons.text_snippet,   const Color(0xFF37474F), () => _generar('txt_asis'))),
      ]),
      const SizedBox(height: 20),

      _sec('Registros individuales', Icons.checklist),
      const SizedBox(height: 4),
      const Text('Cada check-in/out con método (QR/Facial/Manual) y GPS',
          style: TextStyle(fontSize: 11, color: Colors.grey)),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart,    const Color(0xFF1B5E20), () => _generar('excel_registros'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_registros'))),
      ]),
      const SizedBox(height: 20),

      _sec('Tardanzas y Ausencias', Icons.warning_amber),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart,    const Color(0xFF1B5E20), () => _generar('excel_tardanzas'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_tardanzas'))),
      ]),
      const SizedBox(height: 20),

      _sec('Control de Vigencias', Icons.event_busy),
      const SizedBox(height: 4),
      const Text('Vencidos · Por vencer en 30 días · Vigentes',
          style: TextStyle(fontSize: 11, color: Colors.grey)),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity,
        child: _btnRep('PDF Vigencias', Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_vigencias'))),
      const SizedBox(height: 20),

      _sec('Empleados', Icons.people),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart,    const Color(0xFF1B5E20), () => _generar('excel_emp'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_emp'))),
      ]),
      const SizedBox(height: 20),

      _sec('Empleados + Gafete CR80', Icons.badge),
      const SizedBox(height: 4),
      const Text('Una página A4 por empleado: datos completos + gafete imprimible',
          style: TextStyle(fontSize: 11, color: Colors.grey)),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity,
        child: _btnRep('PDF Catálogo', Icons.picture_as_pdf, const Color(0xFF1565C0), () => _generar('pdf_emp_gafetes'))),
      const SizedBox(height: 20),

      _sec('Catálogo Gafetes CR80', Icons.badge),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart,    const Color(0xFF1B5E20), () => _generar('excel_gafetes'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_gafetes'))),
      ]),
      const SizedBox(height: 20),

      _sec('Catálogo QR', Icons.qr_code),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _btnRep('Excel', Icons.table_chart,    const Color(0xFF1B5E20), () => _generar('excel_qr'))),
        const SizedBox(width: 8),
        Expanded(child: _btnRep('PDF',   Icons.picture_as_pdf, const Color(0xFFB71C1C), () => _generar('pdf_qr'))),
      ]),
      const SizedBox(height: 16),

      if (_generando)
        const Center(child: Column(children: [
          CircularProgressIndicator(),
          SizedBox(height: 8),
          Text('Generando reporte...', style: TextStyle(color: Colors.grey)),
        ])),
    ]),
  );

  Widget _tabArchivos() {
    if (_cargandoArch) return const Center(child: CircularProgressIndicator());
    if (_archivos.isEmpty) return Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.folder_open, size: 60, color: Colors.grey),
      const SizedBox(height: 10),
      const Text('Sin reportes generados', style: TextStyle(color: Colors.grey)),
      const SizedBox(height: 16),
      ElevatedButton(onPressed: () => _tab.animateTo(0), child: const Text('Generar uno')),
    ]));

    return RefreshIndicator(
      onRefresh: _cargarArchivos,
      child: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: _archivos.length,
        itemBuilder: (_, i) {
          final a      = _archivos[i];
          final esPdf  = a.nombre.endsWith('.pdf');
          return Card(
            margin: const EdgeInsets.only(bottom: 6),
            child: ListTile(
              leading: CircleAvatar(
                  backgroundColor: _colorTipo(a.tipo),
                  child: Text(a.tipo[0],
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
              title: Text(a.nombre, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              subtitle: Text('${a.tipo} • ${a.tamanioStr} • ${DateFormat('dd/MM/yy HH:mm').format(a.fecha)}',
                  style: const TextStyle(fontSize: 11)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (esPdf) IconButton(
                    icon: const Icon(Icons.visibility, size: 20, color: Color(0xFF1565C0)),
                    tooltip: 'Ver',
                    onPressed: () => _verEnPantalla(a.ruta)),
                IconButton(
                    icon: const Icon(Icons.open_in_new, size: 20, color: Colors.grey),
                    onPressed: () => OpenFilex.open(a.ruta)),
                IconButton(
                    icon: const Icon(Icons.share, size: 20, color: Color(0xFF1976D2)),
                    onPressed: () => Share.shareXFiles([XFile(a.ruta)])),
                IconButton(
                    icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                    tooltip: 'Eliminar',
                    onPressed: () => _confirmarEliminar(a)),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _sec(String t, IconData ico) => Row(children: [
    Icon(ico, color: const Color(0xFF1976D2), size: 16),
    const SizedBox(width: 8),
    Text(t, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF1565C0))),
    const Expanded(child: Divider(indent: 10)),
  ]);

  Widget _btnFecha(String label, String valor, bool esIni) => GestureDetector(
    onTap: () => _selFecha(esIni),
    child: Container(padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(border: Border.all(color: const Color(0xFF1976D2)),
            borderRadius: BorderRadius.circular(10)),
        child: Column(children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 2),
          Text(valor, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1565C0))),
        ])),
  );

  Widget _btnRep(String label, IconData ico, Color color, VoidCallback onTap) => GestureDetector(
    onTap: _generando ? null : onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
          color: _generando ? Colors.grey.shade300 : color,
          borderRadius: BorderRadius.circular(10)),
      child: Column(children: [
        Icon(ico, color: Colors.white, size: 22),
        const SizedBox(height: 5),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      ]),
    ),
  );

  Color _colorTipo(String tipo) {
    switch (tipo) {
      case 'Excel': return const Color(0xFF1B5E20);
      case 'PDF':   return const Color(0xFFB71C1C);
      default:      return const Color(0xFF37474F);
    }
  }
}

class _PantallaPreviewPdf extends StatelessWidget {
  final String ruta;
  final String titulo;
  const _PantallaPreviewPdf({required this.ruta, required this.titulo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: Text(titulo, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
        actions: [
          IconButton(icon: const Icon(Icons.share),
              onPressed: () => Share.shareXFiles([XFile(ruta)])),
        ],
      ),
      body: PdfPreview(
        build: (_) => File(ruta).readAsBytes(),
        allowPrinting: true,
        allowSharing: false,
        canChangeOrientation: false,
        canChangePageFormat: false,
        canDebug: false,
        pdfFileName: titulo,
      ),
    );
  }
}
