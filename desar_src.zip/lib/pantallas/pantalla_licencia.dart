// /desar/lib/pantallas/pantalla_licencia.dart
// Pantalla de licencia, activacion y aviso de caducacion

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../servicios/servicio_licencia.dart';

class PantallaLicencia extends StatefulWidget {
  final EstadoLicencia estado;
  final VoidCallback onContinuar;
  final bool soloAviso; // true = solo muestra aviso, false = bloquea

  const PantallaLicencia({
    super.key,
    required this.estado,
    required this.onContinuar,
    this.soloAviso = false,
  });

  @override
  State<PantallaLicencia> createState() => _PantallaLicenciaState();
}

class _PantallaLicenciaState extends State<PantallaLicencia> {
  final ServicioLicencia _svc = ServicioLicencia();
  final _ctrlCodigo = TextEditingController();
  bool _activando = false;
  String? _mensajeActivacion;
  bool _mostrarActivar = false;

  @override
  void dispose() {
    _ctrlCodigo.dispose();
    super.dispose();
  }

  Future<void> _activar() async {
    final codigo = _ctrlCodigo.text.trim();
    if (codigo.isEmpty) return;
    setState(() { _activando = true; _mensajeActivacion = null; });
    final resultado = await _svc.activar(codigo);
    setState(() {
      _activando = false;
      _mensajeActivacion = resultado.mensaje;
    });
    if (resultado.exitoso && mounted) {
      await Future.delayed(const Duration(seconds: 1));
      widget.onContinuar();
    }
  }

  @override
  Widget build(BuildContext context) {
    final expirada = widget.estado.estaExpirada;
    final color = expirada ? const Color(0xFFB71C1C) : const Color(0xFFF57C00);
    final icono = expirada ? Icons.lock : Icons.warning_amber_rounded;

    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 40),
              // Logo / icono
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 3),
                ),
                child: Icon(icono, color: color, size: 50),
              ),
              const SizedBox(height: 24),

              Text('DESAR', style: TextStyle(
                  color: Colors.white, fontSize: 28,
                  fontWeight: FontWeight.bold, letterSpacing: 4)),
              const Text('Sistema de Control de Asistencias',
                  style: TextStyle(color: Colors.white54, fontSize: 13)),
              const SizedBox(height: 8),
              const Text('v0.0.1-beta',
                  style: TextStyle(color: Colors.white38, fontSize: 11)),
              const SizedBox(height: 32),

              // Mensaje estado
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.5)),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text(
                    expirada ? 'LICENCIA EXPIRADA' : 'VERSIÓN DE PRUEBA',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: color, fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(widget.estado.mensaje,
                      textAlign: TextAlign.center,
                      softWrap: true,
                      style: const TextStyle(color: Colors.white70, fontSize: 13)),
                  if (!expirada) ...[
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: widget.estado.diasRestantes / 60.0,
                      backgroundColor: Colors.white12,
                      valueColor: AlwaysStoppedAnimation<Color>(color),
                    ),
                    const SizedBox(height: 4),
                    Text('${widget.estado.diasRestantes} de 60 días restantes',
                        style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  ],
                ]),
              ),
              const SizedBox(height: 24),

              // Mensaje de compra
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(children: [
                  const Text('Para adquirir la licencia completa:',
                      style: TextStyle(color: Colors.white70, fontSize: 13,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  GestureDetector(
                    onTap: () => Clipboard.setData(
                        const ClipboardData(text: 'zzerver@gmail.com')),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.email, color: Color(0xFF42A5F5), size: 16),
                      const SizedBox(width: 6),
                      const Text('zzerver@gmail.com',
                          style: TextStyle(color: Color(0xFF42A5F5), fontSize: 13)),
                      const SizedBox(width: 4),
                      const Icon(Icons.copy, color: Colors.white38, size: 13),
                    ]),
                  ),
                  const SizedBox(height: 4),
                  const Text('(c) 2026 Alex Rogelio Rodriguez Castañeda',
                      style: TextStyle(color: Colors.white38, fontSize: 10)),
                ]),
              ),
              const SizedBox(height: 24),

              // Activacion
              if (!_mostrarActivar)
                OutlinedButton.icon(
                  onPressed: () => setState(() => _mostrarActivar = true),
                  icon: const Icon(Icons.vpn_key, color: Colors.white70),
                  label: const Text('Tengo un código de activación',
                      style: TextStyle(color: Colors.white70)),
                  style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.white24),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                )
              else
                Column(children: [
                  TextField(
                    controller: _ctrlCodigo,
                    style: const TextStyle(color: Colors.white, fontSize: 18,
                        letterSpacing: 2),
                    textAlign: TextAlign.center,
                    keyboardType: TextInputType.number,
                    maxLength: 19,
                    decoration: InputDecoration(
                      hintText: 'XXXX-XXXX-XXXX-XXXX',
                      hintStyle: const TextStyle(color: Colors.white30),
                      counterText: '',
                      filled: true,
                      fillColor: Colors.white10,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(
                              color: Color(0xFF42A5F5))),
                    ),
                    inputFormatters: [
                      _CodigoActivacionFormatter(),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_mensajeActivacion != null)
                    Text(_mensajeActivacion!,
                        style: TextStyle(
                            color: _mensajeActivacion!.contains('✅')
                                ? Colors.green
                                : Colors.red,
                            fontSize: 13)),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _activando ? null : _activar,
                      icon: _activando
                          ? const SizedBox(width: 16, height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.check_circle),
                      label: Text(_activando ? 'Validando...' : 'Activar Licencia'),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1976D2),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.all(14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                    ),
                  ),
                ]),

              const SizedBox(height: 24),

              // Boton continuar (solo si no expirada)
              if (!expirada)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: widget.onContinuar,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF37474F),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.all(14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: const Text('Continuar con versión de prueba'),
                  ),
                ),

              if (expirada)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Text(
                    'Contacte al proveedor para obtener su código de activación\ny continuar usando el sistema.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white38, fontSize: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// Formateador XXXX-XXXX-XXXX-XXXX
class _CodigoActivacionFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length > 16) return oldValue;

    final buffer = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      if (i > 0 && i % 4 == 0) buffer.write('-');
      buffer.write(digits[i]);
    }

    final str = buffer.toString();
    return TextEditingValue(
      text: str,
      selection: TextSelection.collapsed(offset: str.length),
    );
  }
}

// Widget de banner de aviso (para mostrar en pantalla principal)
class BannerLicencia extends StatelessWidget {
  final EstadoLicencia estado;
  final VoidCallback onActivar;

  const BannerLicencia({
    super.key,
    required this.estado,
    required this.onActivar,
  });

  @override
  Widget build(BuildContext context) {
    if (estado.esCompleta) return const SizedBox.shrink();

    final color = estado.advertencia
        ? const Color(0xFFE53935)
        : const Color(0xFFF57C00);

    return GestureDetector(
      onTap: onActivar,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        color: color,
        child: Row(children: [
          const Icon(Icons.warning_amber, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              estado.mensaje,
              style: const TextStyle(color: Colors.white,
                  fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
          const Text('ACTIVAR →',
              style: TextStyle(color: Colors.white, fontSize: 11,
                  fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }
}
