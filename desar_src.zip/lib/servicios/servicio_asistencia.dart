// /desar/lib/servicios/servicio_asistencia.dart
// Logica central de registros: entrada/salida, jornadas, clasificacion
// Improved: ResultadoAsistencia includes horasTrabajadas, horasFormateadas,
//           mensajeBot includes worked hours on exit

import '../base_datos/base_datos_helper.dart';
import '../modelos/empleado.dart';
import '../modelos/registro.dart';
import '../modelos/jornada.dart';
import 'servicio_gps.dart';

class ServicioAsistencia {
  static final ServicioAsistencia _inst = ServicioAsistencia._interno();
  factory ServicioAsistencia() => _inst;
  ServicioAsistencia._interno();

  final BaseDatosHelper _bd = BaseDatosHelper();
  final ServicioGps _gps = ServicioGps();

  // Determina tipo: si ultimo registro fue entrada -> salida, si no -> entrada
  Future<String> determinarTipo(int empId) async {
    final ultimo = await _bd.obtenerUltimoRegistro(empId);
    if (ultimo == null) return 'entrada';
    if (ultimo.tipo == 'salida') return 'entrada';
    final hoy = DateTime.now().toIso8601String().substring(0, 10);
    if (ultimo.timestamp.startsWith(hoy)) return 'salida';
    return 'entrada';
  }

  Future<ResultadoAsistencia> registrar({
    required Empleado empleado,
    required String metodo,
    String? sitio,
  }) async {
    try {
      final posicion = await _gps.obtenerPosicion();
      final tipo = await determinarTipo(empleado.id!);
      final ahora = DateTime.now();
      final ts = ahora.toIso8601String();
      final fecha = ts.substring(0, 10);
      final sitioFinal = sitio ?? empleado.sitioTrabajo ?? 'Principal';

      final registro = Registro(
        empleadoId: empleado.id!,
        codigoEmpleado: empleado.codigoEmpleado,
        nombreEmpleado: empleado.nombre,
        tipo: tipo,
        timestamp: ts,
        gpsLat: posicion?.latitud,
        gpsLon: posicion?.longitud,
        sitioTrabajo: sitioFinal,
        metodo: metodo,
      );
      await _bd.insertarRegistro(registro);

      double? horasTrabajadas;
      await _actualizarJornada(
          empleado: empleado, tipo: tipo, ts: ts, fecha: fecha, sitio: sitioFinal);

      // Retrieve worked hours for exit
      if (tipo == 'salida') {
        final jornada = await _bd.obtenerJornadaDia(empleado.id!, fecha);
        horasTrabajadas = jornada?.horasTrabajadas;
      }

      return ResultadoAsistencia(
        exitoso: true,
        tipo: tipo,
        empleado: empleado,
        timestamp: ts,
        posicion: posicion,
        sitio: sitioFinal,
        horasTrabajadas: horasTrabajadas,
        mensaje: tipo == 'entrada'
            ? 'ENTRADA registrada: ${empleado.nombre}'
            : 'SALIDA registrada: ${empleado.nombre}',
      );
    } catch (e) {
      print('[ASISTENCIA] Error: $e');
      return ResultadoAsistencia(
        exitoso: false,
        tipo: 'error',
        empleado: empleado,
        timestamp: DateTime.now().toIso8601String(),
        mensaje: 'Error: $e',
      );
    }
  }

  Future<void> _actualizarJornada({
    required Empleado empleado,
    required String tipo,
    required String ts,
    required String fecha,
    required String sitio,
  }) async {
    final jornadaExist = await _bd.obtenerJornadaDia(empleado.id!, fecha);

    if (tipo == 'entrada') {
      if (jornadaExist == null) {
        await _bd.insertarJornada(Jornada(
          empleadoId: empleado.id!,
          codigoEmpleado: empleado.codigoEmpleado,
          nombreEmpleado: empleado.nombre,
          fecha: fecha,
          entradaTimestamp: ts,
          completa: 0,
          sitioTrabajo: sitio,
        ));
      } else {
        await _bd.actualizarJornada(Jornada(
          id: jornadaExist.id,
          empleadoId: jornadaExist.empleadoId,
          codigoEmpleado: jornadaExist.codigoEmpleado,
          nombreEmpleado: jornadaExist.nombreEmpleado,
          fecha: jornadaExist.fecha,
          entradaTimestamp: ts,
          salidaTimestamp: jornadaExist.salidaTimestamp,
          horasTrabajadas: jornadaExist.horasTrabajadas,
          completa: jornadaExist.completa,
          sitioTrabajo: sitio,
        ));
      }
    } else {
      if (jornadaExist != null && jornadaExist.entradaTimestamp != null) {
        final horas = Jornada.calcularHoras(jornadaExist.entradaTimestamp!, ts);
        await _bd.actualizarJornada(Jornada(
          id: jornadaExist.id,
          empleadoId: jornadaExist.empleadoId,
          codigoEmpleado: jornadaExist.codigoEmpleado,
          nombreEmpleado: jornadaExist.nombreEmpleado,
          fecha: jornadaExist.fecha,
          entradaTimestamp: jornadaExist.entradaTimestamp,
          salidaTimestamp: ts,
          horasTrabajadas: horas,
          completa: 1,
          sitioTrabajo: sitio,
        ));
      }
    }
  }
}

class ResultadoAsistencia {
  final bool exitoso;
  final String tipo; // 'entrada' | 'salida' | 'error'
  final Empleado empleado;
  final String timestamp;
  final PosicionGps? posicion;
  final String? sitio;
  final String mensaje;
  final double? horasTrabajadas;

  ResultadoAsistencia({
    required this.exitoso,
    required this.tipo,
    required this.empleado,
    required this.timestamp,
    this.posicion,
    this.sitio,
    required this.mensaje,
    this.horasTrabajadas,
  });

  // Worked hours formatted as Xh Ym
  String get horasFormateadas {
    if (horasTrabajadas == null) return '';
    final h = horasTrabajadas!.floor();
    final m = ((horasTrabajadas! - h) * 60).round();
    return m > 0 ? '${h}h ${m}m' : '${h}h';
  }

  String get mensajeBot {
    final dt = DateTime.parse(timestamp);
    final hora = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    final emoji = tipo == 'entrada' ? '🟢' : '🔴';
    final gpsStr = posicion != null
        ? '\n📍 ${posicion!.latitud.toStringAsFixed(5)}, ${posicion!.longitud.toStringAsFixed(5)}'
        : '';
    final horasStr = (tipo == 'salida' && horasTrabajadas != null)
        ? '\n⏱ Trabajó: $horasFormateadas'
        : '';
    return '$emoji *${tipo.toUpperCase()}*\n👤 ${empleado.nombre}\n🆔 ${empleado.codigoEmpleado}\n🏢 $sitio\n🕐 $hora$horasStr$gpsStr';
  }
}
