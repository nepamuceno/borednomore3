// /desar/lib/servicios/servicio_licencia.dart
// Sistema de licencia y activacion - DESAR v0.0.1-beta
// Algoritmo basado en "matacuaz" + "tecoman" + codigo empleado

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ServicioLicencia {
  static final ServicioLicencia _inst = ServicioLicencia._interno();
  factory ServicioLicencia() => _inst;
  ServicioLicencia._interno();

  static const String _keyFechaInstalacion = 'desar_fecha_instalacion';
  static const String _keyCodigoActivacion = 'desar_codigo_activacion';
  static const String _keyActivado = 'desar_activado';
  static const int _diasPrueba = 60;

  // Semillas del algoritmo (privadas)
  static const String _semilla1 = 'matacuaz';
  static const String _semilla2 = 'tecoman';

  // ─── Inicializar licencia al primer arranque ──────────────
  Future<void> inicializar() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey(_keyFechaInstalacion)) {
      await prefs.setString(
          _keyFechaInstalacion, DateTime.now().toIso8601String());
    }
  }

  // ─── Estado actual de la licencia ────────────────────────
  Future<EstadoLicencia> obtenerEstado() async {
    final prefs = await SharedPreferences.getInstance();

    // Verificar si ya esta activado
    final activado = prefs.getBool(_keyActivado) ?? false;
    if (activado) {
      final codigo = prefs.getString(_keyCodigoActivacion) ?? '';
      return EstadoLicencia(
        tipo: TipoLicencia.completa,
        diasRestantes: -1,
        mensaje: 'Licencia completa activa',
        codigoActivacion: codigo,
      );
    }

    // Calcular dias restantes
    final fechaStr = prefs.getString(_keyFechaInstalacion);
    if (fechaStr == null) {
      await inicializar();
      return EstadoLicencia(
        tipo: TipoLicencia.prueba,
        diasRestantes: _diasPrueba,
        mensaje: 'Versión de prueba: $_diasPrueba días restantes',
      );
    }

    final fechaInstalacion = DateTime.parse(fechaStr);
    final ahora = DateTime.now();
    final diasUsados = ahora.difference(fechaInstalacion).inDays;
    final diasRestantes = _diasPrueba - diasUsados;

    if (diasRestantes <= 0) {
      return EstadoLicencia(
        tipo: TipoLicencia.expirada,
        diasRestantes: 0,
        mensaje: 'Período de prueba expirado. Contacte al proveedor.',
      );
    }

    return EstadoLicencia(
      tipo: TipoLicencia.prueba,
      diasRestantes: diasRestantes,
      mensaje: diasRestantes <= 7
          ? '⚠️ ADVERTENCIA: Solo quedan $diasRestantes días de prueba'
          : 'Versión de prueba: $diasRestantes días restantes',
    );
  }

  // ─── Validar y aplicar codigo de activacion ───────────────
  Future<ResultadoActivacion> activar(String codigo) async {
    final codigoLimpio = codigo.replaceAll('-', '').replaceAll(' ', '').trim();

    if (codigoLimpio.length != 16) {
      return ResultadoActivacion(
          exitoso: false, mensaje: 'Código inválido: debe tener 16 dígitos');
    }

    if (!RegExp(r'^\d{16}$').hasMatch(codigoLimpio)) {
      return ResultadoActivacion(
          exitoso: false, mensaje: 'Código inválido: solo dígitos');
    }

    if (_validarCodigo(codigoLimpio)) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyActivado, true);
      await prefs.setString(_keyCodigoActivacion, codigoLimpio);
      return ResultadoActivacion(
          exitoso: true, mensaje: '✅ Licencia activada correctamente');
    }

    return ResultadoActivacion(
        exitoso: false, mensaje: '❌ Código de activación inválido');
  }

  // ─── Algoritmo de validacion ──────────────────────────────
  // Genera/valida codigo de 16 digitos usando semillas + checksum
  bool _validarCodigo(String codigo) {
    // Extraer partes del codigo
    // Formato: AAAABBBBCCCCDDDD
    // AAAA = bloque 1 (seed1-based)
    // BBBB = bloque 2 (seed2-based)
    // CCCC = bloque 3 (timestamp-based)
    // DDDD = checksum

    if (codigo.length != 16) return false;

    final b1 = int.tryParse(codigo.substring(0, 4)) ?? 0;
    final b2 = int.tryParse(codigo.substring(4, 8)) ?? 0;
    final b3 = int.tryParse(codigo.substring(8, 12)) ?? 0;
    final b4 = int.tryParse(codigo.substring(12, 16)) ?? 0;

    // Verificar bloque 1 basado en semilla1
    final s1Hash = _hashSemilla(_semilla1);
    final b1Esperado = s1Hash % 9000 + 1000;
    if (b1 != b1Esperado) return false;

    // Verificar bloque 2 basado en semilla2
    final s2Hash = _hashSemilla(_semilla2);
    final b2Esperado = s2Hash % 9000 + 1000;
    if (b2 != b2Esperado) return false;

    // Verificar checksum (b4 = (b1 + b2 + b3) % 9000 + 1000)
    final checksumEsperado = (b1 + b2 + b3) % 9000 + 1000;
    if (b4 != checksumEsperado) return false;

    // Verificar que b3 sea un año valido (2025-2035)
    final anio = b3 ~/ 100;
    final mes = b3 % 100;
    if (anio < 25 || anio > 35) return false;
    if (mes < 1 || mes > 12) return false;

    return true;
  }

  // ─── Hash simple de semilla ───────────────────────────────
  int _hashSemilla(String semilla) {
    int hash = 0;
    for (int i = 0; i < semilla.length; i++) {
      hash = (hash * 31 + semilla.codeUnitAt(i)) & 0xFFFFFFFF;
    }
    return hash.abs();
  }

  // ─── Generar codigo valido (para uso del desarrollador) ───
  // anio: 25-35, mes: 1-12
  static String generarCodigo(int anio, int mes) {
    final svc = ServicioLicencia();
    final s1Hash = svc._hashSemilla(_semilla1);
    final s2Hash = svc._hashSemilla(_semilla2);

    final b1 = s1Hash % 9000 + 1000;
    final b2 = s2Hash % 9000 + 1000;
    final b3 = anio * 100 + mes;
    final b4 = (b1 + b2 + b3) % 9000 + 1000;

    final codigo = '${b1.toString().padLeft(4, '0')}'
        '${b2.toString().padLeft(4, '0')}'
        '${b3.toString().padLeft(4, '0')}'
        '${b4.toString().padLeft(4, '0')}';

    return codigo;
  }

  // Formato legible: XXXX-XXXX-XXXX-XXXX
  static String generarCodigoFormateado(int anio, int mes) {
    final raw = generarCodigo(anio, mes);
    return '${raw.substring(0, 4)}-${raw.substring(4, 8)}-'
        '${raw.substring(8, 12)}-${raw.substring(12, 16)}';
  }

  Future<bool> get estaActivado async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyActivado) ?? false;
  }

  Future<bool> get puedeUsarse async {
    final estado = await obtenerEstado();
    return estado.tipo != TipoLicencia.expirada;
  }
}

enum TipoLicencia { prueba, completa, expirada }

class EstadoLicencia {
  final TipoLicencia tipo;
  final int diasRestantes; // -1 si es completa
  final String mensaje;
  final String? codigoActivacion;

  EstadoLicencia({
    required this.tipo,
    required this.diasRestantes,
    required this.mensaje,
    this.codigoActivacion,
  });

  bool get esPrueba => tipo == TipoLicencia.prueba;
  bool get esCompleta => tipo == TipoLicencia.completa;
  bool get estaExpirada => tipo == TipoLicencia.expirada;
  bool get advertencia => esPrueba && diasRestantes <= 7;
}

class ResultadoActivacion {
  final bool exitoso;
  final String mensaje;
  ResultadoActivacion({required this.exitoso, required this.mensaje});
}
