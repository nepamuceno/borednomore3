// /desar/lib/servicios/servicio_qr.dart
// Generacion y procesamiento QR offline
// Fixed: QR content is ALWAYS codigoEmpleado only — consistent, scannable, predictable

import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../modelos/empleado.dart';

class ServicioQr {
  static final ServicioQr _inst = ServicioQr._interno();
  factory ServicioQr() => _inst;
  ServicioQr._interno();

  // QR content is ALWAYS just the employee code — no prefix, no name
  // This ensures every QR for the same employee is 100% identical
  String generarContenido(Empleado emp) => emp.codigoEmpleado;

  // Parses scanned QR — accepts plain code or legacy DESAR: prefixed format
  ResultadoQr procesar(String contenido) {
    if (contenido.isEmpty) {
      return ResultadoQr(valido: false, mensaje: 'QR vacío');
    }
    // Support legacy format: DESAR:CODE:NAME or CHECADOR:CODE:NAME
    if (contenido.contains(':')) {
      final partes = contenido.split(':');
      // e.g. DESAR:EMP001:... or CHECADOR:EMP001:...
      if (partes.length >= 2 && partes[1].isNotEmpty) {
        return ResultadoQr(
          valido: true,
          codigoEmpleado: partes[1],
          nombreEmpleado: partes.length > 2 ? partes.sublist(2).join(':') : '',
          mensaje: 'OK',
        );
      }
    }
    // Plain code (current format)
    return ResultadoQr(
      valido: true,
      codigoEmpleado: contenido.trim().toUpperCase(),
      nombreEmpleado: '',
      mensaje: 'OK',
    );
  }

  // Widget QR for display — white background for clean scan
  Widget widget(String contenido, {double tam = 200}) => QrImageView(
        data: contenido,
        version: QrVersions.auto,
        size: tam,
        errorCorrectionLevel: QrErrorCorrectLevel.M,
        gapless: false,
        backgroundColor: const ui.Color(0xFFFFFFFF),
      );

  // Save QR as PNG and return path
  Future<String?> guardarImagen(Empleado emp) async {
    try {
      final contenido = generarContenido(emp);
      final res = QrValidator.validate(
          data: contenido,
          version: QrVersions.auto,
          errorCorrectionLevel: QrErrorCorrectLevel.M);
      if (res.status != QrValidationStatus.valid) return null;

      final painter = QrPainter.withQr(
          qr: res.qrCode!,
          color: const ui.Color(0xFF000000),
          emptyColor: const ui.Color(0xFFFFFFFF),
          gapless: true);

      final imagen = await painter.toImage(400);
      final bd = await imagen.toByteData(format: ui.ImageByteFormat.png);
      if (bd == null) return null;

      final dir = await getApplicationDocumentsDirectory();
      final dirQr = Directory('${dir.path}/qr');
      if (!await dirQr.exists()) await dirQr.create(recursive: true);

      // Fixed filename — always overwrites same file for same employee
      final ruta = '${dirQr.path}/qr_${emp.codigoEmpleado}.png';
      await File(ruta).writeAsBytes(bd.buffer.asUint8List());
      return ruta;
    } catch (e) {
      print('[QR] Error: $e');
      return null;
    }
  }

  // Alias used by pantalla_nuevo_empleado
  Future<String?> guardarQrComoImagen(Empleado emp) => guardarImagen(emp);
}

class ResultadoQr {
  final bool valido;
  final String? codigoEmpleado;
  final String? nombreEmpleado;
  final String mensaje;

  ResultadoQr({required this.valido, this.codigoEmpleado, this.nombreEmpleado, required this.mensaje});
}
