// /desar/lib/servicios/servicio_gps.dart
// Servicio GPS offline usando hardware del dispositivo

import 'package:geolocator/geolocator.dart';

class ServicioGps {
  static final ServicioGps _inst = ServicioGps._interno();
  factory ServicioGps() => _inst;
  ServicioGps._interno();

  Future<bool> verificarPermisos() async {
    bool activo = await Geolocator.isLocationServiceEnabled();
    if (!activo) return false;
    LocationPermission p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) {
      p = await Geolocator.requestPermission();
    }
    return p == LocationPermission.always || p == LocationPermission.whileInUse;
  }

  Future<PosicionGps?> obtenerPosicion() async {
    if (!await verificarPermisos()) return null;
    try {
      final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high,
              timeLimit: Duration(seconds: 15)));
      return PosicionGps(latitud: pos.latitude, longitud: pos.longitude, precision: pos.accuracy);
    } catch (_) {
      try {
        final pos = await Geolocator.getLastKnownPosition();
        if (pos != null) {
          return PosicionGps(latitud: pos.latitude, longitud: pos.longitude, precision: pos.accuracy);
        }
      } catch (_) {}
      return null;
    }
  }
}

class PosicionGps {
  final double latitud;
  final double longitud;
  final double precision;

  PosicionGps({required this.latitud, required this.longitud, required this.precision});

  @override
  String toString() => '${latitud.toStringAsFixed(6)}, ${longitud.toStringAsFixed(6)}';
}
