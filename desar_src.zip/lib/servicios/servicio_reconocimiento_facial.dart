// /desar/lib/servicios/servicio_reconocimiento_facial.dart
// v4: ML Kit face detector PRIMERO (verifica que haya cara real),
//     luego recorta y pasa a FaceNet.
//     Sin cara detectada → rechaza sin comparar embeddings.

import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import '../modelos/empleado.dart';
import '../base_datos/base_datos_helper.dart';

class ServicioReconocimientoFacial {
  static final ServicioReconocimientoFacial _inst =
      ServicioReconocimientoFacial._interno();
  factory ServicioReconocimientoFacial() => _inst;
  ServicioReconocimientoFacial._interno();

  Interpreter? _interprete;
  bool _cargado      = false;
  String _errorCarga = '';
  int _tamEmbedding  = 512;

  static const int _ancho = 112;
  static const int _alto  = 112;

  // Umbral FaceNet 512-d L2-normalizado:
  // misma persona ≈ 0.3–0.6 | distintas ≈ 1.0–1.4
  double umbral = 0.55;

  // Margen mínimo entre 1er y 2do candidato
  static const double _margenMinimo = 0.10;

  // ML Kit face detector — reutilizar instancia
  final FaceDetector _detector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.accurate,
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.10, // cara mínima 10% del frame
    ),
  );

  static const List<String> _rutasModelo = [
    'assets/modelos_ia/facenet.tflite',
    'assets/modelos_ia/mobilefacenet.tflite',
    'assets/modelos_ia/face_recognition.tflite',
    'assets/modelos_ia/model.tflite',
  ];

  Future<bool> cargarModelo() async {
    if (_cargado) return true;
    _errorCarga = '';
    for (final ruta in _rutasModelo) {
      try {
        await rootBundle.load(ruta);
        final ops = InterpreterOptions()..threads = 2;
        _interprete = await Interpreter.fromAsset(ruta, options: ops);
        final shape = _interprete!.getOutputTensor(0).shape;
        _tamEmbedding = shape.last;
        _cargado = true;
        print('[FACIAL] Modelo OK: $ruta — ${_tamEmbedding}d — umbral=$umbral');
        return true;
      } catch (e) {
        print('[FACIAL] No encontrado: $ruta');
        continue;
      }
    }
    _errorCarga = 'Coloque facenet.tflite en assets/modelos_ia/';
    _cargado = false;
    return false;
  }

  bool   get modeloCargado => _cargado;
  String get errorCarga    => _errorCarga;
  int    get tamEmbedding  => _tamEmbedding;

  // ── Detectar caras con ML Kit ─────────────────────────────
  // Retorna lista de caras detectadas o vacía si no hay ninguna
  Future<List<Face>> detectarCaras(Uint8List bytes) async {
    try {
      // Guardar temporalmente para ML Kit
      final tmpDir = Directory.systemTemp;
      final tmpFile = File('${tmpDir.path}/face_detect_tmp.jpg');
      await tmpFile.writeAsBytes(bytes);
      final inputImage = InputImage.fromFile(tmpFile);
      final caras = await _detector.processImage(inputImage);
      await tmpFile.delete();
      print('[FACIAL] Caras detectadas: ${caras.length}');
      return caras;
    } catch (e) {
      print('[FACIAL] Error detector ML Kit: $e');
      return [];
    }
  }

  // ── Recortar región de la cara de la imagen ───────────────
  Uint8List? _recortarCara(Uint8List bytes, Face cara) {
    try {
      img.Image? imagen = img.decodeImage(bytes);
      if (imagen == null) return null;

      final rect = cara.boundingBox;
      // Añadir margen del 20% alrededor de la cara
      final margen = (rect.width * 0.20).round();
      final x = (rect.left - margen).clamp(0, imagen.width - 1).toInt();
      final y = (rect.top  - margen).clamp(0, imagen.height - 1).toInt();
      final w = (rect.width  + margen * 2).clamp(1, imagen.width  - x).toInt();
      final h = (rect.height + margen * 2).clamp(1, imagen.height - y).toInt();

      final recortada = img.copyCrop(imagen, x: x, y: y, width: w, height: h);
      return Uint8List.fromList(img.encodeJpg(recortada));
    } catch (e) {
      print('[FACIAL] Error recorte: $e');
      return null;
    }
  }

  // ── Generar embedding desde ruta (para registro) ──────────
  Future<List<double>?> generarEmbedding(String ruta) async {
    if (!_cargado) return null;
    try {
      final bytes = await File(ruta).readAsBytes();
      return _generarEmbeddingConDeteccion(bytes);
    } catch (e) {
      print('[FACIAL] Error embedding: $e');
      return null;
    }
  }

  Future<List<double>?> generarEmbeddingBytes(Uint8List bytes) async {
    if (!_cargado) return null;
    return _generarEmbeddingConDeteccion(bytes);
  }

  // Detecta cara primero, recorta, luego genera embedding
  Future<List<double>?> _generarEmbeddingConDeteccion(Uint8List bytes) async {
    // Detectar caras
    final caras = await detectarCaras(bytes);

    Uint8List bytesParaProcesar;
    if (caras.isEmpty) {
      // Sin cara detectada — usar imagen completa con advertencia
      print('[FACIAL] ADVERTENCIA: Sin cara detectada, usando imagen completa');
      bytesParaProcesar = bytes;
    } else {
      // Usar la cara con mayor área (más prominente)
      final cara = caras.reduce((a, b) =>
          a.boundingBox.width * a.boundingBox.height >
          b.boundingBox.width * b.boundingBox.height ? a : b);
      bytesParaProcesar = _recortarCara(bytes, cara) ?? bytes;
    }

    return _procesarBytes(bytesParaProcesar);
  }

  List<double>? _procesarBytes(Uint8List bytes) {
    try {
      img.Image? imagen = img.decodeImage(bytes);
      if (imagen == null) return null;
      imagen = img.copyResize(imagen, width: _ancho, height: _alto);
      final entrada = _aTensor(imagen);
      final salida  = List.filled(_tamEmbedding, 0.0).reshape([1, _tamEmbedding]);
      _interprete!.run(entrada, salida);
      return _normL2(List<double>.from(salida[0] as List));
    } catch (e) {
      print('[FACIAL] Error procesar: $e');
      return null;
    }
  }

  List<List<List<List<double>>>> _aTensor(img.Image imagen) =>
      List.generate(1, (_) =>
          List.generate(_alto, (y) =>
              List.generate(_ancho, (x) {
                final p = imagen.getPixel(x, y);
                return [
                  (p.r / 127.5) - 1.0,
                  (p.g / 127.5) - 1.0,
                  (p.b / 127.5) - 1.0,
                ];
              })));

  List<double> _normL2(List<double> v) {
    final n = sqrt(v.fold(0.0, (s, x) => s + x * x));
    if (n == 0) return v;
    return v.map((x) => x / n).toList();
  }

  double distancia(List<double> a, List<double> b) {
    if (a.length != b.length) return double.infinity;
    double s = 0;
    for (int i = 0; i < a.length; i++) s += (a[i] - b[i]) * (a[i] - b[i]);
    return sqrt(s);
  }

  String        embeddingAJson(List<double> e) => jsonEncode(e);
  List<double>? jsonAEmbedding(String? json) {
    if (json == null || json.isEmpty) return null;
    try {
      return (jsonDecode(json) as List).map((e) => (e as num).toDouble()).toList();
    } catch (_) { return null; }
  }

  // ── Reconocimiento principal ──────────────────────────────
  Future<ResultadoReconocimiento> reconocer(Uint8List bytes) async {
    if (!_cargado) {
      return ResultadoReconocimiento(
          reconocido: false, mensaje: 'Modelo no cargado. $_errorCarga');
    }

    // PASO 1: Detectar cara con ML Kit
    final caras = await detectarCaras(bytes);

    if (caras.isEmpty) {
      return ResultadoReconocimiento(
        reconocido: false,
        mensaje: 'No se detectó ningún rostro. Acérquese a la cámara.',
      );
    }

    if (caras.length > 1) {
      return ResultadoReconocimiento(
        reconocido: false,
        mensaje: 'Múltiples rostros detectados (${caras.length}). Solo un empleado a la vez.',
      );
    }

    // PASO 2: Recortar la cara detectada
    final bytesCaraRecortada = _recortarCara(bytes, caras.first) ?? bytes;

    // PASO 3: Generar embedding de la cara recortada
    final embCapturado = _procesarBytes(bytesCaraRecortada);
    if (embCapturado == null) {
      return ResultadoReconocimiento(
          reconocido: false, mensaje: 'Error procesando imagen');
    }

    // PASO 4: Comparar con empleados registrados
    final empleados = await BaseDatosHelper().obtenerEmpleadosActivos();
    final List<_Candidato> candidatos = [];

    for (final emp in empleados) {
      final embs = [
        jsonAEmbedding(emp.embedding1),
        jsonAEmbedding(emp.embedding2),
        jsonAEmbedding(emp.embedding3),
      ].whereType<List<double>>()
       .where((e) => e.length == _tamEmbedding)
       .toList();

      if (embs.isEmpty) continue;

      // Distancia mínima entre el frame y cualquier embedding del empleado
      double distMin = double.infinity;
      for (final e in embs) {
        final d = distancia(embCapturado, e);
        if (d < distMin) distMin = d;
      }
      candidatos.add(_Candidato(emp, distMin));
    }

    if (candidatos.isEmpty) {
      return ResultadoReconocimiento(
        reconocido: false,
        mensaje: 'Sin empleados con fotos registradas (${_tamEmbedding}d). '
                 'Registre las fotos de los empleados.',
      );
    }

    // Ordenar por distancia
    candidatos.sort((a, b) => a.dist.compareTo(b.dist));
    final mejor   = candidatos.first;
    final segundo = candidatos.length > 1 ? candidatos[1] : null;

    // Log completo para debug
    print('[FACIAL] === Resultados ===');
    for (int i = 0; i < candidatos.length && i < 5; i++) {
      print('[FACIAL]  ${i+1}. ${candidatos[i].emp.nombre}: '
            '${candidatos[i].dist.toStringAsFixed(3)}');
    }
    print('[FACIAL] Umbral=$umbral Margen=$_margenMinimo');

    // Verificar umbral
    if (mejor.dist > umbral) {
      return ResultadoReconocimiento(
        reconocido: false,
        distancia: mejor.dist,
        mensaje: 'Rostro no reconocido '
                 '(dist=${mejor.dist.toStringAsFixed(2)}, '
                 'umbral=$umbral)',
      );
    }

    // Verificar margen entre candidatos
    if (segundo != null) {
      final margen = segundo.dist - mejor.dist;
      if (margen < _margenMinimo) {
        return ResultadoReconocimiento(
          reconocido: false,
          distancia: mejor.dist,
          mensaje: 'Ambigüedad entre candidatos '
                   '(margen=${margen.toStringAsFixed(2)}). '
                   'Ajuste posición.',
        );
      }
    }

    // ✅ Reconocido
    final confianza = ((1.0 - mejor.dist / umbral) * 100).clamp(0.0, 100.0);
    return ResultadoReconocimiento(
      reconocido: true,
      empleado:   mejor.emp,
      distancia:  mejor.dist,
      confianza:  confianza,
      mensaje:    'Identificado: ${mejor.emp.nombre}',
    );
  }

  void liberar() {
    _interprete?.close();
    _interprete = null;
    _cargado    = false;
    _detector.close();
  }
}

class _Candidato {
  final Empleado emp;
  final double   dist;
  _Candidato(this.emp, this.dist);
}

class ResultadoReconocimiento {
  final bool      reconocido;
  final Empleado? empleado;
  final double?   distancia;
  final double?   confianza;
  final String    mensaje;

  ResultadoReconocimiento({
    required this.reconocido,
    this.empleado,
    this.distancia,
    this.confianza,
    required this.mensaje,
  });
}
