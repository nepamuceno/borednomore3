// /desar/lib/servicios/servicio_reportes.dart
// Generacion de reportes Excel, PDF y TXT - 100% offline

import 'dart:io';
import 'package:excel/excel.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import '../base_datos/base_datos_helper.dart';
import '../modelos/jornada.dart';
import '../modelos/registro.dart';
import '../modelos/empleado.dart';
import '../modelos/configuracion.dart';

class ServicioReportes {
  static final ServicioReportes _inst = ServicioReportes._interno();
  factory ServicioReportes() => _inst;
  ServicioReportes._interno();

  final BaseDatosHelper _bd = BaseDatosHelper();
  final DateFormat _fmtHora = DateFormat('HH:mm:ss');
  final DateFormat _fmtFecha = DateFormat('dd/MM/yyyy');

  // Nombre de archivo con timestamp formato aa-mm-dd-hh:mm
  String _nombreArchivo(String ext) {
    final ahora = DateTime.now();
    final ts = DateFormat('yy-MM-dd-HH:mm').format(ahora);
    return '$ts.$ext';
  }

  Future<Directory> _dirReportes() async {
    final doc = await getApplicationDocumentsDirectory();
    final dir = Directory('${doc.path}/reportes');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  // ─────────────────────────────────────────────────────────
  // EXCEL ASISTENCIAS
  // ─────────────────────────────────────────────────────────
  Future<String?> excelAsistencias({
    required String tsInicio,
    required String tsFin,
    int? empleadoId,
    Configuracion? config,
  }) async {
    try {
      // Extraer fechas de los timestamps
      final fi = tsInicio.substring(0, 10);
      final ff = tsFin.substring(0, 10);

      List<Jornada> jornadas;
      if (empleadoId != null) {
        jornadas = await _bd.obtenerJornadasEmpleado(empleadoId, fi, ff);
      } else {
        jornadas = await _bd.obtenerJornadasRango(fi, ff);
      }

      final excel = Excel.createExcel();
      final hoja = excel['Asistencias'];

      final azul = ExcelColor.fromHexString('#1565C0');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final gris = ExcelColor.fromHexString('#F5F5F5');

      final esEnc = CellStyle(
          bold: true,
          backgroundColorHex: azul,
          fontColorHex: blanco,
          horizontalAlign: HorizontalAlign.Center);

      // Fila 0: titulo compania
      hoja.merge(CellIndex.indexByString('A1'), CellIndex.indexByString('I1'));
      hoja.cell(CellIndex.indexByString('A1'))
        ..value = TextCellValue(config?.nombreCompania ?? 'DESAR')
        ..cellStyle = CellStyle(bold: true, fontSize: 14, horizontalAlign: HorizontalAlign.Center);

      // Fila 1: periodo
      hoja.merge(CellIndex.indexByString('A2'), CellIndex.indexByString('I2'));
      hoja.cell(CellIndex.indexByString('A2'))
        ..value = TextCellValue('Reporte de Asistencias: $fi al $ff')
        ..cellStyle = CellStyle(horizontalAlign: HorizontalAlign.Center);

      // Encabezados fila 3
      final enc = ['Código', 'Nombre', 'Fecha', 'Entrada', 'Salida', 'Horas', 'Completa', 'Sitio', 'Método'];
      for (int i = 0; i < enc.length; i++) {
        hoja.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 3))
          ..value = TextCellValue(enc[i])
          ..cellStyle = esEnc;
      }

      for (int i = 0; i < jornadas.length; i++) {
        final j = jornadas[i];
        final fila = i + 4;
        final esF = CellStyle(backgroundColorHex: i % 2 == 0 ? gris : blanco);

        void c(int col, String val) {
          hoja.cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: fila))
            ..value = TextCellValue(val)
            ..cellStyle = esF;
        }

        c(0, j.codigoEmpleado);
        c(1, j.nombreEmpleado);
        c(2, j.fecha);
        c(3, j.entradaTimestamp != null ? _fmtHora.format(DateTime.parse(j.entradaTimestamp!)) : '---');
        c(4, j.salidaTimestamp != null ? _fmtHora.format(DateTime.parse(j.salidaTimestamp!)) : '---');
        c(5, j.horasFormateadas);
        c(6, j.estaCompleta ? 'Sí' : 'No');
        c(7, j.sitioTrabajo ?? '---');
        c(8, '---');
      }

      // Totales
      final ft = jornadas.length + 4;
      final totalH = jornadas.where((j) => j.horasTrabajadas != null)
          .fold<double>(0, (s, j) => s + j.horasTrabajadas!);
      hoja.cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: ft))
        ..value = TextCellValue('TOTAL')
        ..cellStyle = CellStyle(bold: true);
      hoja.cell(CellIndex.indexByColumnRow(columnIndex: 5, rowIndex: ft))
        ..value = TextCellValue('${totalH.toStringAsFixed(1)}h')
        ..cellStyle = CellStyle(bold: true);

      // Anchos
      for (int i = 0; i < [10, 25, 12, 10, 10, 10, 10, 20, 10].length; i++) {
        hoja.setColumnWidth(i, [10.0, 25.0, 12.0, 10.0, 10.0, 10.0, 10.0, 20.0, 10.0][i]);
      }

      final dir = await _dirReportes();
      final ruta = '${dir.path}/${_nombreArchivo('xlsx')}';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      print('[REPORTES] Excel: $ruta');
      return ruta;
    } catch (e) {
      print('[REPORTES] Error Excel: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // EXCEL EMPLEADOS
  // ─────────────────────────────────────────────────────────
  Future<String?> excelEmpleados({List<Empleado>? listaEmpleados}) async {
    try {
      final empleados = listaEmpleados ?? await _bd.obtenerTodosEmpleados();
      final excel = Excel.createExcel();
      final hoja = excel['Empleados'];

      final verde = ExcelColor.fromHexString('#1B5E20');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final gris = ExcelColor.fromHexString('#F5F5F5');
      final esEnc = CellStyle(bold: true, backgroundColorHex: verde, fontColorHex: blanco, horizontalAlign: HorizontalAlign.Center);

      final enc = ['ID', 'Código', 'Nombre', 'No. ID', 'Seg. Social', 'F. Nacimiento', 'Sitio', 'Estado', 'F. Registro'];
      for (int i = 0; i < enc.length; i++) {
        hoja.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0))
          ..value = TextCellValue(enc[i])
          ..cellStyle = esEnc;
      }

      for (int i = 0; i < empleados.length; i++) {
        final e = empleados[i];
        final fila = i + 1;
        final esF = CellStyle(backgroundColorHex: i % 2 == 0 ? gris : blanco);

        void c(int col, String val) {
          hoja.cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: fila))
            ..value = TextCellValue(val)
            ..cellStyle = esF;
        }

        c(0, '${e.id ?? ''}');
        c(1, e.codigoEmpleado);
        c(2, e.nombre);
        c(3, e.numeroIdentificacion ?? '---');
        c(4, e.seguroSocial ?? '---');
        c(5, e.fechaNacimiento ?? '---');
        c(6, e.sitioTrabajo ?? '---');
        c(7, e.estaActivo ? 'Activo' : 'Inactivo');
        c(8, e.fechaRegistro?.substring(0, 10) ?? '---');
      }

      for (int i = 0; i < [6.0, 12.0, 25.0, 18.0, 18.0, 14.0, 18.0, 10.0, 14.0].length; i++) {
        hoja.setColumnWidth(i, [6.0, 12.0, 25.0, 18.0, 18.0, 14.0, 18.0, 10.0, 14.0][i]);
      }

      final dir = await _dirReportes();
      final ruta = '${dir.path}/${_nombreArchivo('xlsx')}';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      return ruta;
    } catch (e) {
      print('[REPORTES] Error Excel empleados: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // PDF ASISTENCIAS
  // ─────────────────────────────────────────────────────────
  Future<String?> pdfAsistencias({
    required String tsInicio,
    required String tsFin,
    int? empleadoId,
    Configuracion? config,
  }) async {
    try {
      final fi = tsInicio.substring(0, 10);
      final ff = tsFin.substring(0, 10);

      List<Jornada> jornadas;
      if (empleadoId != null) {
        jornadas = await _bd.obtenerJornadasEmpleado(empleadoId, fi, ff);
      } else {
        jornadas = await _bd.obtenerJornadasRango(fi, ff);
      }

      final pdf = pw.Document();
      final azul = PdfColor.fromHex('#1565C0');
      final azulClar = PdfColor.fromHex('#BBDEFB');

      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(24),
        build: (ctx) => [
          pw.Container(
            color: azul,
            padding: const pw.EdgeInsets.all(12),
            child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
              pw.Text(config?.nombreCompania ?? 'DESAR',
                  style: pw.TextStyle(color: PdfColors.white, fontSize: 16, fontWeight: pw.FontWeight.bold)),
              pw.Text('Reporte Asistencias',
                  style: pw.TextStyle(color: PdfColor.fromInt(0xFFB3B3B3), fontSize: 11)),
            ]),
          ),
          pw.SizedBox(height: 6),
          pw.Text('Período: $fi al $ff', style: const pw.TextStyle(fontSize: 10)),
          pw.Text('Generado: ${_fmtFecha.format(DateTime.now())} ${_fmtHora.format(DateTime.now())}',
              style: const pw.TextStyle(fontSize: 9)),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {
              0: const pw.FixedColumnWidth(48),
              1: const pw.FixedColumnWidth(90),
              2: const pw.FixedColumnWidth(52),
              3: const pw.FixedColumnWidth(42),
              4: const pw.FixedColumnWidth(42),
              5: const pw.FixedColumnWidth(38),
              6: const pw.FixedColumnWidth(65),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: azulClar),
                children: ['Código', 'Nombre', 'Fecha', 'Entrada', 'Salida', 'Horas', 'Sitio']
                    .map((t) => pw.Padding(
                          padding: const pw.EdgeInsets.all(4),
                          child: pw.Text(t,
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 8)),
                        ))
                    .toList(),
              ),
              ...jornadas.asMap().entries.map((e) {
                final j = e.value;
                final cf = e.key % 2 == 0 ? PdfColors.white : PdfColor.fromHex('#F5F5F5');
                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: cf),
                  children: [
                    j.codigoEmpleado,
                    j.nombreEmpleado,
                    j.fecha,
                    j.entradaTimestamp != null ? _fmtHora.format(DateTime.parse(j.entradaTimestamp!)) : '---',
                    j.salidaTimestamp != null ? _fmtHora.format(DateTime.parse(j.salidaTimestamp!)) : '---',
                    j.horasFormateadas,
                    j.sitioTrabajo ?? '---',
                  ].map((t) => pw.Padding(
                        padding: const pw.EdgeInsets.all(3),
                        child: pw.Text(t, style: const pw.TextStyle(fontSize: 7)),
                      )).toList(),
                );
              }),
            ],
          ),
          pw.SizedBox(height: 8),
          pw.Text(
              'Total: ${jornadas.length} registros  |  '
              'Completas: ${jornadas.where((j) => j.estaCompleta).length}  |  '
              'Horas: ${jornadas.where((j) => j.horasTrabajadas != null).fold<double>(0, (s, j) => s + j.horasTrabajadas!).toStringAsFixed(1)}h',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9)),
        ],
      ));

      final dir = await _dirReportes();
      final ruta = '${dir.path}/${_nombreArchivo('pdf')}';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[REPORTES] PDF: $ruta');
      return ruta;
    } catch (e) {
      print('[REPORTES] Error PDF: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // PDF EMPLEADOS
  // ─────────────────────────────────────────────────────────
  Future<String?> pdfEmpleados({List<Empleado>? listaEmpleados, Configuracion? config}) async {
    try {
      final empleados = listaEmpleados ?? await _bd.obtenerTodosEmpleados();
      final pdf = pw.Document();
      final azul = PdfColor.fromHex('#1565C0');
      final azulClar = PdfColor.fromHex('#BBDEFB');

      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(24),
        build: (ctx) => [
          pw.Container(
            color: azul,
            padding: const pw.EdgeInsets.all(12),
            child: pw.Text(config?.nombreCompania ?? 'DESAR',
                style: pw.TextStyle(color: PdfColors.white, fontSize: 16, fontWeight: pw.FontWeight.bold)),
          ),
          pw.SizedBox(height: 8),
          pw.Text('Lista de Empleados', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {
              0: const pw.FixedColumnWidth(45),
              1: const pw.FixedColumnWidth(80),
              2: const pw.FixedColumnWidth(55),
              3: const pw.FixedColumnWidth(55),
              4: const pw.FixedColumnWidth(50),
              5: const pw.FixedColumnWidth(40),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: azulClar),
                children: ['Código', 'Nombre', 'No. ID', 'Seg. Social', 'Sitio', 'Estado']
                    .map((t) => pw.Padding(
                          padding: const pw.EdgeInsets.all(4),
                          child: pw.Text(t, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 8)),
                        ))
                    .toList(),
              ),
              ...empleados.asMap().entries.map((e) {
                final emp = e.value;
                final cf = e.key % 2 == 0 ? PdfColors.white : PdfColor.fromHex('#F5F5F5');
                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: cf),
                  children: [
                    emp.codigoEmpleado,
                    emp.nombre,
                    emp.numeroIdentificacion ?? '---',
                    emp.seguroSocial ?? '---',
                    emp.sitioTrabajo ?? '---',
                    emp.estaActivo ? 'Activo' : 'Inactivo',
                  ].map((t) => pw.Padding(
                        padding: const pw.EdgeInsets.all(3),
                        child: pw.Text(t, style: const pw.TextStyle(fontSize: 7)),
                      )).toList(),
                );
              }),
            ],
          ),
        ],
      ));

      final dir = await _dirReportes();
      final ruta = '${dir.path}/${_nombreArchivo('pdf')}';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) {
      print('[REPORTES] Error PDF empleados: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // TXT ASISTENCIAS
  // ─────────────────────────────────────────────────────────
  Future<String?> txtAsistencias({required String tsInicio, required String tsFin}) async {
    try {
      final fi = tsInicio.substring(0, 10);
      final ff = tsFin.substring(0, 10);
      final jornadas = await _bd.obtenerJornadasRango(fi, ff);
      final buf = StringBuffer();
      final sep = '=' * 72;

      buf.writeln(sep);
      buf.writeln('  REPORTE DE ASISTENCIAS');
      buf.writeln('  Período: $fi al $ff');
      buf.writeln('  Generado: ${DateTime.now().toIso8601String()}');
      buf.writeln(sep);

      String? fechaActual;
      for (final j in jornadas) {
        if (j.fecha != fechaActual) {
          fechaActual = j.fecha;
          buf.writeln('\n  --- $fechaActual ---');
          buf.writeln('  ${'CÓDIGO'.padRight(12)} ${'NOMBRE'.padRight(26)} ${'ENTRADA'.padRight(10)} ${'SALIDA'.padRight(10)} HORAS');
          buf.writeln('  ${'-' * 66}');
        }
        final en = j.entradaTimestamp != null ? _fmtHora.format(DateTime.parse(j.entradaTimestamp!)) : '---      ';
        final sa = j.salidaTimestamp != null ? _fmtHora.format(DateTime.parse(j.salidaTimestamp!)) : '---      ';
        buf.writeln('  ${j.codigoEmpleado.padRight(12)} ${j.nombreEmpleado.padRight(26)} ${en.padRight(10)} ${sa.padRight(10)} ${j.horasFormateadas}');
      }

      buf.writeln('\n$sep');
      buf.writeln('  Total: ${jornadas.length} registros  |  Completas: ${jornadas.where((j) => j.estaCompleta).length}');
      buf.writeln(sep);

      final dir = await _dirReportes();
      final ruta = '${dir.path}/${_nombreArchivo('txt')}';
      await File(ruta).writeAsString(buf.toString());
      return ruta;
    } catch (e) {
      print('[REPORTES] Error TXT: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // LISTA DE ARCHIVOS GENERADOS
  // ─────────────────────────────────────────────────────────
  Future<List<ArchivoReporte>> listar() async {
    try {
      final dir = await _dirReportes();
      final archivos = dir
          .listSync()
          .whereType<File>()
          .map((f) => ArchivoReporte(
                ruta: f.path,
                nombre: f.path.split('/').last,
                tamanio: f.lengthSync(),
                fecha: f.statSync().modified,
              ))
          .toList();
      archivos.sort((a, b) => b.fecha.compareTo(a.fecha));
      return archivos;
    } catch (_) {
      return [];
    }
  }
  // ─────────────────────────────────────────────────────────
  // SQL DUMP COMPLETO
  // ─────────────────────────────────────────────────────────

  // ── Registros individuales Excel ─────────────────────────────
  Future<String?> excelRegistros({
    required String tsInicio, required String tsFin,
    int? empleadoId, Configuracion? config,
  }) async {
    try {
      List<Registro> registros;
      if (empleadoId != null) {
        registros = await _bd.obtenerRegistrosPorEmpleado(
            empleadoId, tsInicio.substring(0, 10), tsFin.substring(0, 10));
      } else {
        registros = await _bd.obtenerRegistrosPorRango(tsInicio, tsFin);
      }
      final fi   = tsInicio.substring(0, 10);
      final ff   = tsFin.substring(0, 10);
      final excel = Excel.createExcel();
      final hoja  = excel['Registros'];
      final azul   = ExcelColor.fromHexString('#1565C0');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final verde  = ExcelColor.fromHexString('#E8F5E9');
      final rojo   = ExcelColor.fromHexString('#FFEBEE');

      hoja.merge(CellIndex.indexByString('A1'), CellIndex.indexByString('J1'));
      hoja.cell(CellIndex.indexByString('A1'))
        ..value = TextCellValue(config?.nombreCompania ?? 'DESAR')
        ..cellStyle = CellStyle(bold: true, fontSize: 14, horizontalAlign: HorizontalAlign.Center);
      hoja.merge(CellIndex.indexByString('A2'), CellIndex.indexByString('J2'));
      hoja.cell(CellIndex.indexByString('A2'))
        ..value = TextCellValue('Registros de Asistencia: $fi al $ff')
        ..cellStyle = CellStyle(horizontalAlign: HorizontalAlign.Center);

      final enc = ['Código','Nombre','Fecha','Hora','Tipo','Método','Sitio','GPS Lat','GPS Lon','Notas'];
      for (int i = 0; i < enc.length; i++) {
        hoja.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 3))
          ..value = TextCellValue(enc[i])
          ..cellStyle = CellStyle(bold: true, backgroundColorHex: azul, fontColorHex: blanco,
              horizontalAlign: HorizontalAlign.Center);
      }
      final widths = [10.0, 25.0, 12.0, 10.0, 10.0, 12.0, 18.0, 12.0, 12.0, 20.0];
      for (int wi = 0; wi < widths.length; wi++) hoja.setColumnWidth(wi, widths[wi]);

      for (int i = 0; i < registros.length; i++) {
        final r    = registros[i];
        final fila = i + 4;
        final bg   = r.tipo == 'entrada' ? verde : rojo;
        final dt   = DateTime.parse(r.timestamp);
        final hora = '\${dt.hour.toString().padLeft(2,"0")}:\${dt.minute.toString().padLeft(2,"0")}:\${dt.second.toString().padLeft(2,"0")}';
        final vals = [r.codigoEmpleado, r.nombreEmpleado, r.timestamp.substring(0,10),
            hora, r.tipo.toUpperCase(), r.metodo, r.sitioTrabajo ?? '---',
            r.gpsLat?.toStringAsFixed(6) ?? '', r.gpsLon?.toStringAsFixed(6) ?? '', r.notas ?? ''];
        for (int ci = 0; ci < vals.length; ci++) {
          hoja.cell(CellIndex.indexByColumnRow(columnIndex: ci, rowIndex: fila))
            ..value = TextCellValue(vals[ci])
            ..cellStyle = CellStyle(backgroundColorHex: bg);
        }
      }
      hoja.cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: registros.length + 4))
        ..value = TextCellValue('Total: \${registros.length} registros')
        ..cellStyle = CellStyle(bold: true);

      final dir   = await _dirReportes();
      final ruta  = '\${dir.path}/registros-\${DateFormat("yyyyMMdd-HHmm").format(DateTime.now())}.xlsx';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      return ruta;
    } catch (e) { print('[REP] Error registros xls: \$e'); return null; }
  }

  // ── Registros individuales PDF ───────────────────────────────
  Future<String?> pdfRegistros({
    required String tsInicio, required String tsFin,
    int? empleadoId, Configuracion? config,
  }) async {
    try {
      List<Registro> registros;
      if (empleadoId != null) {
        registros = await _bd.obtenerRegistrosPorEmpleado(
            empleadoId, tsInicio.substring(0, 10), tsFin.substring(0, 10));
      } else {
        registros = await _bd.obtenerRegistrosPorRango(tsInicio, tsFin);
      }
      final cfg  = config ?? await _bd.obtenerConfiguracion();
      final fi   = tsInicio.substring(0, 10);
      final ff   = tsFin.substring(0, 10);
      final pdf  = pw.Document();
      final azul = PdfColor.fromHex('#1565C0');

      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(20),
        build: (ctx) => [
          pw.Container(color: azul, padding: const pw.EdgeInsets.all(10),
            child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
              pw.Text('Registros de Asistencia',
                  style: pw.TextStyle(color: PdfColors.white, fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.Text('\$fi al \$ff', style: const pw.TextStyle(color: PdfColors.white, fontSize: 9)),
            ])),
          pw.SizedBox(height: 4),
          pw.Text('\${cfg.nombreCompania}  |  \${registros.length} registros',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey)),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {
              0: const pw.FixedColumnWidth(40), 1: const pw.FixedColumnWidth(68),
              2: const pw.FixedColumnWidth(30), 3: const pw.FixedColumnWidth(26),
              4: const pw.FixedColumnWidth(26), 5: const pw.FixedColumnWidth(28),
              6: const pw.FixedColumnWidth(50),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: PdfColor.fromHex('#BBDEFB')),
                children: ['Código','Nombre','Fecha','Hora','Tipo','Método','Sitio']
                    .map((t) => pw.Padding(padding: const pw.EdgeInsets.all(3),
                        child: pw.Text(t, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 7))))
                    .toList()),
              ...registros.map((r) {
                final dt  = DateTime.parse(r.timestamp);
                final hora = '\${dt.hour.toString().padLeft(2,"0")}:\${dt.minute.toString().padLeft(2,"0")}';
                final bg  = r.tipo == 'entrada'
                    ? PdfColor.fromHex('#E8F5E9') : PdfColor.fromHex('#FFEBEE');
                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: bg),
                  children: [r.codigoEmpleado, r.nombreEmpleado,
                    r.timestamp.substring(0,10), hora,
                    r.tipo.toUpperCase(), r.metodo, r.sitioTrabajo ?? '---']
                      .map((t) => pw.Padding(padding: const pw.EdgeInsets.all(2),
                          child: pw.Text(t, style: const pw.TextStyle(fontSize: 6)))).toList());
              }),
            ],
          ),
        ],
      ));
      final dir  = await _dirReportes();
      final ruta = '\${dir.path}/registros-\${DateFormat("yyyyMMdd-HHmm").format(DateTime.now())}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) { print('[REP] Error registros pdf: \$e'); return null; }
  }

  Future<String?> sqlDumpCompleto() async {
    try {
      final sql = await _bd.generarSqlDump();
      final dir = await _dirReportes();
      final ahora = DateTime.now();
      final nombre = 'datos-\${ahora.year}-\${ahora.month.toString().padLeft(2,"0")}-\${ahora.day.toString().padLeft(2,"0")}.sql';
      final ruta = '\${dir.path}/\$nombre';
      await File(ruta).writeAsString(sql);
      print('[REPORTES] SQL dump: \$ruta');
      return ruta;
    } catch (e) {
      print('[REPORTES] Error SQL dump: \$e');
      return null;
    }
  }


  // ── Catálogo Gafetes Excel ───────────────────────────────────
  Future<String?> excelCatalogoGafetes({List<Empleado>? listaEmpleados}) async {
    try {
      final empleados = listaEmpleados ?? await _bd.obtenerTodosEmpleados();
      final excel = Excel.createExcel();
      final hoja  = excel['Gafetes'];
      final azul   = ExcelColor.fromHexString('#1565C0');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final gris   = ExcelColor.fromHexString('#F5F5F5');
      final cabs = ['Código','Nombre','Puesto','Área','Alta','Vencimiento',
                    'IMSS','RFC','ID','Sangre','Teléfono','Activo'];
      for (int c = 0; c < cabs.length; c++) {
        final cell = hoja.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: 0));
        cell.value = TextCellValue(cabs[c]);
        cell.cellStyle = CellStyle(bold: true, fontColorHex: blanco,
            backgroundColorHex: azul, horizontalAlign: HorizontalAlign.Center);
        hoja.setColumnWidth(c, c < 2 ? 20.0 : 14.0);
      }
      for (int i = 0; i < empleados.length; i++) {
        final e   = empleados[i];
        final bg  = (i + 1) % 2 == 0 ? gris : ExcelColor.fromHexString('#FFFFFF');
        final vals = [e.codigoEmpleado, e.nombre, e.puesto ?? '', e.sitioTrabajo ?? '',
                      e.fechaAlta ?? '', e.fechaVencimiento ?? '',
                      e.seguroSocial ?? '', e.rfc ?? '', e.numeroIdentificacion ?? '',
                      e.tipoSangre ?? '', e.telefono ?? '',
                      e.estaActivo ? 'Activo' : 'Baja'];
        for (int c = 0; c < vals.length; c++) {
          final cell = hoja.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: i + 1));
          cell.value = TextCellValue(vals[c]);
          cell.cellStyle = CellStyle(backgroundColorHex: bg);
        }
      }
      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '\${dir.path}/catalogo-gafetes-\$ts.xlsx';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      return ruta;
    } catch (e) { print('[REP] Error cat gafetes xls: \$e'); return null; }
  }

  // ── Catálogo QR Excel ────────────────────────────────────────
  Future<String?> excelCatalogoQr({List<Empleado>? listaEmpleados}) async {
    try {
      final empleados = listaEmpleados ?? await _bd.obtenerTodosEmpleados();
      final excel = Excel.createExcel();
      final hoja  = excel['Códigos QR'];
      final azul   = ExcelColor.fromHexString('#1565C0');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final gris   = ExcelColor.fromHexString('#F5F5F5');
      final cabs = ['Código','Nombre','Puesto','Contenido QR','Alta','Vencimiento'];
      for (int c = 0; c < cabs.length; c++) {
        final cell = hoja.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: 0));
        cell.value = TextCellValue(cabs[c]);
        cell.cellStyle = CellStyle(bold: true, fontColorHex: blanco,
            backgroundColorHex: azul, horizontalAlign: HorizontalAlign.Center);
        hoja.setColumnWidth(c, c == 3 ? 32.0 : 18.0);
      }
      for (int i = 0; i < empleados.length; i++) {
        final e   = empleados[i];
        final bg  = (i + 1) % 2 == 0 ? gris : ExcelColor.fromHexString('#FFFFFF');
        final qr  = 'CHECADOR:\${e.codigoEmpleado}:\${e.nombre}';
        final vals = [e.codigoEmpleado, e.nombre, e.puesto ?? '', qr,
                      e.fechaAlta ?? '', e.fechaVencimiento ?? ''];
        for (int c = 0; c < vals.length; c++) {
          final cell = hoja.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: i + 1));
          cell.value = TextCellValue(vals[c]);
          cell.cellStyle = CellStyle(backgroundColorHex: bg);
        }
      }
      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '\${dir.path}/catalogo-qr-\$ts.xlsx';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      return ruta;
    } catch (e) { print('[REP] Error cat qr xls: \$e'); return null; }
  }


  // ── Catálogo combinado Empleados + Gafete PDF ────────────────
  // Una página A4 por empleado: datos completos a la izquierda + gafete CR80 a la derecha
  Future<String?> pdfCatalogoEmpleadosGafetes({
    List<Empleado>? listaEmpleados,
    Configuracion? config,
  }) async {
    try {
      final empleados = listaEmpleados ?? await _bd.obtenerTodosEmpleados();
      final cfg       = config ?? await _bd.obtenerConfiguracion();
      final pdf       = pw.Document();

      final colorP  = PdfColor.fromHex('#1565C0');
      final colorS  = PdfColor.fromHex('#E3F2FD');
      final colorGr = PdfColor.fromHex('#757575');
      final colorTx = PdfColor.fromHex('#212121');

      // Ancho CR80 en puntos
      const gfAncho = 242.5;
      const gfAlto  = 153.1;

      for (final emp in empleados) {
        // Cargar foto si existe
        pw.ImageProvider? fotoEmp;
        final fotoPath = emp.fotoRostro1 ?? emp.fotoPerfil;
        if (fotoPath != null) {
          try { fotoEmp = pw.MemoryImage(await File(fotoPath).readAsBytes()); } catch (_) {}
        }
        pw.ImageProvider? logoImg;
        if (cfg.logoCompania != null) {
          try { logoImg = pw.MemoryImage(await File(cfg.logoCompania!).readAsBytes()); } catch (_) {}
        }

        pdf.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(20),
          build: (ctx) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // ── Encabezado ──
              pw.Container(
                width: double.infinity, color: colorP,
                padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                      pw.Text(cfg.nombreCompania,
                          style: pw.TextStyle(color: PdfColors.white, fontSize: 12,
                              fontWeight: pw.FontWeight.bold)),
                      pw.Text('Catálogo de Empleados con Gafete',
                          style: const pw.TextStyle(color: PdfColors.white, fontSize: 8)),
                      pw.Text(DateFormat('dd/MM/yyyy').format(DateTime.now()),
                          style: const pw.TextStyle(color: PdfColors.white, fontSize: 7)),
                    ]),
                    if (logoImg != null)
                      pw.Image(logoImg, width: 40, height: 28, fit: pw.BoxFit.contain),
                  ],
                ),
              ),
              pw.SizedBox(height: 12),

              // ── Contenido principal: datos izquierda + gafete derecha ──
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  // COLUMNA IZQUIERDA — datos del empleado
                  pw.Expanded(
                    flex: 3,
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        // Foto y nombre
                        pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                          pw.Container(
                            width: 60, height: 60,
                            decoration: pw.BoxDecoration(
                              border: pw.Border.all(color: colorP, width: 1.5),
                              color: colorS,
                            ),
                            child: fotoEmp != null
                                ? pw.Image(fotoEmp, fit: pw.BoxFit.cover)
                                : pw.Center(child: pw.Text(
                                    emp.nombre.isNotEmpty ? emp.nombre[0].toUpperCase() : '?',
                                    style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold,
                                        color: colorP))),
                          ),
                          pw.SizedBox(width: 10),
                          pw.Expanded(child: pw.Column(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            children: [
                              pw.Text(emp.nombre,
                                  style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold,
                                      color: colorTx)),
                              if (emp.puesto != null)
                                pw.Text(emp.puesto!,
                                    style: pw.TextStyle(fontSize: 10, color: colorP,
                                        fontWeight: pw.FontWeight.bold)),
                              pw.Text(emp.estaActivo ? '● Activo' : '○ Baja',
                                  style: pw.TextStyle(fontSize: 9,
                                      color: emp.estaActivo ? PdfColors.green : PdfColors.red)),
                            ],
                          )),
                        ]),
                        pw.SizedBox(height: 10),
                        pw.Divider(color: colorP, thickness: 0.5),
                        pw.SizedBox(height: 6),

                        // Datos en 2 columnas
                        pw.Row(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Expanded(child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                _fila('No. Empleado', emp.codigoEmpleado),
                                _fila('IMSS', emp.seguroSocial),
                                _fila('RFC', emp.rfc),
                                _fila('No. ID', emp.numeroIdentificacion),
                                _fila('Área', emp.sitioTrabajo),
                                _fila('Tel.', emp.telefono),
                                _fila('Emergencia', emp.telefonoEmergencia),
                              ],
                            )),
                            pw.SizedBox(width: 8),
                            pw.Expanded(child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                _fila('F. Nacimiento', emp.fechaNacimiento),
                                _fila('Sangre', emp.tipoSangre),
                                _fila('F. Alta', emp.fechaAlta),
                                _fila('F. Vencimiento', emp.fechaVencimiento),
                                _fila('Ciudad', emp.ciudad),
                                _fila('Estado', emp.estado),
                                _fila('País', emp.pais),
                              ],
                            )),
                          ],
                        ),

                        if (emp.notas != null) ...[
                          pw.SizedBox(height: 6),
                          pw.Container(
                            width: double.infinity,
                            color: colorS,
                            padding: const pw.EdgeInsets.all(5),
                            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                              pw.Text('Notas:', style: pw.TextStyle(fontSize: 7, color: colorGr)),
                              pw.Text(emp.notas!,
                                  style: const pw.TextStyle(fontSize: 7)),
                            ]),
                          ),
                        ],

                        pw.SizedBox(height: 12),

                        // Líneas de firma
                        pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            _firmaLinea('Autoriza', 120),
                            _firmaLinea('Empleado', 120),
                          ],
                        ),
                      ],
                    ),
                  ),

                  pw.SizedBox(width: 16),

                  // COLUMNA DERECHA — gafete CR80 + QR
                  pw.Column(
                    children: [
                      pw.Text('GAFETE CR80', style: pw.TextStyle(fontSize: 7,
                          color: colorGr, fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 4),
                      // Frente del gafete
                      pw.Container(
                        width: gfAncho, height: gfAlto,
                        decoration: pw.BoxDecoration(
                          border: pw.Border.all(color: PdfColors.grey400),
                          borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4)),
                        ),
                        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                          pw.Container(width: double.infinity, color: colorP,
                            padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 4),
                            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                              if (logoImg != null) pw.Image(logoImg, width: 20, height: 13, fit: pw.BoxFit.contain),
                              pw.Text(cfg.nombreCompania, textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(color: PdfColors.white, fontSize: 6,
                                      fontWeight: pw.FontWeight.bold)),
                            ])),
                          pw.SizedBox(height: 3),
                          pw.Container(width: 44, height: 44,
                            decoration: pw.BoxDecoration(
                              border: pw.Border.all(color: colorP, width: 1), color: colorS),
                            child: fotoEmp != null
                                ? pw.Image(fotoEmp, fit: pw.BoxFit.cover)
                                : pw.Center(child: pw.Text('FOTO',
                                    style: pw.TextStyle(fontSize: 5, color: colorGr))),
                          ),
                          pw.SizedBox(height: 2),
                          pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                              style: pw.TextStyle(fontSize: 6.5, fontWeight: pw.FontWeight.bold)),
                          if (emp.puesto != null)
                            pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                                style: pw.TextStyle(fontSize: 5.5, color: colorP)),
                          pw.Text('No. \${emp.codigoEmpleado}',
                              style: pw.TextStyle(fontSize: 6, fontWeight: pw.FontWeight.bold)),
                          if (emp.fechaAlta != null)
                            pw.Text('Alta: \${_fmt(emp.fechaAlta!)}',
                                style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
                          if (emp.fechaVencimiento != null)
                            pw.Text('Vence: \${_fmt(emp.fechaVencimiento!)}',
                                style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
                          pw.Expanded(child: pw.SizedBox()),
                          pw.Container(width: double.infinity, color: colorS,
                            padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                              children: [
                                _gfFirma('Autoriza', 68),
                                _gfFirma('Empleado', 68),
                              ])),
                        ]),
                      ),
                      pw.SizedBox(height: 8),
                      pw.Text('REVERSO / QR', style: pw.TextStyle(fontSize: 7,
                          color: colorGr, fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 4),
                      // Reverso con QR
                      pw.Container(
                        width: gfAncho, height: gfAlto,
                        decoration: pw.BoxDecoration(
                          border: pw.Border.all(color: PdfColors.grey400),
                          borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4)),
                        ),
                        child: pw.Column(
                          mainAxisAlignment: pw.MainAxisAlignment.center,
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.BarcodeWidget(
                              barcode: pw.Barcode.qrCode(),
                              data: 'CHECADOR:\${emp.codigoEmpleado}:\${emp.nombre}',
                              width: 88, height: 88, color: PdfColors.black),
                            pw.SizedBox(height: 4),
                            pw.Text(emp.codigoEmpleado,
                                style: pw.TextStyle(fontSize: 8,
                                    fontWeight: pw.FontWeight.bold, letterSpacing: 2)),
                            pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                                style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ));
      }

      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '\${dir.path}/catalogo-empleados-gafetes-\$ts.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[REPORTES] Catálogo empleados+gafetes: \$ruta');
      return ruta;
    } catch (e) {
      print('[REPORTES] Error catálogo emp+gafetes: \$e');
      return null;
    }
  }

  // Helpers privados para el catálogo
  pw.Widget _fila(String label, String? valor) {
    if (valor == null || valor.isEmpty) return pw.SizedBox();
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 2),
      child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.SizedBox(width: 60, child: pw.Text('$label:',
            style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey))),
        pw.Expanded(child: pw.Text(valor,
            style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold))),
      ]),
    );
  }

  pw.Widget _firmaLinea(String label, double ancho) => pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.center,
    children: [
      pw.Container(width: ancho, height: 0.5, color: PdfColors.grey700),
      pw.SizedBox(height: 2),
      pw.Text(label, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey)),
    ],
  );

  pw.Widget _gfFirma(String label, double ancho) => pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.center,
    children: [
      pw.Container(width: ancho, height: 0.5, color: PdfColors.grey700),
      pw.SizedBox(height: 1),
      pw.Text(label, style: const pw.TextStyle(fontSize: 5, color: PdfColors.grey)),
    ],
  );

  String _fmt(String iso) {
    try { return DateFormat('dd/MM/yyyy').format(DateTime.parse(iso)); }
    catch (_) { return iso; }
  }

  // ─────────────────────────────────────────────────────────
  // SQL DUMP MOVIMIENTOS
  // ─────────────────────────────────────────────────────────
  Future<String?> sqlDumpMovimientos() async {
    try {
      final sql = await _bd.generarSqlDumpMovimientos();
      final dir = await _dirReportes();
      final ahora = DateTime.now();
      final nombre = 'movimientos-\${ahora.year}-\${ahora.month.toString().padLeft(2,"0")}-\${ahora.day.toString().padLeft(2,"0")}.sql';
      final ruta = '\${dir.path}/\$nombre';
      await File(ruta).writeAsString(sql);
      print('[REPORTES] SQL movimientos: \$ruta');
      return ruta;
    } catch (e) {
      print('[REPORTES] Error SQL movimientos: \$e');
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────
  // IMPORTAR SQL
  // ─────────────────────────────────────────────────────────
  Future<bool> importarSql(String rutaArchivo) async {
    try {
      final sql = await File(rutaArchivo).readAsString();
      await _bd.importarSql(sql);
      return true;
    } catch (e) {
      print('[REPORTES] Error importando SQL: \$e');
      return false;
    }
  }


  // ── Tardanzas y Ausencias Excel ──────────────────────────────
  Future<String?> excelTardanzasAusencias({
    required String tsInicio, required String tsFin,
  }) async {
    try {
      final fi = tsInicio.substring(0, 10);
      final ff = tsFin.substring(0, 10);
      final jornadas  = await _bd.obtenerJornadasRango(fi, ff);
      final empleados = await _bd.obtenerEmpleadosActivos();
      final cfg       = await _bd.obtenerConfiguracion();
      final excel = Excel.createExcel();
      final hoja  = excel['Tardanzas'];
      final azul   = ExcelColor.fromHexString('#1565C0');
      final blanco = ExcelColor.fromHexString('#FFFFFF');
      final ama    = ExcelColor.fromHexString('#FFF9C4');

      final cabs = ['Código','Nombre','Tardanzas','Ausencias','Días','Horas','Puesto','Área'];
      for (int i = 0; i < cabs.length; i++) {
        hoja.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0))
          ..value = TextCellValue(cabs[i])
          ..cellStyle = CellStyle(bold: true, fontColorHex: blanco,
              backgroundColorHex: azul, horizontalAlign: HorizontalAlign.Center);
        hoja.setColumnWidth(i, i == 1 ? 22.0 : 12.0);
      }
      final Map<String, List<Jornada>> porEmp = {};
      for (final j in jornadas) porEmp.putIfAbsent(j.codigoEmpleado, () => []).add(j);

      for (int i = 0; i < empleados.length; i++) {
        final emp = empleados[i];
        final js  = porEmp[emp.codigoEmpleado] ?? [];
        final diasTrab = js.where((j) => j.completa == 1).length;
        final tardanzas = js.where((j) {
          if (j.entradaTimestamp == null) return false;
          try {
            final ent = DateTime.parse(j.entradaTimestamp!);
            final parts = cfg.horaEntradaDefault.split(':');
            final limite = DateTime(ent.year, ent.month, ent.day,
                int.parse(parts[0]), int.parse(parts[1]));
            return ent.isAfter(limite.add(Duration(minutes: cfg.toleranciaMinutos)));
          } catch (_) { return false; }
        }).length;
        final ausencias = js.where((j) => j.entradaTimestamp == null).length;
        final horasTot  = js.fold<double>(0, (s, j) => s + (j.horasTrabajadas ?? 0));
        final bg = (tardanzas > 0 || ausencias > 0) ? ama : ExcelColor.fromHexString('#FFFFFF');
        final vals = [emp.codigoEmpleado, emp.nombre, tardanzas.toString(),
            ausencias.toString(), diasTrab.toString(),
            horasTot.toStringAsFixed(1), emp.puesto ?? '', emp.sitioTrabajo ?? ''];
        for (int ci = 0; ci < vals.length; ci++) {
          hoja.cell(CellIndex.indexByColumnRow(columnIndex: ci, rowIndex: i + 1))
            ..value = TextCellValue(vals[ci])
            ..cellStyle = CellStyle(backgroundColorHex: bg);
        }
      }
      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '${dir.path}/tardanzas-$ts.xlsx';
      final bytes = excel.save();
      if (bytes == null) return null;
      await File(ruta).writeAsBytes(bytes);
      return ruta;
    } catch (e) { print('[REP] Error tardanzas xls: $e'); return null; }
  }

  // ── Tardanzas y Ausencias PDF ────────────────────────────────
  Future<String?> pdfTardanzasAusencias({
    required String tsInicio, required String tsFin, Configuracion? config,
  }) async {
    try {
      final fi = tsInicio.substring(0, 10);
      final ff = tsFin.substring(0, 10);
      final jornadas  = await _bd.obtenerJornadasRango(fi, ff);
      final empleados = await _bd.obtenerEmpleadosActivos();
      final cfg  = config ?? await _bd.obtenerConfiguracion();
      final pdf  = pw.Document();
      final azul = PdfColor.fromHex('#1565C0');
      final Map<String, List<Jornada>> porEmp = {};
      for (final j in jornadas) porEmp.putIfAbsent(j.codigoEmpleado, () => []).add(j);

      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(24),
        build: (ctx) => [
          pw.Container(color: azul, padding: const pw.EdgeInsets.all(10),
            child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
              pw.Text('Tardanzas y Ausencias',
                  style: pw.TextStyle(color: PdfColors.white, fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.Text('Del ${_fmtFecha.format(DateTime.parse(fi))} al ${_fmtFecha.format(DateTime.parse(ff))}',
                  style: const pw.TextStyle(color: PdfColors.white, fontSize: 9)),
            ])),
          pw.SizedBox(height: 4),
          pw.Text(cfg.nombreCompania, style: pw.TextStyle(fontSize: 10, color: azul)),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {
              0: const pw.FixedColumnWidth(45), 1: const pw.FixedColumnWidth(80),
              2: const pw.FixedColumnWidth(35), 3: const pw.FixedColumnWidth(35),
              4: const pw.FixedColumnWidth(35), 5: const pw.FixedColumnWidth(50),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: PdfColor.fromHex('#BBDEFB')),
                children: ['Código','Nombre','Tardanzas','Ausencias','Días','Horas']
                    .map((t) => pw.Padding(padding: const pw.EdgeInsets.all(4),
                        child: pw.Text(t, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 8))))
                    .toList()),
              ...empleados.map((emp) {
                final js = porEmp[emp.codigoEmpleado] ?? [];
                final diasTrab = js.where((j) => j.completa == 1).length;
                final tardanzas = js.where((j) {
                  if (j.entradaTimestamp == null) return false;
                  try {
                    final ent = DateTime.parse(j.entradaTimestamp!);
                    final parts = cfg.horaEntradaDefault.split(':');
                    final limite = DateTime(ent.year, ent.month, ent.day,
                        int.parse(parts[0]), int.parse(parts[1]));
                    return ent.isAfter(limite.add(Duration(minutes: cfg.toleranciaMinutos)));
                  } catch (_) { return false; }
                }).length;
                final ausencias = js.where((j) => j.entradaTimestamp == null).length;
                final horasTot  = js.fold<double>(0, (s, j) => s + (j.horasTrabajadas ?? 0));
                final bg = (tardanzas > 0 || ausencias > 0)
                    ? PdfColor.fromHex('#FFF9C4') : PdfColors.white;
                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: bg),
                  children: [emp.codigoEmpleado, emp.nombre,
                    tardanzas > 0 ? '$tardanzas !' : '0',
                    ausencias > 0 ? '$ausencias x' : '0',
                    '$diasTrab', '${horasTot.toStringAsFixed(1)}h',
                  ].map((t) => pw.Padding(padding: const pw.EdgeInsets.all(3),
                      child: pw.Text(t, style: const pw.TextStyle(fontSize: 7)))).toList());
              }),
            ],
          ),
        ],
      ));
      final dir  = await _dirReportes();
      final ruta = '${dir.path}/tardanzas-${DateFormat("yyyyMMdd-HHmm").format(DateTime.now())}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) { print('[REP] Error tardanzas pdf: $e'); return null; }
  }

  // ── Vigencias PDF ────────────────────────────────────────────
  Future<String?> pdfVigencias({Configuracion? config}) async {
    try {
      final empleados = await _bd.obtenerTodosEmpleados();
      final cfg  = config ?? await _bd.obtenerConfiguracion();
      final hoy  = DateTime.now();
      final pdf  = pw.Document();
      final azul = PdfColor.fromHex('#1565C0');
      final rojo = PdfColor.fromHex('#B71C1C');
      final ama  = PdfColor.fromHex('#F57F17');
      final verd = PdfColor.fromHex('#2E7D32');
      final gris = PdfColor.fromHex('#607D8B');

      final vencidos  = <Empleado>[];
      final por30dias = <Empleado>[];
      final vigentes  = <Empleado>[];
      final sinFecha  = <Empleado>[];

      for (final e in empleados) {
        if (e.fechaVencimiento == null || e.fechaVencimiento!.isEmpty) { sinFecha.add(e); continue; }
        try {
          final fv = DateTime.parse(e.fechaVencimiento!);
          if (fv.isBefore(hoy)) vencidos.add(e);
          else if (fv.isBefore(hoy.add(const Duration(days: 30)))) por30dias.add(e);
          else vigentes.add(e);
        } catch (_) { sinFecha.add(e); }
      }

      List<pw.Widget> seccion(String titulo, List<Empleado> lista, PdfColor color) {
        if (lista.isEmpty) return [];
        return [
          pw.SizedBox(height: 8),
          pw.Container(color: color, padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: pw.Text(titulo,
                style: pw.TextStyle(color: PdfColors.white, fontSize: 9, fontWeight: pw.FontWeight.bold))),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {0: const pw.FixedColumnWidth(45), 1: const pw.FixedColumnWidth(90),
                           2: const pw.FixedColumnWidth(55), 3: const pw.FixedColumnWidth(60)},
            children: [
              pw.TableRow(decoration: pw.BoxDecoration(color: PdfColor.fromHex('#F5F5F5')),
                children: ['Código','Nombre','Puesto','Vencimiento'].map((t) =>
                  pw.Padding(padding: const pw.EdgeInsets.all(3),
                    child: pw.Text(t, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 8)))).toList()),
              ...lista.map((e) => pw.TableRow(children: [
                e.codigoEmpleado, e.nombre, e.puesto ?? '---',
                e.fechaVencimiento != null
                    ? _fmtFecha.format(DateTime.tryParse(e.fechaVencimiento!) ?? DateTime.now())
                    : 'Sin fecha',
              ].map((t) => pw.Padding(padding: const pw.EdgeInsets.all(3),
                  child: pw.Text(t, style: const pw.TextStyle(fontSize: 7)))).toList())),
            ],
          ),
        ];
      }

      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(24),
        build: (ctx) => [
          pw.Container(color: azul, padding: const pw.EdgeInsets.all(10),
            child: pw.Text('Control de Vigencias',
                style: pw.TextStyle(color: PdfColors.white, fontSize: 14, fontWeight: pw.FontWeight.bold))),
          pw.SizedBox(height: 4),
          pw.Text('${cfg.nombreCompania}  |  ${_fmtFecha.format(hoy)}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey)),
          ...seccion('VENCIDOS (${vencidos.length})', vencidos, rojo),
          ...seccion('VENCEN EN 30 DÍAS (${por30dias.length})', por30dias, ama),
          ...seccion('VIGENTES (${vigentes.length})', vigentes, verd),
          ...seccion('SIN FECHA (${sinFecha.length})', sinFecha, gris),
        ],
      ));
      final dir  = await _dirReportes();
      final ruta = '${dir.path}/vigencias-${DateFormat("yyyyMMdd-HHmm").format(DateTime.now())}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) { print('[REP] Error vigencias: $e'); return null; }
  }

  // ── Catálogo Gafetes PDF (en reportes/) ─────────────────────
  Future<String?> pdfCatalogoGafetes({Configuracion? config}) async {
    try {
      final empleados = await _bd.obtenerTodosEmpleados();
      final cfg    = config ?? await _bd.obtenerConfiguracion();
      final pdf    = pw.Document();
      final colorP = PdfColor.fromHex('#1565C0');
      final colorS = PdfColor.fromHex('#E3F2FD');
      const gfA = 242.5; const gfH = 153.1; const porPag = 4;

      for (int p = 0; p < (empleados.length / porPag).ceil(); p++) {
        final lote = empleados.skip(p * porPag).take(porPag).toList();
        pdf.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(18),
          build: (ctx) => pw.Column(children: [
            pw.Container(width: double.infinity, color: colorP,
              padding: const pw.EdgeInsets.all(6),
              child: pw.Text('${cfg.nombreCompania} — Catálogo de Gafetes',
                  style: pw.TextStyle(color: PdfColors.white, fontSize: 10, fontWeight: pw.FontWeight.bold))),
            pw.SizedBox(height: 8),
            pw.Wrap(spacing: 10, runSpacing: 10, children: lote.map((emp) =>
              pw.Container(
                width: gfA, height: gfH,
                decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400),
                    borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4))),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                  pw.Container(width: double.infinity, color: colorP, padding: const pw.EdgeInsets.all(2),
                    child: pw.Text(cfg.nombreCompania, textAlign: pw.TextAlign.center,
                        style: pw.TextStyle(color: PdfColors.white, fontSize: 6, fontWeight: pw.FontWeight.bold))),
                  pw.SizedBox(height: 2),
                  pw.Container(width: 44, height: 44, color: colorS,
                    child: pw.Center(child: pw.Text(emp.nombre.isNotEmpty ? emp.nombre[0] : '?',
                        style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold, color: colorP)))),
                  pw.SizedBox(height: 2),
                  pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(fontSize: 6.5, fontWeight: pw.FontWeight.bold)),
                  if (emp.puesto != null) pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(fontSize: 5.5, color: colorP)),
                  pw.Text('No. ${emp.codigoEmpleado}',
                      style: pw.TextStyle(fontSize: 6, fontWeight: pw.FontWeight.bold)),
                  pw.Expanded(child: pw.SizedBox()),
                  pw.Container(width: double.infinity, color: colorS,
                    padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                          pw.Container(width: 70, height: 0.5, color: PdfColors.grey700),
                          pw.Text('Autoriza', style: const pw.TextStyle(fontSize: 5, color: PdfColors.grey)),
                        ]),
                        pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                          pw.Container(width: 70, height: 0.5, color: PdfColors.grey700),
                          pw.Text('Empleado', style: const pw.TextStyle(fontSize: 5, color: PdfColors.grey)),
                        ]),
                      ])),
                ]),
              )).toList()),
          ]),
        ));
      }
      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '${dir.path}/catalogo-gafetes-$ts.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) { print('[REP] Error cat gafetes pdf: $e'); return null; }
  }

  // ── Catálogo QR PDF (en reportes/) ──────────────────────────
  Future<String?> pdfCatalogoQr() async {
    try {
      final empleados = await _bd.obtenerTodosEmpleados();
      final pdf = pw.Document();
      const gfA = 242.5; const gfH = 153.1; const porPag = 6;

      for (int p = 0; p < (empleados.length / porPag).ceil(); p++) {
        final lote = empleados.skip(p * porPag).take(porPag).toList();
        pdf.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(18),
          build: (ctx) => pw.Wrap(spacing: 12, runSpacing: 12,
            children: lote.map((emp) => pw.Container(
              width: gfA, height: gfH,
              decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300)),
              padding: const pw.EdgeInsets.all(4),
              child: pw.Column(mainAxisAlignment: pw.MainAxisAlignment.center,
                crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                pw.BarcodeWidget(barcode: pw.Barcode.qrCode(),
                    data: 'CHECADOR:${emp.codigoEmpleado}:${emp.nombre}',
                    width: 84, height: 84),
                pw.SizedBox(height: 3),
                pw.Text(emp.codigoEmpleado,
                    style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, letterSpacing: 2)),
                pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                    style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
              ]),
            )).toList()),
        ));
      }
      final dir  = await _dirReportes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '${dir.path}/catalogo-qr-$ts.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      return ruta;
    } catch (e) { print('[REP] Error cat QR pdf: $e'); return null; }
  }

}

class ArchivoReporte {
  final String ruta;
  final String nombre;
  final int tamanio;
  final DateTime fecha;

  ArchivoReporte({required this.ruta, required this.nombre, required this.tamanio, required this.fecha});

  String get tipo {
    if (nombre.endsWith('.xlsx')) return 'Excel';
    if (nombre.endsWith('.pdf')) return 'PDF';
    if (nombre.endsWith('.txt')) return 'Texto';
    return '?';
  }

  String get tamanioStr {
    if (tamanio < 1024) return '$tamanio B';
    if (tamanio < 1048576) return '${(tamanio / 1024).toStringAsFixed(1)} KB';
    return '${(tamanio / 1048576).toStringAsFixed(1)} MB';
  }

}