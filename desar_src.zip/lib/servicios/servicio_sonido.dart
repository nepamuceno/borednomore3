// /desar/lib/servicios/servicio_sonido.dart
// Sonidos de notificacion usando audioplayers - DESAR v0.0.1-beta
// Added: vibration support per event type, prefs keys for sound+vibration toggles

import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';

class ServicioSonido {
  static final ServicioSonido _inst = ServicioSonido._interno();
  factory ServicioSonido() => _inst;
  ServicioSonido._interno();

  final AudioPlayer _player = AudioPlayer();

  static const String _keyEntrada = 'sonido_entrada';
  static const String _keySalida  = 'sonido_salida';
  static const String _keyBaja    = 'sonido_baja';

  // Keys for sound/vibration toggle per event
  static const String _keyUsarSonidoEntrada    = 'usar_sonido_entrada';
  static const String _keyUsarVibEntrada       = 'usar_vibracion_entrada';
  static const String _keyUsarSonidoSalida     = 'usar_sonido_salida';
  static const String _keyUsarVibSalida        = 'usar_vibracion_salida';
  static const String _keyUsarSonidoBaja       = 'usar_sonido_baja';
  static const String _keyUsarVibBaja          = 'usar_vibracion_baja';

  // Sonidos por defecto en assets
  static const String _defEntrada = 'sonidos/entrada.wav';
  static const String _defSalida  = 'sonidos/salida.wav';
  static const String _defBaja    = 'sonidos/baja.wav';

  Future<void> reproducirEntrada() async =>
      _reproducir(_keyEntrada, _defEntrada, _keyUsarSonidoEntrada, _keyUsarVibEntrada, [100, 100, 100]);

  Future<void> reproducirSalida() async =>
      _reproducir(_keySalida, _defSalida, _keyUsarSonidoSalida, _keyUsarVibSalida, [200]);

  Future<void> reproducirBaja() async =>
      _reproducir(_keyBaja, _defBaja, _keyUsarSonidoBaja, _keyUsarVibBaja, [500, 200, 500]);

  Future<void> _reproducir(String prefKey, String defaultAsset,
      String keySonido, String keyVibracion, List<int> patronVibracion) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final usarSonido    = prefs.getBool(keySonido)    ?? true;
      final usarVibracion = prefs.getBool(keyVibracion) ?? false;

      if (usarSonido) {
        final rutaCustom = prefs.getString(prefKey);
        if (rutaCustom != null && rutaCustom.isNotEmpty) {
          await _player.play(DeviceFileSource(rutaCustom));
        } else {
          await _player.play(AssetSource(defaultAsset));
        }
      }

      if (usarVibracion) {
        final tiene = await Vibration.hasVibrator() ?? false;
        if (tiene) {
          if (patronVibracion.length == 1) {
            await Vibration.vibrate(duration: patronVibracion[0]);
          } else {
            await Vibration.vibrate(pattern: patronVibracion);
          }
        }
      }
    } catch (e) {
      print('[SONIDO] Error: $e');
    }
  }

  Future<void> guardarSonidoEntrada(String ruta) async =>
      (await SharedPreferences.getInstance()).setString(_keyEntrada, ruta);

  Future<void> guardarSonidoSalida(String ruta) async =>
      (await SharedPreferences.getInstance()).setString(_keySalida, ruta);

  Future<void> guardarSonidoBaja(String ruta) async =>
      (await SharedPreferences.getInstance()).setString(_keyBaja, ruta);

  // Save sound/vibration toggles
  Future<void> guardarPrefsEntrada(bool usarSonido, bool usarVibracion) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyUsarSonidoEntrada, usarSonido);
    await prefs.setBool(_keyUsarVibEntrada,    usarVibracion);
  }

  Future<void> guardarPrefsSalida(bool usarSonido, bool usarVibracion) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyUsarSonidoSalida, usarSonido);
    await prefs.setBool(_keyUsarVibSalida,    usarVibracion);
  }

  Future<void> guardarPrefsBaja(bool usarSonido, bool usarVibracion) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyUsarSonidoBaja, usarSonido);
    await prefs.setBool(_keyUsarVibBaja,    usarVibracion);
  }

  Future<Map<String, String?>> obtenerSonidos() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'entrada': prefs.getString(_keyEntrada),
      'salida':  prefs.getString(_keySalida),
      'baja':    prefs.getString(_keyBaja),
    };
  }

  // Returns all prefs including sound/vibration toggles
  Future<Map<String, dynamic>> obtenerPrefsCompletas() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'entrada':          prefs.getString(_keyEntrada),
      'salida':           prefs.getString(_keySalida),
      'baja':             prefs.getString(_keyBaja),
      'sonido_entrada':   prefs.getBool(_keyUsarSonidoEntrada)  ?? true,
      'vib_entrada':      prefs.getBool(_keyUsarVibEntrada)     ?? false,
      'sonido_salida':    prefs.getBool(_keyUsarSonidoSalida)   ?? true,
      'vib_salida':       prefs.getBool(_keyUsarVibSalida)      ?? false,
      'sonido_baja':      prefs.getBool(_keyUsarSonidoBaja)     ?? true,
      'vib_baja':         prefs.getBool(_keyUsarVibBaja)        ?? false,
    };
  }

  void dispose() => _player.dispose();
}
