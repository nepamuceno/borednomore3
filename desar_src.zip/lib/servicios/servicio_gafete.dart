// /desar/lib/servicios/servicio_gafete.dart
// v3: CR80 (85.6x54mm), centrado, fechaAlta, fechaVencimiento, firmas
//     Auto-genera gafete-{codigo}.pdf y qr-{codigo}.pdf al guardar empleado

import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import '../modelos/empleado.dart';
import '../modelos/configuracion.dart';

class ServicioGafete {
  static final ServicioGafete _inst = ServicioGafete._interno();
  factory ServicioGafete() => _inst;
  ServicioGafete._interno();

  // CR80 estándar: 85.6mm x 54mm en puntos PDF (1pt = 0.3528mm)
  static const double _ancho = 242.5;
  static const double _alto  = 153.1;

  Future<Directory> _dirGafetes() async {
    final doc = await getApplicationDocumentsDirectory();
    final dir = Directory('${doc.path}/gafetes');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  String rutaGafete(String codigo) => ''; // resuelto en _dirGafetes async
  String _contenidoQr(Empleado emp) => 'CHECADOR:${emp.codigoEmpleado}:${emp.nombre}';

  String _fmtFecha(String iso) {
    try { return DateFormat('dd/MM/yyyy').format(DateTime.parse(iso)); }
    catch (_) { return iso; }
  }

  // ── Gafete CR80 PDF ─────────────────────────────────────────
  Future<String?> generarGafetePdf(Empleado emp, Configuracion cfg) async {
    try {
      final pdf = pw.Document();

      pw.ImageProvider? fotoEmp;
      if (emp.fotoRostro1 != null) {
        try { fotoEmp = pw.MemoryImage(await File(emp.fotoRostro1!).readAsBytes()); } catch (_) {}
      } else if (emp.fotoPerfil != null) {
        try { fotoEmp = pw.MemoryImage(await File(emp.fotoPerfil!).readAsBytes()); } catch (_) {}
      }

      pw.ImageProvider? logoImg;
      if (cfg.logoCompania != null) {
        try { logoImg = pw.MemoryImage(await File(cfg.logoCompania!).readAsBytes()); } catch (_) {}
      }

      final colorP  = PdfColor.fromHex('#1565C0');
      final colorS  = PdfColor.fromHex('#E3F2FD');
      final colorTx = PdfColor.fromHex('#212121');
      final colorGr = PdfColor.fromHex('#757575');

      // CARA FRONTAL
      pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat(_ancho, _alto, marginAll: 5),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            // Encabezado
            pw.Container(
              width: double.infinity, color: colorP,
              padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 5),
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                if (logoImg != null) pw.Image(logoImg, width: 22, height: 15, fit: pw.BoxFit.contain),
                pw.Text(cfg.nombreCompania,
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 7, fontWeight: pw.FontWeight.bold)),
                if (cfg.ciudadCompania != null || cfg.estadoCompania != null)
                  pw.Text(
                    [cfg.ciudadCompania, cfg.estadoCompania, cfg.paisCompania]
                        .where((e) => e != null && e.isNotEmpty).join(', '),
                    style: const pw.TextStyle(color: PdfColors.white, fontSize: 4.5)),
              ]),
            ),
            pw.SizedBox(height: 3),
            // Foto centrada
            pw.Container(width: 46, height: 46,
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: colorP, width: 1), color: colorS),
              child: fotoEmp != null
                  ? pw.Image(fotoEmp, fit: pw.BoxFit.cover)
                  : pw.Center(child: pw.Text('SIN\nFOTO',
                      textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(color: colorGr, fontSize: 5))),
            ),
            pw.SizedBox(height: 3),
            // Nombre y puesto
            pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 7.5, fontWeight: pw.FontWeight.bold, color: colorTx)),
            if (emp.puesto != null)
              pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(fontSize: 6.5, color: colorP, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 2),
            // Datos en 2 columnas
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.center, children: [
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _dato('No.', emp.codigoEmpleado),
                if (emp.sitioTrabajo != null) _dato('Área', emp.sitioTrabajo!),
                if (emp.fechaAlta != null) _dato('Alta', _fmtFecha(emp.fechaAlta!)),
              ]),
              pw.SizedBox(width: 10),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                if (emp.seguroSocial != null) _dato('IMSS', emp.seguroSocial!),
                if (emp.tipoSangre != null)
                  _datoColor('Sangre', emp.tipoSangre!, PdfColor.fromHex('#D32F2F')),
                if (emp.fechaVencimiento != null) _dato('Vence', _fmtFecha(emp.fechaVencimiento!)),
              ]),
            ]),
            pw.Expanded(child: pw.SizedBox()),
            // Líneas de firma
            pw.Container(
              width: double.infinity, color: colorS,
              padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [_lineaFirma('Autoriza', 78), _lineaFirma('Empleado', 78)],
              ),
            ),
          ],
        ),
      ));

      // CARA REVERSA
      pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat(_ancho, _alto, marginAll: 5),
        build: (ctx) => pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.center,
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.Text('CÓDIGO QR DE ACCESO',
                style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: colorP)),
            pw.SizedBox(height: 4),
            pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: _contenidoQr(emp),
                width: 82, height: 82, color: PdfColors.black),
            pw.SizedBox(height: 4),
            pw.Text(emp.codigoEmpleado,
                style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, letterSpacing: 2)),
            pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
            if (emp.fechaVencimiento != null)
              pw.Text('Vigencia: ${_fmtFecha(emp.fechaVencimiento!)}',
                  style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
          ],
        ),
      ));

      final dir    = await _dirGafetes();
      final ruta   = '${dir.path}/gafete-${emp.codigoEmpleado}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[GAFETE] $ruta');
      return ruta;
    } catch (e) { print('[GAFETE] Error: $e'); return null; }
  }

  // ── QR individual CR80 PDF ───────────────────────────────────
  Future<String?> generarQrPdf(Empleado emp) async {
    try {
      final pdf = pw.Document();
      pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat(_ancho, _alto, marginAll: 5),
        build: (ctx) => pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.center,
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: _contenidoQr(emp),
                width: 105, height: 105, color: PdfColors.black),
            pw.SizedBox(height: 5),
            pw.Text(emp.codigoEmpleado,
                style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, letterSpacing: 3)),
            pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey)),
            if (emp.puesto != null)
              pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                  style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
          ],
        ),
      ));
      final dir  = await _dirGafetes();
      final ruta = '${dir.path}/qr-${emp.codigoEmpleado}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[QR] $ruta');
      return ruta;
    } catch (e) { print('[QR] Error: $e'); return null; }
  }

  // ── Catálogo gafetes PDF (4 por hoja A4) ────────────────────
  Future<String?> generarCatalogoGafetesPdf(
      List<Empleado> empleados, Configuracion cfg) async {
    try {
      final pdf    = pw.Document();
      final colorP = PdfColor.fromHex('#1565C0');
      final colorS = PdfColor.fromHex('#E3F2FD');
      const porPag = 4;

      for (int p = 0; p < (empleados.length / porPag).ceil(); p++) {
        final lote = empleados.skip(p * porPag).take(porPag).toList();
        pdf.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(18),
          build: (ctx) => pw.Wrap(
            spacing: 12, runSpacing: 12,
            children: lote.map((emp) => pw.Container(
              width: _ancho, height: _alto,
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey400),
                borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4)),
              ),
              padding: const pw.EdgeInsets.all(4),
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                pw.Container(width: double.infinity, color: colorP,
                  padding: const pw.EdgeInsets.all(2),
                  child: pw.Text(cfg.nombreCompania, textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(color: PdfColors.white, fontSize: 6,
                          fontWeight: pw.FontWeight.bold))),
                pw.SizedBox(height: 2),
                pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: _contenidoQr(emp),
                    width: 52, height: 52),
                pw.SizedBox(height: 2),
                pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold)),
                if (emp.puesto != null)
                  pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(fontSize: 5.5, color: colorP)),
                pw.Text(emp.codigoEmpleado,
                    style: pw.TextStyle(fontSize: 6.5, fontWeight: pw.FontWeight.bold)),
                if (emp.fechaAlta != null || emp.fechaVencimiento != null)
                  pw.Text(
                    [if (emp.fechaAlta != null) 'Alta: ${_fmtFecha(emp.fechaAlta!)}',
                     if (emp.fechaVencimiento != null) 'Vence: ${_fmtFecha(emp.fechaVencimiento!)}'].join('  '),
                    style: const pw.TextStyle(fontSize: 5, color: PdfColors.grey)),
                pw.Expanded(child: pw.SizedBox()),
                pw.Container(width: double.infinity, color: colorS,
                  padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [_lineaFirma('Autoriza', 70), _lineaFirma('Empleado', 70)])),
              ]),
            )).toList(),
          ),
        ));
      }
      final dir  = await _dirGafetes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '${dir.path}/catalogo-gafetes-$ts.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[CAT-GAFETES] $ruta');
      return ruta;
    } catch (e) { print('[CAT-GAFETES] Error: $e'); return null; }
  }

  // ── Catálogo QR PDF (6 por hoja A4) ─────────────────────────
  Future<String?> generarCatalogoQrPdf(List<Empleado> empleados) async {
    try {
      final pdf    = pw.Document();
      const porPag = 6;

      for (int p = 0; p < (empleados.length / porPag).ceil(); p++) {
        final lote = empleados.skip(p * porPag).take(porPag).toList();
        pdf.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(18),
          build: (ctx) => pw.Wrap(
            spacing: 12, runSpacing: 12,
            children: lote.map((emp) => pw.Container(
              width: _ancho, height: _alto,
              decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300)),
              padding: const pw.EdgeInsets.all(4),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: _contenidoQr(emp),
                      width: 84, height: 84),
                  pw.SizedBox(height: 3),
                  pw.Text(emp.codigoEmpleado,
                      style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, letterSpacing: 2)),
                  pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                      style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
                ]),
            )).toList(),
          ),
        ));
      }
      final dir  = await _dirGafetes();
      final ts   = DateFormat('yyyyMMdd-HHmm').format(DateTime.now());
      final ruta = '${dir.path}/catalogo-qr-$ts.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[CAT-QR] $ruta');
      return ruta;
    } catch (e) { print('[CAT-QR] Error: $e'); return null; }
  }

  // ── Impresión individual: frente+reverso en una hoja A4 ──────
  Future<String?> generarImpresionIndividual(Empleado emp, Configuracion cfg) async {
    try {
      final pdf    = pw.Document();
      final colorP = PdfColor.fromHex('#1565C0');
      final colorS = PdfColor.fromHex('#E3F2FD');
      final colorGr = PdfColor.fromHex('#757575');

      pw.ImageProvider? fotoEmp;
      if (emp.fotoRostro1 != null) {
        try { fotoEmp = pw.MemoryImage(await File(emp.fotoRostro1!).readAsBytes()); } catch (_) {}
      } else if (emp.fotoPerfil != null) {
        try { fotoEmp = pw.MemoryImage(await File(emp.fotoPerfil!).readAsBytes()); } catch (_) {}
      }
      pw.ImageProvider? logoImg;
      if (cfg.logoCompania != null) {
        try { logoImg = pw.MemoryImage(await File(cfg.logoCompania!).readAsBytes()); } catch (_) {}
      }

      pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(20),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.Text('${cfg.nombreCompania} — Credencial de Empleado',
                style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: colorP)),
            pw.SizedBox(height: 6),
            pw.Text('Recortar y colocar en porta-gafetes CR80 (85.6 × 54 mm)',
                style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey)),
            pw.SizedBox(height: 14),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.center, children: [
              // FRENTE
              pw.Container(
                width: _ancho, height: _alto,
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey),
                  borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4))),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                  pw.Container(width: double.infinity, color: colorP,
                    padding: const pw.EdgeInsets.all(2),
                    child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                      if (logoImg != null) pw.Image(logoImg, width: 18, height: 12, fit: pw.BoxFit.contain),
                      pw.Text(cfg.nombreCompania, textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(color: PdfColors.white, fontSize: 6,
                              fontWeight: pw.FontWeight.bold)),
                    ])),
                  pw.SizedBox(height: 2),
                  if (fotoEmp != null)
                    pw.Container(width: 38, height: 38,
                        decoration: pw.BoxDecoration(border: pw.Border.all(color: colorP, width: 1)),
                        child: pw.Image(fotoEmp, fit: pw.BoxFit.cover))
                  else
                    pw.Container(width: 38, height: 38, color: colorS,
                        child: pw.Center(child: pw.Text('FOTO',
                            style: pw.TextStyle(fontSize: 5, color: colorGr)))),
                  pw.SizedBox(height: 2),
                  pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(fontSize: 6.5, fontWeight: pw.FontWeight.bold)),
                  if (emp.puesto != null)
                    pw.Text(emp.puesto!, textAlign: pw.TextAlign.center,
                        style: pw.TextStyle(fontSize: 5.5, color: colorP)),
                  pw.SizedBox(height: 1),
                  pw.Text('No. ${emp.codigoEmpleado}',
                      style: pw.TextStyle(fontSize: 6, fontWeight: pw.FontWeight.bold)),
                  if (emp.fechaAlta != null)
                    pw.Text('Alta: ${_fmtFecha(emp.fechaAlta!)}',
                        style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
                  if (emp.fechaVencimiento != null)
                    pw.Text('Vence: ${_fmtFecha(emp.fechaVencimiento!)}',
                        style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
                  pw.Expanded(child: pw.SizedBox()),
                  pw.Container(width: double.infinity, color: colorS,
                    padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                        children: [_lineaFirma('Autoriza', 68), _lineaFirma('Empleado', 68)])),
                ]),
              ),
              pw.SizedBox(width: 18),
              // REVERSO / QR
              pw.Container(
                width: _ancho, height: _alto,
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey),
                  borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4))),
                child: pw.Column(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: _contenidoQr(emp),
                        width: 92, height: 92, color: PdfColors.black),
                    pw.SizedBox(height: 4),
                    pw.Text(emp.codigoEmpleado,
                        style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, letterSpacing: 2)),
                    pw.Text(emp.nombre, textAlign: pw.TextAlign.center,
                        style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey)),
                    if (emp.fechaVencimiento != null)
                      pw.Text('Vigencia: ${_fmtFecha(emp.fechaVencimiento!)}',
                          style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
                  ],
                ),
              ),
            ]),
            pw.SizedBox(height: 6),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.center, children: [
              pw.SizedBox(width: _ancho, child: pw.Center(
                  child: pw.Text('▲ FRENTE', style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey)))),
              pw.SizedBox(width: 18),
              pw.SizedBox(width: _ancho, child: pw.Center(
                  child: pw.Text('▲ REVERSO / QR', style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey)))),
            ]),
          ],
        ),
      ));

      final dir  = await _dirGafetes();
      final ruta = '${dir.path}/impresion-${emp.codigoEmpleado}.pdf';
      await File(ruta).writeAsBytes(await pdf.save());
      print('[IMPRESION] $ruta');
      return ruta;
    } catch (e) { print('[IMPRESION] Error: $e'); return null; }
  }

  // ── Helpers PDF ─────────────────────────────────────────────
  pw.Widget _dato(String label, String valor) => pw.Padding(
    padding: const pw.EdgeInsets.only(bottom: 1),
    child: pw.Row(mainAxisSize: pw.MainAxisSize.min, children: [
      pw.Text('$label: ', style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
      pw.Text(valor, style: pw.TextStyle(fontSize: 5.5, fontWeight: pw.FontWeight.bold)),
    ]),
  );

  pw.Widget _datoColor(String label, String valor, PdfColor color) => pw.Padding(
    padding: const pw.EdgeInsets.only(bottom: 1),
    child: pw.Row(mainAxisSize: pw.MainAxisSize.min, children: [
      pw.Text('$label: ', style: const pw.TextStyle(fontSize: 5.5, color: PdfColors.grey)),
      pw.Text(valor, style: pw.TextStyle(fontSize: 5.5, fontWeight: pw.FontWeight.bold, color: color)),
    ]),
  );

  pw.Widget _lineaFirma(String label, double ancho) => pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.center,
    children: [
      pw.Container(width: ancho, height: 0.5, color: PdfColors.grey700),
      pw.SizedBox(height: 1),
      pw.Text(label, style: const pw.TextStyle(fontSize: 5, color: PdfColors.grey)),
    ],
  );
}
