// /desar/lib/servicios/servicio_bot.dart
// Bot Telegram/WhatsApp con comandos configurables - DESAR v0.0.1-beta

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../base_datos/base_datos_helper.dart';
import '../modelos/configuracion.dart';
import '../modelos/empleado.dart';
import 'servicio_reportes.dart';
import 'servicio_gafete.dart';

class ServicioBot {
  static final ServicioBot _inst = ServicioBot._interno();
  factory ServicioBot() => _inst;
  ServicioBot._interno();

  final BaseDatosHelper _bd = BaseDatosHelper();
  final ServicioReportes _rep = ServicioReportes();
  final ServicioGafete _gafete = ServicioGafete();

  Timer? _timerPolling;
  int _ultimoUpdateId = 0;
  bool _activo = false;

  // Paginacion de respuestas largas
  final Map<String, List<String>> _bufferPaginas = {};
  static const int _maxCaracteres = 3500;

  static const String _version = '0.0.1-beta';
  static const String _autor = 'Alex Rogelio Rodriguez Castañeda';
  static const String _copyr = '(c) 2026 zSoft';

  // ─── Iniciar polling Telegram ────────────────────────────
  Future<void> iniciarTelegram(Configuracion cfg) async {
    if (!cfg.telegramHabilitado || (cfg.telegramBotToken ?? '').isEmpty) return;
    _activo = true;
    print('[BOT] Iniciando Telegram bot polling...');
    _timerPolling = Timer.periodic(const Duration(seconds: 3), (_) async {
      await _pollTelegram(cfg);
    });
  }

  void detener() {
    _activo = false;
    _timerPolling?.cancel();
    _timerPolling = null;
  }

  // ─── Poll Telegram getUpdates ────────────────────────────
  Future<void> _pollTelegram(Configuracion cfg) async {
    try {
      final url =
          'https://api.telegram.org/bot${cfg.telegramBotToken}/getUpdates'
          '?offset=${_ultimoUpdateId + 1}&timeout=2';
      final resp =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 5));
      if (resp.statusCode != 200) return;
      final data = jsonDecode(resp.body);
      if (!(data['ok'] as bool)) return;
      final updates = data['result'] as List;
      for (final upd in updates) {
        _ultimoUpdateId = upd['update_id'] as int;
        final msg = upd['message'];
        if (msg == null) continue;
        final chatId = msg['chat']['id'].toString();
        final texto = (msg['text'] as String? ?? '').trim();
        final prefijo = cfg.botPrefijo.isNotEmpty ? cfg.botPrefijo.trim() : '/';

        if (texto.startsWith(prefijo)) {
          // Extraer comando sin el prefijo
          String cmdRaw = texto.substring(prefijo.length).trim();
          // Normalizar: asegurar que empiece con /
          final cmdNorm = cmdRaw.startsWith('/') ? cmdRaw : '/$cmdRaw';

          // Manejar paginacion
          if (cmdNorm == '/mas') {
            final buf = _bufferPaginas[chatId];
            if (buf != null && buf.isNotEmpty) {
              final pag = buf.removeAt(0);
              final aviso = buf.isEmpty
                  ? '\n\n✅ *Fin del contenido*'
                  : '\n\nEscribe `${prefijo}mas` para continuar.';
              await _enviarTelegram(cfg, chatId, pag + aviso);
            } else {
              await _enviarTelegram(
                  cfg, chatId, 'ℹ️ No hay más contenido pendiente.');
            }
          } else if (cmdNorm == '/cancelar') {
            _bufferPaginas.remove(chatId);
            await _enviarTelegram(cfg, chatId, '✅ Cancelado.');
          } else {
            final respuesta = await procesarComando(cmdNorm, cfg: cfg);
            await _enviarRespuestaPaginada(cfg, chatId, respuesta);
          }
        }
      }
    } catch (_) {}
  }

  // ─── Enviar mensaje Telegram ─────────────────────────────
  Future<void> _enviarTelegram(
      Configuracion cfg, String chatId, String texto) async {
    if (texto.isEmpty) return;
    try {
      await http.post(
        Uri.parse(
            'https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage'),
        body: {'chat_id': chatId, 'text': texto, 'parse_mode': 'Markdown'},
      ).timeout(const Duration(seconds: 10));
    } catch (e) {
      print('[BOT] Error enviar Telegram: $e');
    }
  }

  // ─── Enviar archivo Telegram ─────────────────────────────
  Future<void> _enviarArchivoTelegram(
      Configuracion cfg, String chatId, String ruta) async {
    try {
      final nombre = ruta.split('/').last;
      final req = http.MultipartRequest(
          'POST',
          Uri.parse(
              'https://api.telegram.org/bot${cfg.telegramBotToken}/sendDocument'));
      req.fields['chat_id'] = chatId;
      req.files.add(
          await http.MultipartFile.fromPath('document', ruta, filename: nombre));
      await req.send().timeout(const Duration(seconds: 30));
    } catch (e) {
      print('[BOT] Error enviar archivo: $e');
    }
  }

  // ─── Enviar notificacion de asistencia ──────────────────
  Future<void> notificarAsistencia(String mensaje) async {
    final cfg = await _bd.obtenerConfiguracion();
    if (cfg.telegramHabilitado &&
        (cfg.telegramBotToken ?? '').isNotEmpty &&
        (cfg.telegramChatId ?? '').isNotEmpty) {
      await _enviarTelegram(cfg, cfg.telegramChatId!, mensaje);
    }
    if (cfg.whatsappHabilitado) {
      await _enviarWhatsApp(cfg, mensaje);
    }
  }

  // ─── Enviar WhatsApp Business API ────────────────────────
  Future<void> _enviarWhatsApp(Configuracion cfg, String texto) async {
    if ((cfg.whatsappApiUrl ?? '').isEmpty ||
        (cfg.whatsappApiToken ?? '').isEmpty ||
        (cfg.whatsappPhoneNumberId ?? '').isEmpty ||
        (cfg.whatsappChannelId ?? '').isEmpty) return;
    try {
      await http.post(
        Uri.parse(
            '${cfg.whatsappApiUrl}/${cfg.whatsappPhoneNumberId}/messages'),
        headers: {
          'Authorization': 'Bearer ${cfg.whatsappApiToken}',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'messaging_product': 'whatsapp',
          'to': cfg.whatsappChannelId,
          'type': 'text',
          'text': {'body': texto},
        }),
      ).timeout(const Duration(seconds: 10));
    } catch (e) {
      print('[BOT] Error WhatsApp: $e');
    }
  }

  // ─── Divide texto largo en paginas seguras ───────────────
  List<String> _dividirEnPaginas(String texto) {
    if (texto.length <= _maxCaracteres) return [texto];
    final paginas = <String>[];
    int inicio = 0;
    while (inicio < texto.length) {
      int fin = inicio + _maxCaracteres;
      if (fin >= texto.length) {
        paginas.add(texto.substring(inicio));
        break;
      }
      int corte = texto.lastIndexOf('\n', fin);
      if (corte <= inicio) corte = fin;
      paginas.add(texto.substring(inicio, corte));
      inicio = corte + 1;
    }
    return paginas;
  }

  // ─── Enviar con paginacion automatica ────────────────────
  Future<void> _enviarRespuestaPaginada(
      Configuracion cfg, String chatId, RespuestaBot respuesta) async {
    if (respuesta.texto.isEmpty) return;
    final paginas = _dividirEnPaginas(respuesta.texto);
    if (paginas.length == 1) {
      await _enviarTelegram(cfg, chatId, respuesta.texto);
    } else {
      _bufferPaginas[chatId] = paginas.sublist(1);
      final prefijo = cfg.botPrefijo.isNotEmpty ? cfg.botPrefijo.trim() : '/';
      final aviso = '\n\n📄 *Parte 1 de ${paginas.length}*\n'
          'Escribe `${prefijo}mas` para continuar o '
          '`${prefijo}cancelar` para detener.';
      await _enviarTelegram(cfg, chatId, paginas[0] + aviso);
    }
    if (respuesta.rutaArchivo != null) {
      await _enviarArchivoTelegram(cfg, chatId, respuesta.rutaArchivo!);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PROCESADOR DE COMANDOS
  // ═══════════════════════════════════════════════════════════
  Future<RespuestaBot> procesarComando(String entrada,
      {Configuracion? cfg}) async {
    final cfgActual = cfg ?? await _bd.obtenerConfiguracion();
    final partes = entrada.trim().split(RegExp(r'\s+'));
    if (partes.isEmpty) return RespuestaBot(texto: 'Comando vacío');

    final cmd = partes[0].toLowerCase();
    final args = partes.sublist(1);

    switch (cmd) {
      case '/ayuda':
      case '/help':
        return await _cmdAyuda(cfgActual);
      case '/creditos':
      case '/credits':
        return _cmdCreditos();
      case '/reporte':
        return await _cmdReporte(args, cfgActual);
      case '/lista':
        return await _cmdLista(args, cfgActual);
      case '/hoy':
        return await _cmdHoy();

      case '/estado':
        return await _cmdEstado();
      case '/empleado':
        return await _cmdEmpleado(args, cfgActual);
      default:
        return RespuestaBot(
            texto:
                '❓ Comando desconocido: $cmd\nUsa /ayuda para ver los comandos disponibles.');
    }
  }

  // ─── /ayuda ──────────────────────────────────────────────
  Future<RespuestaBot> _cmdAyuda(Configuracion cfg) async {
    final p = cfg.botPrefijo.trim().isEmpty ? '/' : cfg.botPrefijo.trim();
    final texto = '''
🤖 *DESAR Bot - Comandos disponibles*
_Prefijo actual: `$p`_

📊 *Reportes:*
`${p}reporte` — Asistencias de hoy
`${p}reporte <fecha>` — Fecha YYYY-MM-DD
`${p}reporte <fi> <ff>` — Rango de fechas
`${p}reporte total` — Toda la base de datos
`${p}reporte [opciones] pdf` — En PDF

👥 *Empleados:*
`${p}lista` — Lista todos los empleados
`${p}lista <id_ini> <id_fin>` — Rango de IDs
`${p}lista excel|pdf` — Archivo descargable
`${p}empleado <codigo>` — Detalle del empleado
`${p}empleado <codigo> habilitar` — Activar
`${p}empleado <codigo> deshabilitar` — Desactivar
`${p}empleado <codigo> qr` — QR del empleado

📅 *Hoy:*
`${p}hoy` — Resumen de asistencias de hoy

📄 *Navegación:*
`${p}mas` — Continuar respuesta larga
`${p}cancelar` — Cancelar respuesta

ℹ️ *Info:*
`${p}estado` — Estado del sistema
`${p}creditos` — Info del sistema
`${p}ayuda` — Este mensaje
''';
    return RespuestaBot(texto: texto);
  }

  // ─── /creditos ───────────────────────────────────────────
  RespuestaBot _cmdCreditos() {
    return RespuestaBot(texto: '''
ℹ️ *DESAR - Sistema de Control de Asistencias*

📦 Versión: $_version
👤 Autor: $_autor
$_copyr
📧 Email: zzerver@gmail.com

🔧 Tecnologías:
• Flutter (Dart)
• SQLite offline
• TensorFlow Lite FaceNet
• Reconocimiento QR offline
• GPS local
''');
  }

  // ─── /reporte ────────────────────────────────────────────
  Future<RespuestaBot> _cmdReporte(
      List<String> args, Configuracion cfg) async {
    try {
      String tsIni, tsFin;
      bool esPdf = false;
      final w = List<String>.from(args);

      if (w.isNotEmpty && w.last.toLowerCase() == 'pdf') {
        esPdf = true;
        w.removeLast();
      }

      if (w.length == 1 && w[0].toLowerCase() == 'total') {
        tsIni = '2000-01-01T00:00:00';
        tsFin = '2099-12-31T23:59:59';
      } else if (w.isEmpty) {
        final hoy = DateTime.now().toIso8601String().substring(0, 10);
        tsIni = '${hoy}T00:00:00';
        tsFin = '${hoy}T23:59:59';
      } else if (w.length == 1) {
        final f = _parseFecha(w[0]);
        if (f == null) {
          return RespuestaBot(
              texto: '❌ Fecha inválida. Formato: YYYY-MM-DD');
        }
        tsIni = '${f}T00:00:00';
        tsFin = '${f}T23:59:59';
      } else if (w.length == 2) {
        final fi = _parseFecha(w[0]);
        final ff = _parseFecha(w[1]);
        if (fi == null || ff == null) {
          return RespuestaBot(texto: '❌ Fechas inválidas. Formato: YYYY-MM-DD');
        }
        tsIni = '${fi}T00:00:00';
        tsFin = '${ff}T23:59:59';
      } else if (w.length == 4) {
        final fi = _parseFecha(w[0]);
        final ff = _parseFecha(w[2]);
        if (fi == null || ff == null) {
          return RespuestaBot(texto: '❌ Fechas inválidas');
        }
        tsIni = '${fi}T${w[1]}:00';
        tsFin = '${ff}T${w[3]}:59';
      } else {
        return RespuestaBot(texto: '❌ Argumentos inválidos. Usa /ayuda');
      }

      String? ruta;
      if (esPdf) {
        ruta = await _rep.pdfAsistencias(
            tsInicio: tsIni, tsFin: tsFin, config: cfg);
      } else {
        ruta = await _rep.excelAsistencias(
            tsInicio: tsIni, tsFin: tsFin, config: cfg);
      }

      if (ruta == null) return RespuestaBot(texto: '❌ Error generando reporte');

      return RespuestaBot(
        texto: '📊 Reporte ${esPdf ? "PDF" : "Excel"} generado\n'
            'Período: ${tsIni.substring(0, 10)} al ${tsFin.substring(0, 10)}\n'
            '📎 Archivo adjunto',
        rutaArchivo: ruta,
      );
    } catch (e) {
      return RespuestaBot(texto: '❌ Error: $e');
    }
  }

  // ─── /lista ──────────────────────────────────────────────
  Future<RespuestaBot> _cmdLista(
      List<String> args, Configuracion cfg) async {
    try {
      final w = List<String>.from(args);
      String? formato;
      int? idIni, idFin;

      if (w.isNotEmpty) {
        final ult = w.last.toLowerCase();
        if (ult == 'excel' || ult == 'pdf') {
          formato = ult;
          w.removeLast();
        }
      }
      if (w.length >= 1) idIni = int.tryParse(w[0]);
      if (w.length >= 2) idFin = int.tryParse(w[1]);

      List<Empleado> empleados;
      if (idIni != null && idFin != null) {
        empleados = await _bd.obtenerEmpleadosRango(idIni.toString(), idFin.toString());
      } else {
        empleados = await _bd.obtenerTodosEmpleados();
      }

      if (formato == null) {
        if (empleados.isEmpty) {
          return RespuestaBot(texto: 'ℹ️ No hay empleados en ese rango');
        }
        final buf = StringBuffer('👥 *Lista de Empleados*\n\n');
        for (final e in empleados) {
          buf.writeln('🆔 `${e.codigoEmpleado}` | ${e.nombre}');
          if (e.puesto != null) buf.writeln('   💼 ${e.puesto}');
          if (e.numeroIdentificacion != null) {
            buf.writeln('   ID: ${e.numeroIdentificacion}');
          }
          buf.writeln(
              '   ${e.estaActivo ? "✅ Activo" : "🚫 Inactivo"}');
          buf.writeln();
        }
        buf.writeln('Total: ${empleados.length} empleados');
        return RespuestaBot(texto: buf.toString());
      }

      String? ruta;
      if (formato == 'pdf') {
        ruta = await _rep.pdfEmpleados(listaEmpleados: empleados, config: cfg);
      } else {
        ruta = await _rep.excelEmpleados(listaEmpleados: empleados);
      }

      if (ruta == null) return RespuestaBot(texto: '❌ Error generando archivo');
      return RespuestaBot(
        texto:
            '👥 Lista de empleados (${empleados.length}) en ${formato.toUpperCase()}',
        rutaArchivo: ruta,
      );
    } catch (e) {
      return RespuestaBot(texto: '❌ Error: $e');
    }
  }

  // ─── /hoy ────────────────────────────────────────────────
  Future<RespuestaBot> _cmdHoy() async {
    final resumen = await _bd.resumenHoy();
    if (resumen.isEmpty) return RespuestaBot(texto: 'ℹ️ Sin registros hoy');

    final buf = StringBuffer('📅 *Asistencias de hoy*\n\n');
    final fmt = DateFormat('HH:mm');
    int entradas = 0, salidas = 0;

    for (final r in resumen) {
      final tieneEntrada = r['entrada_timestamp'] != null;
      final tieneSalida = r['salida_timestamp'] != null;
      if (tieneEntrada) entradas++;
      if (tieneSalida) salidas++;
      final enStr = tieneEntrada
          ? fmt.format(DateTime.parse(r['entrada_timestamp']))
          : '--:--';
      final saStr = tieneSalida
          ? fmt.format(DateTime.parse(r['salida_timestamp']))
          : '--:--';
      final emoji = tieneSalida ? '⚫' : (tieneEntrada ? '🟢' : '🔴');
      buf.writeln('$emoji ${r['nombre']}  🟢$enStr 🔴$saStr');
    }
    buf.writeln('\nPresentes: $entradas | Salidas: $salidas | Total: ${resumen.length}');
    return RespuestaBot(texto: buf.toString());
  }

  // ─── /empleado ───────────────────────────────────────────
  Future<RespuestaBot> _cmdEmpleado(List<String> args, Configuracion cfg) async {
    if (args.isEmpty) {
      return RespuestaBot(
          texto: 'Uso:\n'
              '/empleado <codigo> — Ver detalle\n'
              '/empleado <codigo> habilitar|deshabilitar\n'
              '/empleado <codigo> qr\n'
              '/empleado <codigo> gafete\n'
              '/empleado modificar <codigo> <campo> "valor"');
    }

    // /empleado modificar <codigo> <campo> "valor"
    if (args[0].toLowerCase() == 'modificar') {
      if (args.length < 3) return RespuestaBot(texto: 'Uso: /empleado modificar <codigo> <campo> "valor"');
      final emp = await _bd.obtenerEmpleadoPorCodigo(args[1].toUpperCase());
      if (emp == null) return RespuestaBot(texto: 'Empleado no encontrado: ${args[1]}');
      final campo = args[2].toLowerCase();
      final nuevoValor = args.length > 3 ? args.sublist(3).join(' ').replaceAll('"', '') : '';
      final actualizado = _modificarCampoEmpleado(emp, campo, nuevoValor);
      if (actualizado == null) return RespuestaBot(texto: 'Campo no reconocido: $campo');
      await _bd.actualizarEmpleado(actualizado);
      return RespuestaBot(texto: 'Campo $campo actualizado para ${emp.nombre}');
    }

    final emp = await _bd.obtenerEmpleadoPorCodigo(args[0].toUpperCase());
    if (emp == null) return RespuestaBot(texto: 'Empleado no encontrado: ${args[0]}');

    final accion = args.length > 1 ? args[1].toLowerCase() : '';

    if (accion == 'habilitar') {
      await _bd.cambiarEstado(emp.id!, 1);
      return RespuestaBot(texto: '${emp.nombre} HABILITADO');
    }
    if (accion == 'deshabilitar') {
      await _bd.cambiarEstado(emp.id!, 0);
      return RespuestaBot(texto: '${emp.nombre} DESHABILITADO');
    }
    if (accion == 'qr') {
      final contenido = 'CHECADOR:${emp.codigoEmpleado}:${emp.nombre}';
      return RespuestaBot(texto: 'QR de ${emp.nombre}\nContenido: $contenido');
    }
    if (accion == 'gafete') {
      final ruta = await _gafete.generarGafetePdf(emp, cfg);
      if (ruta == null) return RespuestaBot(texto: 'Error generando gafete');
      return RespuestaBot(texto: 'Gafete de ${emp.nombre}', rutaArchivo: ruta);
    }

    final buf = StringBuffer();
    buf.writeln('👤 *${emp.nombre}*');
    buf.writeln('Código: ${emp.codigoEmpleado}');
    if (emp.puesto != null) buf.writeln('Puesto: ${emp.puesto}');
    if (emp.numeroIdentificacion != null) buf.writeln('ID: ${emp.numeroIdentificacion}');
    if (emp.seguroSocial != null) buf.writeln('SS: ${emp.seguroSocial}');
    if (emp.rfc != null) buf.writeln('RFC: ${emp.rfc}');
    if (emp.fechaNacimiento != null) buf.writeln('Nacimiento: ${emp.fechaNacimiento}');
    if (emp.telefono != null) buf.writeln('Tel: ${emp.telefono}');
    if (emp.sitioTrabajo != null) buf.writeln('Sitio: ${emp.sitioTrabajo}');
    if (emp.ubicacion.isNotEmpty) buf.writeln('Ubicacion: ${emp.ubicacion}');
    buf.writeln('Alta: ${emp.fechaRegistro?.substring(0, 10) ?? "---"}');
    buf.writeln('Estado: ${emp.estaActivo ? "Activo" : "Inactivo"}');
    return RespuestaBot(texto: buf.toString());
  }


  // ─── /estado ─────────────────────────────────────────────
  Future<RespuestaBot> _cmdEstado() async {
    final totalEmp = await _bd.contarEmpleadosActivos();
    final regHoy = await _bd.contarRegistrosHoy();
    return RespuestaBot(texto: '''
📊 *Estado del Sistema DESAR*
👥 Empleados activos: $totalEmp
📝 Registros hoy: $regHoy
🤖 Bot: activo
📱 Versión: $_version
''');
  }


  // ─── Modifica un campo del empleado ──────────────────────
  Empleado? _modificarCampoEmpleado(Empleado emp, String campo, String valor) {
    final v = valor.isEmpty ? null : valor;
    switch (campo) {
      case 'nombre': return emp.copiarCon(nombre: valor);
      case 'puesto': return emp.copiarCon(puesto: v);
      case 'telefono': return emp.copiarCon(telefono: v);
      case 'tel_emergencia':
      case 'telefono_emergencia': return emp.copiarCon(telefonoEmergencia: v);
      case 'direccion': return emp.copiarCon(direccion: v);
      case 'ciudad': return emp.copiarCon(ciudad: v);
      case 'estado': return emp.copiarCon(estado: v);
      case 'pais': return emp.copiarCon(pais: v);
      case 'rfc': return emp.copiarCon(rfc: v);
      case 'seguro_social':
      case 'ss': return emp.copiarCon(seguroSocial: v);
      case 'id':
      case 'identificacion': return emp.copiarCon(numeroIdentificacion: v);
      case 'nacimiento':
      case 'fecha_nacimiento': return emp.copiarCon(fechaNacimiento: v);
      case 'tipo_sangre':
      case 'sangre': return emp.copiarCon(tipoSangre: v);
      case 'notas': return emp.copiarCon(notas: v);
      case 'sitio':
      case 'sitio_trabajo': return emp.copiarCon(sitioTrabajo: v);
      default: return null;
    }
  }
  // ─── Helpers ─────────────────────────────────────────────
  String? _parseFecha(String s) {
    try {
      if (RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(s)) return s;
      if (RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(s)) {
        final p = s.split('/');
        return '${p[2]}-${p[1]}-${p[0]}';
      }
    } catch (_) {}
    return null;
  }
}

class RespuestaBot {
  final String texto;
  final String? rutaArchivo;
  RespuestaBot({required this.texto, this.rutaArchivo});
}
