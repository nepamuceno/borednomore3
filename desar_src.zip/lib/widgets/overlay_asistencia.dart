// /desar/lib/widgets/overlay_asistencia.dart
// Overlay ENTRADA/SALIDA/BAJA con sonidos - DESAR v0.0.1-beta
// Improved: employee photo shown, hours worked on exit, smoother animation

import 'dart:io';
import 'package:flutter/material.dart';
import '../modelos/empleado.dart';
import '../servicios/servicio_asistencia.dart';
import '../servicios/servicio_sonido.dart';

class OverlayAsistencia extends StatefulWidget {
  final ResultadoAsistencia? resultado;
  final Empleado? empleadoBaja;
  final VoidCallback onCerrar;

  const OverlayAsistencia({
    super.key,
    this.resultado,
    this.empleadoBaja,
    required this.onCerrar,
  });

  @override
  State<OverlayAsistencia> createState() => _OverlayAsistenciaState();
}

class _OverlayAsistenciaState extends State<OverlayAsistencia>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _escala;
  late Animation<double> _opacidad;
  final ServicioSonido _sonido = ServicioSonido();

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _escala   = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _opacidad = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _ctrl.forward();
    _reproducirSonido();

    // Auto-close: BAJA=2s, others=4s
    final delay = widget.empleadoBaja != null ? 2 : 4;
    Future.delayed(Duration(seconds: delay), () {
      if (mounted) _cerrarAnimado();
    });
  }

  Future<void> _cerrarAnimado() async {
    await _ctrl.reverse();
    if (mounted) widget.onCerrar();
  }

  void _reproducirSonido() {
    if (widget.empleadoBaja != null) {
      _sonido.reproducirBaja();
    } else if (widget.resultado?.tipo == 'entrada') {
      _sonido.reproducirEntrada();
    } else if (widget.resultado?.tipo == 'salida') {
      _sonido.reproducirSalida();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.empleadoBaja != null) return _overlayBaja();
    if (widget.resultado == null) return const SizedBox.shrink();
    final res = widget.resultado!;
    if (res.tipo == 'entrada') return _overlayEntrada(res);
    if (res.tipo == 'salida')  return _overlaySalida(res);
    return _overlayError(res);
  }

  Widget _base({required Color fondo, required Widget contenido}) =>
      FadeTransition(
        opacity: _opacidad,
        child: Material(
          color: Colors.transparent,
          child: GestureDetector(
            onTap: _cerrarAnimado,
            child: Container(
              color: fondo.withOpacity(0.96),
              child: Center(
                child: ScaleTransition(
                  scale: _escala,
                  child: contenido,
                ),
              ),
            ),
          ),
        ),
      );

  // Employee circular photo widget
  Widget _fotoEmpleado(Empleado emp, {double radio = 52}) {
    final ruta = emp.fotoPerfil ?? emp.fotoRostro1;
    return CircleAvatar(
      radius: radio,
      backgroundColor: Colors.white24,
      backgroundImage: ruta != null ? FileImage(File(ruta)) : null,
      child: ruta == null
          ? Text(emp.nombre[0].toUpperCase(),
              style: TextStyle(
                  fontSize: radio * 0.8,
                  fontWeight: FontWeight.bold,
                  color: Colors.white))
          : null,
    );
  }

  Widget _overlayEntrada(ResultadoAsistencia res) => _base(
        fondo: const Color(0xFF1B5E20),
        contenido: Column(mainAxisSize: MainAxisSize.min, children: [
          _fotoEmpleado(res.empleado),
          const SizedBox(height: 12),
          const Icon(Icons.login, color: Colors.white, size: 60),
          const Text('ENTRADA',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 52,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 6)),
          const SizedBox(height: 10),
          Text(res.empleado.nombre,
              style: const TextStyle(
                  color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          Text(res.empleado.codigoEmpleado,
              style: const TextStyle(color: Colors.white70, fontSize: 16)),
          if (res.empleado.puesto != null)
            Text(res.empleado.puesto!,
                style: const TextStyle(color: Colors.white60, fontSize: 13)),
          const SizedBox(height: 6),
          if (res.sitio != null)
            Text('🏢 ${res.sitio}',
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
          Text(_horaStr(res.timestamp),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2)),
          const SizedBox(height: 12),
          const Text('Toca para continuar',
              style: TextStyle(color: Colors.white38, fontSize: 11)),
        ]),
      );

  Widget _overlaySalida(ResultadoAsistencia res) => _base(
        fondo: const Color(0xFF0D47A1),
        contenido: Column(mainAxisSize: MainAxisSize.min, children: [
          _fotoEmpleado(res.empleado),
          const SizedBox(height: 12),
          const Icon(Icons.logout, color: Colors.white, size: 60),
          const Text('SALIDA',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 52,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 6)),
          const SizedBox(height: 10),
          Text(res.empleado.nombre,
              style: const TextStyle(
                  color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          Text(res.empleado.codigoEmpleado,
              style: const TextStyle(color: Colors.white70, fontSize: 16)),
          if (res.empleado.puesto != null)
            Text(res.empleado.puesto!,
                style: const TextStyle(color: Colors.white60, fontSize: 13)),
          const SizedBox(height: 6),
          if (res.sitio != null)
            Text('🏢 ${res.sitio}',
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
          Text(_horaStr(res.timestamp),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2)),
          // Show hours worked if available
          if (res.horasTrabajadas != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(20)),
                child: Text('⏱ ${res.horasFormateadas}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          const SizedBox(height: 12),
          const Text('Toca para continuar',
              style: TextStyle(color: Colors.white38, fontSize: 11)),
        ]),
      );

  Widget _overlayBaja() => _base(
        fondo: const Color(0xFFB71C1C),
        contenido: Column(mainAxisSize: MainAxisSize.min, children: [
          _fotoEmpleado(widget.empleadoBaja!, radio: 44),
          const SizedBox(height: 12),
          const Icon(Icons.block, color: Colors.white, size: 70),
          const Text('BAJA',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 64,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 8)),
          const SizedBox(height: 10),
          Text(widget.empleadoBaja!.nombre,
              style: const TextStyle(color: Colors.white70, fontSize: 20),
              textAlign: TextAlign.center),
          const SizedBox(height: 6),
          const Text('Empleado inactivo',
              style: TextStyle(color: Colors.white54, fontSize: 15)),
        ]),
      );

  Widget _overlayError(ResultadoAsistencia res) => _base(
        fondo: const Color(0xFF37474F),
        contenido: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, color: Colors.white, size: 64),
          const SizedBox(height: 12),
          Text(res.mensaje,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              textAlign: TextAlign.center),
        ]),
      );

  String _horaStr(String ts) {
    final dt = DateTime.parse(ts);
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}
