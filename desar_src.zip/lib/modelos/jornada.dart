// /desar/lib/modelos/jornada.dart
// Modelo de jornada laboral diaria

class Jornada {
  final int? id;
  final int empleadoId;
  final String codigoEmpleado;
  final String nombreEmpleado;
  final String fecha;
  final String? entradaTimestamp;
  final String? salidaTimestamp;
  final double? horasTrabajadas;
  final int completa;
  final String? sitioTrabajo;

  const Jornada({
    this.id,
    required this.empleadoId,
    required this.codigoEmpleado,
    required this.nombreEmpleado,
    required this.fecha,
    this.entradaTimestamp,
    this.salidaTimestamp,
    this.horasTrabajadas,
    this.completa = 0,
    this.sitioTrabajo,
  });

  Map<String, dynamic> aMapaSql() => {
        if (id != null) 'id': id,
        'empleado_id': empleadoId,
        'codigo_empleado': codigoEmpleado,
        'nombre_empleado': nombreEmpleado,
        'fecha': fecha,
        'entrada_timestamp': entradaTimestamp,
        'salida_timestamp': salidaTimestamp,
        'horas_trabajadas': horasTrabajadas,
        'completa': completa,
        'sitio_trabajo': sitioTrabajo,
      };

  factory Jornada.desdeMapa(Map<String, dynamic> m) => Jornada(
        id: m['id'] as int?,
        empleadoId: m['empleado_id'] as int,
        codigoEmpleado: m['codigo_empleado'] as String,
        nombreEmpleado: m['nombre_empleado'] as String,
        fecha: m['fecha'] as String,
        entradaTimestamp: m['entrada_timestamp'] as String?,
        salidaTimestamp: m['salida_timestamp'] as String?,
        horasTrabajadas: m['horas_trabajadas'] != null
            ? (m['horas_trabajadas'] as num).toDouble()
            : null,
        completa: m['completa'] as int? ?? 0,
        sitioTrabajo: m['sitio_trabajo'] as String?,
      );

  static double calcularHoras(String entrada, String salida) {
    final e = DateTime.parse(entrada);
    final s = DateTime.parse(salida);
    return s.difference(e).inMinutes / 60.0;
  }

  bool get estaCompleta => completa == 1;

  String get horasFormateadas {
    if (horasTrabajadas == null) return '--:--';
    final h = horasTrabajadas!.floor();
    final m = ((horasTrabajadas! - h) * 60).round();
    return '${h}h ${m.toString().padLeft(2, '0')}m';
  }
}
