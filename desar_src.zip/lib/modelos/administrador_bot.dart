// /desar/lib/modelos/administrador_bot.dart
// Administrador autorizado para comandos de bot

class AdministradorBot {
  final int? id;
  final String plataforma;      // 'telegram', 'whatsapp', 'facebook'
  final String plataformaId;    // ID único en la plataforma
  final String? nombre;
  final String? apellido;
  final String? username;       // @usuario en Telegram, etc.
  final String? email;
  final String? telefono;
  final String? empresa;
  final String? cargo;
  final String? notas;
  final bool activo;
  final String? fechaRegistro;

  const AdministradorBot({
    this.id,
    required this.plataforma,
    required this.plataformaId,
    this.nombre,
    this.apellido,
    this.username,
    this.email,
    this.telefono,
    this.empresa,
    this.cargo,
    this.notas,
    this.activo = true,
    this.fechaRegistro,
  });

  String get nombreCompleto =>
      [nombre, apellido].where((e) => e != null && e.isNotEmpty).join(' ').trim();

  String get identificador => username != null && username!.isNotEmpty
      ? '@$username' : nombreCompleto.isNotEmpty ? nombreCompleto : plataformaId;

  Map<String, dynamic> aMapaSql() => {
    if (id != null) 'id': id,
    'plataforma': plataforma,
    'plataforma_id': plataformaId,
    'nombre': nombre,
    'apellido': apellido,
    'username': username,
    'email': email,
    'telefono': telefono,
    'empresa': empresa,
    'cargo': cargo,
    'notas': notas,
    'activo': activo ? 1 : 0,
    'fecha_registro': fechaRegistro ?? DateTime.now().toIso8601String(),
  };

  factory AdministradorBot.desdeMapa(Map<String, dynamic> m) => AdministradorBot(
    id: m['id'] as int?,
    plataforma:   m['plataforma']    as String,
    plataformaId: m['plataforma_id'] as String,
    nombre:    m['nombre']    as String?,
    apellido:  m['apellido']  as String?,
    username:  m['username']  as String?,
    email:     m['email']     as String?,
    telefono:  m['telefono']  as String?,
    empresa:   m['empresa']   as String?,
    cargo:     m['cargo']     as String?,
    notas:     m['notas']     as String?,
    activo:    (m['activo'] as int? ?? 1) == 1,
    fechaRegistro: m['fecha_registro'] as String?,
  );

  @override
  String toString() => '$identificador ($plataforma)';
}
