// /desar/lib/modelos/configuracion.dart
// Configuracion ampliada - DESAR v0.0.1-beta

class Configuracion {
  final String nombreCompania;
  final String? rfcCompania;
  final String? direccionCompania;
  final String? ciudadCompania;
  final String? estadoCompania;
  final String? paisCompania;
  final String? codigoPostalCompania;
  final String? telefonoCompania;
  final String? emailCompania;
  final String? logoCompania;
  final String? whatsappApiUrl;
  final String? whatsappApiToken;
  final String? whatsappChannelId;
  final String? whatsappPhoneNumberId;
  final String? whatsappVerifyToken;
  final bool whatsappHabilitado;
  final String? telegramBotToken;
  final String? telegramChatId;
  final bool telegramHabilitado;
  // Facebook Messenger
  final String? facebookPageToken;
  final String? facebookAppId;
  final String? facebookAppSecret;
  final String? facebookVerifyToken;
  final bool facebookHabilitado;
  // Sincronización con servidor externo
  final String? syncUrl;
  final String? syncApiKey;
  final int syncPuerto;
  final bool syncHabilitado;
  final bool syncSoloWifi;
  final String botPrefijo; // ej: '/', '@mibot ', '&bot '
  final String horaEntradaDefault;
  final String horaSalidaDefault;
  final int toleranciaMinutos;
  final double jornadaHoras;
  final double umbralReconocimiento;
  final bool pedirConfirmacionNuevo;
  final String formatoReporteDefault;
  final String zonaHoraria;

  const Configuracion({
    this.nombreCompania = 'Mi Compañía',
    this.rfcCompania,
    this.direccionCompania,
    this.ciudadCompania,
    this.estadoCompania,
    this.paisCompania,
    this.codigoPostalCompania,
    this.telefonoCompania,
    this.emailCompania,
    this.logoCompania,
    this.whatsappApiUrl,
    this.whatsappApiToken,
    this.whatsappChannelId,
    this.whatsappPhoneNumberId,
    this.whatsappVerifyToken,
    this.whatsappHabilitado = false,
    this.telegramBotToken,
    this.telegramChatId,
    this.telegramHabilitado = false,
    this.facebookPageToken,
    this.facebookAppId,
    this.facebookAppSecret,
    this.facebookVerifyToken,
    this.facebookHabilitado = false,
    this.syncUrl,
    this.syncApiKey,
    this.syncPuerto = 8080,
    this.syncHabilitado = false,
    this.syncSoloWifi = true,
    this.botPrefijo = '/',
    this.horaEntradaDefault = '08:00',
    this.horaSalidaDefault = '17:00',
    this.toleranciaMinutos = 15,
    this.jornadaHoras = 8.0,
    this.umbralReconocimiento = 0.80,
    this.pedirConfirmacionNuevo = true,
    this.formatoReporteDefault = 'excel',
    this.zonaHoraria = 'America/Mexico_City',
  });

  Map<String, dynamic> aMapaSql() => {
        'nombre_compania': nombreCompania,
        'rfc_compania': rfcCompania,
        'direccion_compania': direccionCompania,
        'ciudad_compania': ciudadCompania,
        'estado_compania': estadoCompania,
        'pais_compania': paisCompania,
        'codigo_postal_compania': codigoPostalCompania,
        'telefono_compania': telefonoCompania,
        'email_compania': emailCompania,
        'logo_compania': logoCompania,
        'whatsapp_api_url': whatsappApiUrl,
        'whatsapp_api_token': whatsappApiToken,
        'whatsapp_channel_id': whatsappChannelId,
        'whatsapp_phone_number_id': whatsappPhoneNumberId,
        'whatsapp_verify_token': whatsappVerifyToken,
        'whatsapp_habilitado': whatsappHabilitado ? 1 : 0,
        'telegram_bot_token': telegramBotToken,
        'telegram_chat_id': telegramChatId,
        'telegram_habilitado': telegramHabilitado ? 1 : 0,
        'facebook_page_token': facebookPageToken,
        'facebook_app_id': facebookAppId,
        'facebook_app_secret': facebookAppSecret,
        'facebook_verify_token': facebookVerifyToken,
        'facebook_habilitado': facebookHabilitado ? 1 : 0,
        'sync_url': syncUrl,
        'sync_api_key': syncApiKey,
        'sync_puerto': syncPuerto,
        'sync_habilitado': syncHabilitado ? 1 : 0,
        'sync_solo_wifi': syncSoloWifi ? 1 : 0,
        'bot_prefijo': botPrefijo,
        'hora_entrada_default': horaEntradaDefault,
        'hora_salida_default': horaSalidaDefault,
        'tolerancia_minutos': toleranciaMinutos,
        'jornada_horas': jornadaHoras,
        'umbral_reconocimiento': umbralReconocimiento,
        'pedir_confirmacion_nuevo': pedirConfirmacionNuevo ? 1 : 0,
        'formato_reporte_default': formatoReporteDefault,
        'zona_horaria': zonaHoraria,
      };

  factory Configuracion.desdeMapa(Map<String, dynamic> m) => Configuracion(
        nombreCompania: m['nombre_compania'] as String? ?? 'Mi Compañía',
        rfcCompania: m['rfc_compania'] as String?,
        direccionCompania: m['direccion_compania'] as String?,
        ciudadCompania: m['ciudad_compania'] as String?,
        estadoCompania: m['estado_compania'] as String?,
        paisCompania: m['pais_compania'] as String?,
        codigoPostalCompania: m['codigo_postal_compania'] as String?,
        telefonoCompania: m['telefono_compania'] as String?,
        emailCompania: m['email_compania'] as String?,
        logoCompania: m['logo_compania'] as String?,
        whatsappApiUrl: m['whatsapp_api_url'] as String?,
        whatsappApiToken: m['whatsapp_api_token'] as String?,
        whatsappChannelId: m['whatsapp_channel_id'] as String?,
        whatsappPhoneNumberId: m['whatsapp_phone_number_id'] as String?,
        whatsappVerifyToken: m['whatsapp_verify_token'] as String?,
        whatsappHabilitado: (m['whatsapp_habilitado'] as int? ?? 0) == 1,
        telegramBotToken: m['telegram_bot_token'] as String?,
        telegramChatId: m['telegram_chat_id'] as String?,
        telegramHabilitado: (m['telegram_habilitado'] as int? ?? 0) == 1,
      facebookPageToken: m['facebook_page_token'] as String?,
      facebookAppId: m['facebook_app_id'] as String?,
      facebookAppSecret: m['facebook_app_secret'] as String?,
      facebookVerifyToken: m['facebook_verify_token'] as String?,
      facebookHabilitado: (m['facebook_habilitado'] as int? ?? 0) == 1,
      syncUrl: m['sync_url'] as String?,
      syncApiKey: m['sync_api_key'] as String?,
      syncPuerto: m['sync_puerto'] as int? ?? 8080,
      syncHabilitado: (m['sync_habilitado'] as int? ?? 0) == 1,
      syncSoloWifi: (m['sync_solo_wifi'] as int? ?? 1) == 1,
        botPrefijo: m['bot_prefijo'] as String? ?? '/',
        horaEntradaDefault: m['hora_entrada_default'] as String? ?? '08:00',
        horaSalidaDefault: m['hora_salida_default'] as String? ?? '17:00',
        toleranciaMinutos: m['tolerancia_minutos'] as int? ?? 15,
        jornadaHoras: (m['jornada_horas'] as num?)?.toDouble() ?? 8.0,
        umbralReconocimiento: (m['umbral_reconocimiento'] as num?)?.toDouble() ?? 0.80,
        pedirConfirmacionNuevo: (m['pedir_confirmacion_nuevo'] as int? ?? 1) == 1,
        formatoReporteDefault: m['formato_reporte_default'] as String? ?? 'excel',
        zonaHoraria: m['zona_horaria'] as String? ?? 'America/Mexico_City',
      );

  String get direccionCompleta => [
        if (direccionCompania != null) direccionCompania!,
        if (ciudadCompania != null) ciudadCompania!,
        if (estadoCompania != null) estadoCompania!,
        if (paisCompania != null) paisCompania!,
      ].join(', ');

  Configuracion copiarCon({
    String? nombreCompania, String? rfcCompania, String? direccionCompania,
    String? ciudadCompania, String? estadoCompania, String? paisCompania,
    String? telefonoCompania, String? emailCompania, String? logoCompania,
    String? whatsappApiUrl, String? whatsappApiToken, String? whatsappChannelId,
    String? whatsappPhoneNumberId, String? whatsappVerifyToken,
    bool? whatsappHabilitado, String? telegramBotToken, String? telegramChatId,
    bool? telegramHabilitado,
    String? facebookPageToken,
    String? facebookAppId,
    String? facebookAppSecret,
    String? facebookVerifyToken,
    bool? facebookHabilitado,
    String? syncUrl,
    String? syncApiKey,
    int? syncPuerto,
    bool? syncHabilitado,
    bool? syncSoloWifi, String? botPrefijo,
    String? horaEntradaDefault, String? horaSalidaDefault,
    int? toleranciaMinutos, double? jornadaHoras,
    double? umbralReconocimiento, bool? pedirConfirmacionNuevo,
    String? formatoReporteDefault, String? zonaHoraria,
  }) => Configuracion(
    nombreCompania: nombreCompania ?? this.nombreCompania,
    rfcCompania: rfcCompania ?? this.rfcCompania,
    direccionCompania: direccionCompania ?? this.direccionCompania,
    ciudadCompania: ciudadCompania ?? this.ciudadCompania,
    estadoCompania: estadoCompania ?? this.estadoCompania,
    paisCompania: paisCompania ?? this.paisCompania,
    telefonoCompania: telefonoCompania ?? this.telefonoCompania,
    emailCompania: emailCompania ?? this.emailCompania,
    logoCompania: logoCompania ?? this.logoCompania,
    whatsappApiUrl: whatsappApiUrl ?? this.whatsappApiUrl,
    whatsappApiToken: whatsappApiToken ?? this.whatsappApiToken,
    whatsappChannelId: whatsappChannelId ?? this.whatsappChannelId,
    whatsappPhoneNumberId: whatsappPhoneNumberId ?? this.whatsappPhoneNumberId,
    whatsappVerifyToken: whatsappVerifyToken ?? this.whatsappVerifyToken,
    whatsappHabilitado: whatsappHabilitado ?? this.whatsappHabilitado,
    telegramBotToken: telegramBotToken ?? this.telegramBotToken,
    telegramChatId: telegramChatId ?? this.telegramChatId,
    telegramHabilitado: telegramHabilitado ?? this.telegramHabilitado,
    botPrefijo: botPrefijo ?? this.botPrefijo,
    horaEntradaDefault: horaEntradaDefault ?? this.horaEntradaDefault,
    horaSalidaDefault: horaSalidaDefault ?? this.horaSalidaDefault,
    toleranciaMinutos: toleranciaMinutos ?? this.toleranciaMinutos,
    jornadaHoras: jornadaHoras ?? this.jornadaHoras,
    umbralReconocimiento: umbralReconocimiento ?? this.umbralReconocimiento,
    pedirConfirmacionNuevo: pedirConfirmacionNuevo ?? this.pedirConfirmacionNuevo,
    formatoReporteDefault: formatoReporteDefault ?? this.formatoReporteDefault,
    zonaHoraria: zonaHoraria ?? this.zonaHoraria,
  );
}
