// /desar/lib/modelos/registro.dart
// Modelo de registro de asistencia - entrada o salida

class Registro {
  final int? id;
  final int empleadoId;
  final String codigoEmpleado;
  final String nombreEmpleado;
  final String tipo; // 'entrada' | 'salida'
  final String timestamp;
  final double? gpsLat;
  final double? gpsLon;
  final String? sitioTrabajo;
  final String metodo; // 'qr' | 'rostro' | 'manual'
  final String? notas;

  const Registro({
    this.id,
    required this.empleadoId,
    required this.codigoEmpleado,
    required this.nombreEmpleado,
    required this.tipo,
    required this.timestamp,
    this.gpsLat,
    this.gpsLon,
    this.sitioTrabajo,
    required this.metodo,
    this.notas,
  });

  Map<String, dynamic> aMapaSql() => {
        if (id != null) 'id': id,
        'empleado_id': empleadoId,
        'codigo_empleado': codigoEmpleado,
        'nombre_empleado': nombreEmpleado,
        'tipo': tipo,
        'timestamp': timestamp,
        'gps_lat': gpsLat,
        'gps_lon': gpsLon,
        'sitio_trabajo': sitioTrabajo,
        'metodo': metodo,
        'notas': notas,
      };

  factory Registro.desdeMapa(Map<String, dynamic> m) => Registro(
        id: m['id'] as int?,
        empleadoId: m['empleado_id'] as int,
        codigoEmpleado: m['codigo_empleado'] as String,
        nombreEmpleado: m['nombre_empleado'] as String,
        tipo: m['tipo'] as String,
        timestamp: m['timestamp'] as String,
        gpsLat: m['gps_lat'] != null ? (m['gps_lat'] as num).toDouble() : null,
        gpsLon: m['gps_lon'] != null ? (m['gps_lon'] as num).toDouble() : null,
        sitioTrabajo: m['sitio_trabajo'] as String?,
        metodo: m['metodo'] as String,
        notas: m['notas'] as String?,
      );

  DateTime get fechaHora => DateTime.parse(timestamp);

  bool get esEntrada => tipo == 'entrada';
  bool get esSalida => tipo == 'salida';

  @override
  String toString() => 'Registro($codigoEmpleado - $tipo - $timestamp)';
}
