// /desar/lib/modelos/empleado.dart
// v2: fechaAlta, fechaVencimiento

class Empleado {
  final int? id;
  final String codigoEmpleado;
  final String nombre;
  final String? direccion;
  final String? ciudad;
  final String? estado;
  final String? pais;
  final String? codigoPostal;
  final String? telefono;
  final String? telefonoEmergencia;
  final String? fechaNacimiento;
  final String? rfc;
  final String? seguroSocial;
  final String? numeroIdentificacion;
  final String? puesto;
  final String? tipoSangre;
  final String? notas;
  final String? fotoPerfil;
  final String? fotoRostro1;
  final String? fotoRostro2;
  final String? fotoRostro3;
  final String? embedding1;
  final String? embedding2;
  final String? embedding3;
  final String? sitioTrabajo;
  final int activo;
  final String? fechaRegistro;
  final String? fechaAlta;
  final String? fechaVencimiento;

  const Empleado({
    this.id,
    required this.codigoEmpleado,
    required this.nombre,
    this.direccion, this.ciudad, this.estado, this.pais, this.codigoPostal,
    this.telefono, this.telefonoEmergencia, this.fechaNacimiento,
    this.rfc, this.seguroSocial, this.numeroIdentificacion,
    this.puesto, this.tipoSangre, this.notas,
    this.fotoPerfil, this.fotoRostro1, this.fotoRostro2, this.fotoRostro3,
    this.embedding1, this.embedding2, this.embedding3,
    this.sitioTrabajo, this.activo = 1, this.fechaRegistro,
    this.fechaAlta, this.fechaVencimiento,
  });

  Map<String, dynamic> aMapaSql() => {
    if (id != null) 'id': id,
    'codigo_empleado': codigoEmpleado, 'nombre': nombre,
    'direccion': direccion, 'ciudad': ciudad, 'estado': estado,
    'pais': pais, 'codigo_postal': codigoPostal,
    'telefono': telefono, 'telefono_emergencia': telefonoEmergencia,
    'fecha_nacimiento': fechaNacimiento, 'rfc': rfc,
    'seguro_social': seguroSocial, 'numero_identificacion': numeroIdentificacion,
    'puesto': puesto, 'tipo_sangre': tipoSangre, 'notas': notas,
    'foto_perfil': fotoPerfil, 'foto_rostro_1': fotoRostro1,
    'foto_rostro_2': fotoRostro2, 'foto_rostro_3': fotoRostro3,
    'embedding_1': embedding1, 'embedding_2': embedding2, 'embedding_3': embedding3,
    'sitio_trabajo': sitioTrabajo, 'activo': activo,
    'fecha_registro': fechaRegistro ?? DateTime.now().toIso8601String(),
    'fecha_alta': fechaAlta, 'fecha_vencimiento': fechaVencimiento,
  };

  factory Empleado.desdeMapa(Map<String, dynamic> m) => Empleado(
    id: m['id'] as int?,
    codigoEmpleado: m['codigo_empleado'] as String,
    nombre: m['nombre'] as String,
    direccion: m['direccion'] as String?, ciudad: m['ciudad'] as String?,
    estado: m['estado'] as String?, pais: m['pais'] as String?,
    codigoPostal: m['codigo_postal'] as String?,
    telefono: m['telefono'] as String?,
    telefonoEmergencia: m['telefono_emergencia'] as String?,
    fechaNacimiento: m['fecha_nacimiento'] as String?,
    rfc: m['rfc'] as String?, seguroSocial: m['seguro_social'] as String?,
    numeroIdentificacion: m['numero_identificacion'] as String?,
    puesto: m['puesto'] as String?, tipoSangre: m['tipo_sangre'] as String?,
    notas: m['notas'] as String?, fotoPerfil: m['foto_perfil'] as String?,
    fotoRostro1: m['foto_rostro_1'] as String?,
    fotoRostro2: m['foto_rostro_2'] as String?,
    fotoRostro3: m['foto_rostro_3'] as String?,
    embedding1: m['embedding_1'] as String?,
    embedding2: m['embedding_2'] as String?,
    embedding3: m['embedding_3'] as String?,
    sitioTrabajo: m['sitio_trabajo'] as String?,
    activo: m['activo'] as int? ?? 1,
    fechaRegistro: m['fecha_registro'] as String?,
    fechaAlta: m['fecha_alta'] as String?,
    fechaVencimiento: m['fecha_vencimiento'] as String?,
  );

  Empleado copiarCon({
    int? id, String? codigoEmpleado, String? nombre,
    String? direccion, String? ciudad, String? estado, String? pais, String? codigoPostal,
    String? telefono, String? telefonoEmergencia, String? fechaNacimiento,
    String? rfc, String? seguroSocial, String? numeroIdentificacion,
    String? puesto, String? tipoSangre, String? notas,
    String? fotoPerfil, String? fotoRostro1, String? fotoRostro2, String? fotoRostro3,
    String? embedding1, String? embedding2, String? embedding3,
    String? sitioTrabajo, int? activo, String? fechaRegistro,
    String? fechaAlta, String? fechaVencimiento,
  }) => Empleado(
    id: id ?? this.id, codigoEmpleado: codigoEmpleado ?? this.codigoEmpleado,
    nombre: nombre ?? this.nombre, direccion: direccion ?? this.direccion,
    ciudad: ciudad ?? this.ciudad, estado: estado ?? this.estado,
    pais: pais ?? this.pais, codigoPostal: codigoPostal ?? this.codigoPostal,
    telefono: telefono ?? this.telefono,
    telefonoEmergencia: telefonoEmergencia ?? this.telefonoEmergencia,
    fechaNacimiento: fechaNacimiento ?? this.fechaNacimiento,
    rfc: rfc ?? this.rfc, seguroSocial: seguroSocial ?? this.seguroSocial,
    numeroIdentificacion: numeroIdentificacion ?? this.numeroIdentificacion,
    puesto: puesto ?? this.puesto, tipoSangre: tipoSangre ?? this.tipoSangre,
    notas: notas ?? this.notas, fotoPerfil: fotoPerfil ?? this.fotoPerfil,
    fotoRostro1: fotoRostro1 ?? this.fotoRostro1,
    fotoRostro2: fotoRostro2 ?? this.fotoRostro2,
    fotoRostro3: fotoRostro3 ?? this.fotoRostro3,
    embedding1: embedding1 ?? this.embedding1,
    embedding2: embedding2 ?? this.embedding2,
    embedding3: embedding3 ?? this.embedding3,
    sitioTrabajo: sitioTrabajo ?? this.sitioTrabajo,
    activo: activo ?? this.activo, fechaRegistro: fechaRegistro ?? this.fechaRegistro,
    fechaAlta: fechaAlta ?? this.fechaAlta,
    fechaVencimiento: fechaVencimiento ?? this.fechaVencimiento,
  );

  bool get estaActivo => activo == 1;
  String get ubicacion => [ciudad, estado, pais].where((e) => e != null && e.isNotEmpty).join(', ');

  @override
  String toString() => 'Empleado($codigoEmpleado - $nombre)';
}
