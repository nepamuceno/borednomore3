// /desar/lib/modelos/sitio.dart
// v3: tipoSitio, recibirAdvertencias

class Sitio {
  final int? id;
  final String nombre;
  final String? descripcion;
  final double? gpsLat;
  final double? gpsLon;
  final double? geofenceRadioMetros;
  final String? geofenceTipo;       // 'permitido' o 'prohibido'
  final bool geofenceActivo;
  final String tipoSitio;           // 'normal','restringido','peligroso','remoto','otro'
  final bool recibirAdvertencias;   // enviar alerta bot al entrar/salir
  final int activo;

  const Sitio({
    this.id,
    required this.nombre,
    this.descripcion,
    this.gpsLat,
    this.gpsLon,
    this.geofenceRadioMetros,
    this.geofenceTipo = 'permitido',
    this.geofenceActivo = false,
    this.tipoSitio = 'normal',
    this.recibirAdvertencias = false,
    this.activo = 1,
  });

  bool get tieneGeofence => gpsLat != null && gpsLon != null && geofenceActivo;
  bool get esZonaProhibida => geofenceTipo == 'prohibido';

  Map<String, dynamic> aMapaSql() => {
    if (id != null) 'id': id,
    'nombre': nombre,
    'descripcion': descripcion,
    'gps_lat': gpsLat,
    'gps_lon': gpsLon,
    'geofence_radio_metros': geofenceRadioMetros,
    'geofence_tipo': geofenceTipo ?? 'permitido',
    'geofence_activo': geofenceActivo ? 1 : 0,
    'tipo_sitio': tipoSitio,
    'recibir_advertencias': recibirAdvertencias ? 1 : 0,
    'activo': activo,
  };

  factory Sitio.desdeMapa(Map<String, dynamic> m) => Sitio(
    id: m['id'] as int?,
    nombre: m['nombre'] as String,
    descripcion: m['descripcion'] as String?,
    gpsLat: m['gps_lat'] != null ? (m['gps_lat'] as num).toDouble() : null,
    gpsLon: m['gps_lon'] != null ? (m['gps_lon'] as num).toDouble() : null,
    geofenceRadioMetros: m['geofence_radio_metros'] != null
        ? (m['geofence_radio_metros'] as num).toDouble() : null,
    geofenceTipo:   m['geofence_tipo'] as String? ?? 'permitido',
    geofenceActivo: (m['geofence_activo'] as int? ?? 0) == 1,
    tipoSitio:           m['tipo_sitio'] as String? ?? 'normal',
    recibirAdvertencias: (m['recibir_advertencias'] as int? ?? 0) == 1,
    activo: m['activo'] as int? ?? 1,
  );

  static const List<String> tiposSitio = [
    'normal', 'restringido', 'peligroso', 'remoto', 'otro'
  ];

  String get tipoSitioLabel {
    switch (tipoSitio) {
      case 'restringido': return '🔒 Restringido';
      case 'peligroso':   return '⚠️ Peligroso';
      case 'remoto':      return '📡 Remoto';
      case 'otro':        return '📍 Otro';
      default:            return '✅ Normal';
    }
  }

  @override
  String toString() => nombre;
}
