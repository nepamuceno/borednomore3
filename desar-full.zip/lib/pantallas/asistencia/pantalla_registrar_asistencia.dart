// /desar/lib/pantallas/asistencia/pantalla_registrar_asistencia.dart
// Fixed: facial shows clear model-missing instructions instead of generic error
//        manual mode includes name search with suggestion list
//        all 3 methods in unified TabBar screen

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:camera/camera.dart';
import '../../servicios/servicio_asistencia.dart';
import '../../servicios/servicio_reconocimiento_facial.dart';
import '../../servicios/servicio_qr.dart';
import '../../servicios/servicio_bot.dart';
import '../../base_datos/base_datos_helper.dart';
import '../../modelos/empleado.dart';
import '../../modelos/configuracion.dart';
import '../../modelos/registro.dart';
import '../../widgets/overlay_asistencia.dart';
import '../empleados/pantalla_nuevo_empleado.dart';

class PantallaRegistrarAsistencia extends StatefulWidget {
  final String metodo;
  const PantallaRegistrarAsistencia({super.key, required this.metodo});

  @override
  State<PantallaRegistrarAsistencia> createState() =>
      _PantallaRegistrarAsistenciaState();
}

class _PantallaRegistrarAsistenciaState
    extends State<PantallaRegistrarAsistencia>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final ServicioAsistencia _svcAsist    = ServicioAsistencia();
  final ServicioReconocimientoFacial _svcFacial = ServicioReconocimientoFacial();
  final ServicioQr _svcQr              = ServicioQr();
  final ServicioBot _svcBot            = ServicioBot();
  final BaseDatosHelper _bd            = BaseDatosHelper();

  late TabController _tab;

  CameraController? _camara;
  bool _camaraLista   = false;
  bool _procesando    = false;
  bool _mostrarOverlay = false;
  ResultadoAsistencia? _ultimoResultado;
  Empleado? _empleadoBaja;
  Configuracion? _cfg;

  // Last 5 records live strip
  List<Registro> _ultimosRegistros = [];

  // Facial
  Timer? _timerFacial;
  bool _analizandoFacial    = false;
  String _estadoFacial      = 'Apunte la cámara al rostro del empleado';
  double _confianza         = 0.0;
  int _intentosFallidos     = 0;
  bool _modeloDisponible    = true; // assume true until first attempt
  bool _intentandoModelo    = false;
  static const int _maxIntentosFallidos = 3;

  // Manual mode — code + name search
  final TextEditingController _ctrlCodigo  = TextEditingController();
  final TextEditingController _ctrlBusq    = TextEditingController();
  List<Empleado> _sugerencias = [];
  List<Empleado> _todosEmpleados = [];
  bool _buscando = false;

  int _tabIndexFor(String m) {
    switch (m) {
      case 'qr':     return 0;
      case 'rostro': return 1;
      default:       return 2;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _tab = TabController(length: 3, vsync: this, initialIndex: _tabIndexFor(widget.metodo));
    _tab.addListener(_onTabChange);
    _cargarConfig();
    _cargarUltimosRegistros();
    _cargarEmpleados();
    if (widget.metodo == 'rostro') _iniciarCamaraYModelo();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tab.removeListener(_onTabChange);
    _tab.dispose();
    _timerFacial?.cancel();
    _camara?.dispose();
    _ctrlCodigo.dispose();
    _ctrlBusq.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) {
      _timerFacial?.cancel();
    } else if (state == AppLifecycleState.resumed && _tab.index == 1) {
      _iniciarCamaraYModelo();
    }
  }

  void _onTabChange() {
    if (!_tab.indexIsChanging) return;
    if (_tab.index == 1 && !_camaraLista) {
      _iniciarCamaraYModelo();
    } else if (_tab.index != 1) {
      _timerFacial?.cancel();
    }
  }

  Future<void> _cargarConfig() async {
    _cfg = await _bd.obtenerConfiguracion();
    if (_cfg != null) _svcFacial.umbral = _cfg!.umbralReconocimiento;
  }

  Future<void> _cargarUltimosRegistros() async {
    final lista = await _bd.obtenerUltimosRegistros(limite: 5);
    if (mounted) setState(() => _ultimosRegistros = lista);
  }

  Future<void> _cargarEmpleados() async {
    _todosEmpleados = await _bd.obtenerEmpleadosActivos();
  }

  // Name/code search for manual mode
  void _buscarEmpleados(String q) {
    if (q.trim().isEmpty) {
      setState(() => _sugerencias = []);
      return;
    }
    final ql = q.toLowerCase();
    setState(() {
      _sugerencias = _todosEmpleados.where((e) =>
          e.nombre.toLowerCase().contains(ql) ||
          e.codigoEmpleado.toLowerCase().contains(ql) ||
          (e.puesto ?? '').toLowerCase().contains(ql)).take(8).toList();
    });
  }

  Future<void> _iniciarCamaraYModelo() async {
    _iniciarCamara();
    if (!_svcFacial.modeloCargado && !_intentandoModelo) {
      _intentandoModelo = true;
      final ok = await _svcFacial.cargarModelo();
      if (mounted) setState(() { _modeloDisponible = ok; _intentandoModelo = false; });
    }
  }

  Future<void> _iniciarCamara() async {
    if (_camaraLista) return;
    try {
      final camaras = await availableCameras();
      if (camaras.isEmpty) { setState(() => _estadoFacial = 'No se encontró cámara'); return; }
      final camara = camaras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => camaras.first);
      _camara = CameraController(camara, ResolutionPreset.medium,
          enableAudio: false, imageFormatGroup: ImageFormatGroup.jpeg);
      await _camara!.initialize();
        // Zoom mínimo para que solo quepa la cara
        try {
          final zoomMin = await _camara!.getMinZoomLevel();
          final zoomMax = await _camara!.getMaxZoomLevel();
          final zoom = (zoomMin + (zoomMax - zoomMin) * 0.35).clamp(zoomMin, zoomMax);
          await _camara!.setZoomLevel(zoom);
        } catch (_) {}
      if (!mounted) return;
      setState(() => _camaraLista = true);
      _timerFacial = Timer.periodic(const Duration(milliseconds: 900), (_) {
        if (!_procesando && !_mostrarOverlay && !_analizandoFacial && _modeloDisponible && mounted) {
          _analizarFrame();
        }
      });
    } catch (e) {
      print('[CAM] Error: $e');
      if (mounted) setState(() => _estadoFacial = 'Error cámara: $e');
    }
  }

  Future<void> _analizarFrame() async {
    if (_camara == null || !_camaraLista || _analizandoFacial || !mounted) return;
    _analizandoFacial = true;
    try {
      if (!_svcFacial.modeloCargado) {
        // Try loading once more silently
        final ok = await _svcFacial.cargarModelo();
        if (!ok) {
          if (mounted) setState(() { _modeloDisponible = false; });
          _analizandoFacial = false;
          return;
        }
      }
      final xfile = await _camara!.takePicture();
      final bytes = await xfile.readAsBytes();
      final resultado = await _svcFacial.reconocer(bytes);
      if (!mounted) { _analizandoFacial = false; return; }

      if (resultado.reconocido && resultado.empleado != null) {
        _intentosFallidos = 0;
        setState(() { _confianza = resultado.confianza ?? 0; _estadoFacial = 'Identificado: ${resultado.empleado!.nombre}'; });
        await Future.delayed(const Duration(milliseconds: 300));
        if (mounted && !_procesando && !_mostrarOverlay) {
          await _procesarEmpleado(resultado.empleado!.codigoEmpleado);
        }
      } else {
        _intentosFallidos++;
        setState(() {
          _confianza = 0;
          _estadoFacial = _intentosFallidos <= _maxIntentosFallidos
              ? 'Buscando rostro...'
              : 'Rostro no reconocido. Acerque o ajuste posición.';
        });
      }
    } catch (e) {
      print('[FACIAL] Error frame: $e');
      if (mounted) setState(() => _estadoFacial = 'Error procesando imagen');
    }
    _analizandoFacial = false;
  }

  Future<void> _procesarEmpleado(String codigo) async {
    if (_procesando || _mostrarOverlay) return;
    setState(() => _procesando = true);
    final empleado = await _bd.obtenerEmpleadoPorCodigo(codigo.toUpperCase());
    if (empleado == null) {
      setState(() => _procesando = false);
      await _preguntarNuevo(codigo);
      return;
    }
    if (!empleado.estaActivo) {
      setState(() { _empleadoBaja = empleado; _ultimoResultado = null;
        _mostrarOverlay = true; _procesando = false;
        _estadoFacial = 'Apunte la cámara al rostro del empleado'; });
      return;
    }
    final resultado = await _svcAsist.registrar(empleado: empleado, metodo: _metodoActual());
    if (resultado.exitoso) {
      await _svcBot.notificarAsistencia(resultado.mensajeBot);
      await _cargarUltimosRegistros();
    }
    if (mounted) {
      setState(() { _ultimoResultado = resultado; _empleadoBaja = null;
        _mostrarOverlay = true; _procesando = false;
        _confianza = 0; _intentosFallidos = 0;
        _estadoFacial = 'Apunte la cámara al rostro del empleado';
        _sugerencias = []; _ctrlBusq.clear(); _ctrlCodigo.clear(); });
    }
  }

  String _metodoActual() {
    switch (_tab.index) { case 0: return 'qr'; case 1: return 'rostro'; default: return 'manual'; }
  }

  Future<void> _preguntarNuevo(String codigoSugerido) async {
    if (!(_cfg?.pedirConfirmacionNuevo ?? true)) return;
    final agregar = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Empleado no encontrado'),
      content: Text('No se encontró "$codigoSugerido".\n¿Registrar nuevo empleado?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('No')),
        ElevatedButton(onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white),
            child: const Text('Sí, registrar')),
      ],
    ));
    if (agregar == true && mounted) {
      await Navigator.push(context,
          MaterialPageRoute(builder: (_) => PantallaNuevoEmpleado(codigoSugerido: codigoSugerido)));
    }
  }

  Future<void> _procesarQr(String raw) async {
    if (_procesando || _mostrarOverlay) return;
    final res = _svcQr.procesar(raw);
    await _procesarEmpleado(res.valido ? res.codigoEmpleado! : raw);
  }

  Future<void> _registrarManual() async {
    final cod = _ctrlCodigo.text.trim();
    if (cod.isEmpty) return;
    _ctrlCodigo.clear();
    await _procesarEmpleado(cod);
  }

  void _cerrarOverlay() {
    setState(() { _mostrarOverlay = false; _ultimoResultado = null; _empleadoBaja = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
        title: const Text('Registrar Asistencia'),
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Colors.white, labelColor: Colors.white, unselectedLabelColor: Colors.white60,
          tabs: const [
            Tab(icon: Icon(Icons.qr_code_scanner),         text: 'QR'),
            Tab(icon: Icon(Icons.face_retouching_natural), text: 'Facial'),
            Tab(icon: Icon(Icons.keyboard),                text: 'Manual'),
          ],
        ),
      ),
      body: Stack(children: [
        Column(children: [
          if (_ultimosRegistros.isNotEmpty) _barraUltimosRegistros(),
          Expanded(child: TabBarView(controller: _tab, children: [
            _vistaQr(),
            _vistaRostro(),
            _vistaManual(),
          ])),
        ]),
        if (_mostrarOverlay)
          Positioned.fill(child: OverlayAsistencia(
            resultado: _ultimoResultado, empleadoBaja: _empleadoBaja, onCerrar: _cerrarOverlay)),
      ]),
    );
  }

  Widget _barraUltimosRegistros() {
    return Container(
      color: const Color(0xFF0D47A1), height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        itemCount: _ultimosRegistros.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (_, i) {
          final r = _ultimosRegistros[i];
          final esEntrada = r.tipo == 'entrada';
          final dt = DateTime.parse(r.timestamp);
          final hora = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: esEntrada ? Colors.green.withOpacity(0.25) : Colors.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: esEntrada ? Colors.green : Colors.blueAccent, width: 1),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(esEntrada ? Icons.login : Icons.logout, size: 13,
                  color: esEntrada ? Colors.greenAccent : Colors.blueAccent),
              const SizedBox(width: 4),
              Text(r.nombreEmpleado.split(' ').first,
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(width: 4),
              Text(hora, style: const TextStyle(color: Colors.white70, fontSize: 10)),
            ]),
          );
        },
      ),
    );
  }

  Widget _vistaQr() => Stack(children: [
    MobileScanner(onDetect: (cap) {
      if (_procesando || _mostrarOverlay) return;
      final val = cap.barcodes.firstOrNull?.rawValue ?? '';
      if (val.isNotEmpty) _procesarQr(val);
    }),
    Center(child: Container(width: 260, height: 260,
        decoration: BoxDecoration(border: Border.all(color: Colors.blueAccent, width: 3),
            borderRadius: BorderRadius.circular(16)))),
    Positioned(bottom: 30, left: 0, right: 0,
        child: const Text('Apunte al código QR del empleado',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 14))),
    if (_procesando) Container(color: Colors.black54,
        child: const Center(child: CircularProgressIndicator(color: Colors.white))),
  ]);

  Widget _vistaRostro() {
    // Model not available — show clear installation instructions
    if (!_modeloDisponible && !_intentandoModelo) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.model_training, color: Colors.orange, size: 72),
          const SizedBox(height: 20),
          const Text('Modelo de IA no instalado',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(12)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Para activar reconocimiento facial:', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('1. Descargue facenet.tflite o mobilefacenet.tflite', style: TextStyle(color: Colors.white60, fontSize: 13)),
              SizedBox(height: 4),
              Text('2. Colóquelo en assets/modelos_ia/', style: TextStyle(color: Colors.white60, fontSize: 13)),
              SizedBox(height: 4),
              Text('3. Recompile la aplicación', style: TextStyle(color: Colors.white60, fontSize: 13)),
              SizedBox(height: 12),
              Text('Mientras tanto use QR o Manual →', style: TextStyle(color: Colors.orange, fontSize: 13)),
            ]),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () => _tab.animateTo(2),
            icon: const Icon(Icons.keyboard),
            label: const Text('Ir a Ingreso Manual'),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white),
          ),
        ]),
      ));
    }

    if (_intentandoModelo) {
      return const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        CircularProgressIndicator(color: Colors.white),
        SizedBox(height: 16),
        Text('Cargando modelo facial…', style: TextStyle(color: Colors.white70)),
      ]));
    }

    return Stack(children: [
      if (_camaraLista && _camara != null)
        Positioned.fill(child: CameraPreview(_camara!))
      else
        const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircularProgressIndicator(color: Colors.white), SizedBox(height: 16),
          Text('Iniciando cámara...', style: TextStyle(color: Colors.white70)),
        ])),

      // Oscurecer área fuera del óvalo
      Positioned.fill(child: CustomPaint(painter: FaceOvalPainter())),
      Center(child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: 220, height: 260,
        decoration: BoxDecoration(
          border: Border.all(
            color: _analizandoFacial ? Colors.yellow
                : (_confianza > 0 ? Colors.green : Colors.blueAccent),
            width: _confianza > 0 ? 4 : 2),
          borderRadius: BorderRadius.circular(130)),
      )),

      if (_confianza > 0)
        Positioned(bottom: 120, left: 40, right: 40, child: Column(children: [
          Text('${_confianza.toStringAsFixed(0)}% confianza',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          ClipRRect(borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(value: _confianza / 100,
                  backgroundColor: Colors.white24,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.green), minHeight: 8)),
        ])),

      Positioned(top: 20, left: 20, right: 20, child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          if (_analizandoFacial) const SizedBox(width: 14, height: 14,
              child: CircularProgressIndicator(color: Colors.yellow, strokeWidth: 2)),
          if (_analizandoFacial) const SizedBox(width: 8),
          Flexible(child: Text(_estadoFacial, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 13))),
        ]),
      )),

      Positioned(bottom: 30, left: 0, right: 0, child: Column(children: [
        const Text('Centre su rostro en el óvalo • Buena iluminación • Sin lentes',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 8),
        TextButton.icon(
          onPressed: () { if (!_procesando) _analizarFrame(); },
          icon: const Icon(Icons.camera, color: Colors.white54, size: 16),
          label: const Text('Capturar ahora', style: TextStyle(color: Colors.white54, fontSize: 12))),
      ])),

      if (_procesando) Container(color: Colors.black54,
          child: const Center(child: CircularProgressIndicator(color: Colors.white))),
    ]);
  }

  // Manual mode — code field + name search with suggestions
  Widget _vistaManual() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const SizedBox(height: 20),
        const Icon(Icons.badge, color: Colors.white54, size: 64),
        const SizedBox(height: 20),

        // ── Code field ──────────────────────────────────────
        const Text('Código de empleado',
            style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _ctrlCodigo,
          textCapitalization: TextCapitalization.characters,
          style: const TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 4),
          textAlign: TextAlign.center,
          decoration: InputDecoration(
              hintText: 'EMP001', hintStyle: const TextStyle(color: Colors.white30),
              filled: true, fillColor: Colors.white12,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
          onSubmitted: (_) => _registrarManual(),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: ElevatedButton(
          onPressed: _procesando ? null : _registrarManual,
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1976D2), foregroundColor: Colors.white,
              padding: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: _procesando
              ? const SizedBox(width: 22, height: 22,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : const Text('REGISTRAR', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        )),

        const SizedBox(height: 24),
        const Divider(color: Colors.white24),
        const SizedBox(height: 12),

        // ── Name search ──────────────────────────────────────
        const Text('Buscar por nombre',
            style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _ctrlBusq,
          style: const TextStyle(color: Colors.white),
          onChanged: _buscarEmpleados,
          decoration: InputDecoration(
              hintText: 'Escriba nombre o código…',
              hintStyle: const TextStyle(color: Colors.white30),
              prefixIcon: const Icon(Icons.search, color: Colors.white54),
              suffixIcon: _ctrlBusq.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.clear, color: Colors.white54),
                      onPressed: () { _ctrlBusq.clear(); setState(() => _sugerencias = []); })
                  : null,
              filled: true, fillColor: Colors.white12,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
        ),
        const SizedBox(height: 8),

        // Suggestions list
        if (_sugerencias.isNotEmpty)
          Container(
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12)),
            child: Column(children: _sugerencias.map((emp) => ListTile(
              leading: CircleAvatar(
                backgroundColor: emp.estaActivo ? const Color(0xFF1976D2) : Colors.grey,
                radius: 18,
                child: Text(emp.nombre[0].toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
              ),
              title: Text(emp.nombre,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
              subtitle: Text('${emp.codigoEmpleado}${emp.puesto != null ? " · ${emp.puesto}" : ""}',
                  style: const TextStyle(color: Colors.white54, fontSize: 11)),
              trailing: Icon(emp.estaActivo ? Icons.login : Icons.block,
                  color: emp.estaActivo ? Colors.green : Colors.red, size: 20),
              onTap: () {
                if (!emp.estaActivo) {
                  setState(() { _empleadoBaja = emp; _mostrarOverlay = true; _sugerencias = []; _ctrlBusq.clear(); });
                } else {
                  _ctrlBusq.clear();
                  setState(() => _sugerencias = []);
                  _procesarEmpleado(emp.codigoEmpleado);
                }
              },
            )).toList()),
          )
        else if (_ctrlBusq.text.isNotEmpty && _sugerencias.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('Sin resultados', style: TextStyle(color: Colors.white38, fontSize: 13)),
          ),
      ]),
    );
  }
}


class FaceOvalPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0x88000000);
    final oval = Rect.fromCenter(
        center: Offset(size.width / 2, size.height / 2),
        width: 224, height: 264);
    canvas.drawPath(
      Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
            ..addOval(oval)..fillType = PathFillType.evenOdd,
      paint);
  }
  @override
  bool shouldRepaint(FaceOvalPainter old) => false;
}
