module desar-server

go 1.22

require (
	github.com/go-chi/chi/v5 v5.0.12
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/gorilla/websocket v1.5.1
	golang.org/x/crypto v0.22.0
	modernc.org/sqlite v1.29.9
)
